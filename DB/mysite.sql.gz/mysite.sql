-- MySQL dump 10.13  Distrib 8.0.33, for Linux (x86_64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	8.0.33-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `addresses`
--

DROP TABLE IF EXISTS `addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `addresses` (
  `id` int NOT NULL,
  `ownerId` int DEFAULT NULL,
  `countryCode` varchar(255) NOT NULL,
  `administrativeArea` varchar(255) DEFAULT NULL,
  `locality` varchar(255) DEFAULT NULL,
  `dependentLocality` varchar(255) DEFAULT NULL,
  `postalCode` varchar(255) DEFAULT NULL,
  `sortingCode` varchar(255) DEFAULT NULL,
  `addressLine1` varchar(255) DEFAULT NULL,
  `addressLine2` varchar(255) DEFAULT NULL,
  `organization` varchar(255) DEFAULT NULL,
  `organizationTaxId` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `latitude` varchar(255) DEFAULT NULL,
  `longitude` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_xffsukgckkirgeyvqodkadjlsrfehqkquuva` (`ownerId`),
  CONSTRAINT `fk_xffsukgckkirgeyvqodkadjlsrfehqkquuva` FOREIGN KEY (`ownerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xteyorsijcgxwamikeygsxcfjqpbwrdjzzen` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `addresses`
--

LOCK TABLES `addresses` WRITE;
/*!40000 ALTER TABLE `addresses` DISABLE KEYS */;
/*!40000 ALTER TABLE `addresses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `announcements`
--

DROP TABLE IF EXISTS `announcements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `announcements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `pluginId` int DEFAULT NULL,
  `heading` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `unread` tinyint(1) NOT NULL DEFAULT '1',
  `dateRead` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_vvbxbikhfgjpkaolrzcsuwwrniofzcycwjrd` (`userId`,`unread`,`dateRead`,`dateCreated`),
  KEY `idx_nzalaehptjfnydeiadiowjrnybsitufdwfpj` (`dateRead`),
  KEY `fk_aecxxqkojgorqbbbgfcnatkpteayxzrvsedw` (`pluginId`),
  CONSTRAINT `fk_aecxxqkojgorqbbbgfcnatkpteayxzrvsedw` FOREIGN KEY (`pluginId`) REFERENCES `plugins` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_knwcfuztcpmgkvzoalkfhtzclnhiaxcflxjn` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `announcements`
--

LOCK TABLES `announcements` WRITE;
/*!40000 ALTER TABLE `announcements` DISABLE KEYS */;
/*!40000 ALTER TABLE `announcements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assetindexdata`
--

DROP TABLE IF EXISTS `assetindexdata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assetindexdata` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sessionId` int NOT NULL,
  `volumeId` int NOT NULL,
  `uri` text,
  `size` bigint unsigned DEFAULT NULL,
  `timestamp` datetime DEFAULT NULL,
  `isDir` tinyint(1) DEFAULT '0',
  `recordId` int DEFAULT NULL,
  `isSkipped` tinyint(1) DEFAULT '0',
  `inProgress` tinyint(1) DEFAULT '0',
  `completed` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_wipvfldnwbytemqbddwpltvnmnnpjyibsawj` (`sessionId`,`volumeId`),
  KEY `idx_hfpbirnkmifjqqekzgfvyzwihpbuabfbrtbd` (`volumeId`),
  CONSTRAINT `fk_kzoncsmvizfvaxbjhehrtexdhkwlsjxdcxnz` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wddfvjqtxgkrdlkcoherzyqugsguzgjkoxbs` FOREIGN KEY (`sessionId`) REFERENCES `assetindexingsessions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assetindexdata`
--

LOCK TABLES `assetindexdata` WRITE;
/*!40000 ALTER TABLE `assetindexdata` DISABLE KEYS */;
/*!40000 ALTER TABLE `assetindexdata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assetindexingsessions`
--

DROP TABLE IF EXISTS `assetindexingsessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assetindexingsessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `indexedVolumes` text,
  `totalEntries` int DEFAULT NULL,
  `processedEntries` int NOT NULL DEFAULT '0',
  `cacheRemoteImages` tinyint(1) DEFAULT NULL,
  `listEmptyFolders` tinyint(1) DEFAULT '0',
  `isCli` tinyint(1) DEFAULT '0',
  `actionRequired` tinyint(1) DEFAULT '0',
  `processIfRootEmpty` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assetindexingsessions`
--

LOCK TABLES `assetindexingsessions` WRITE;
/*!40000 ALTER TABLE `assetindexingsessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `assetindexingsessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assets`
--

DROP TABLE IF EXISTS `assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assets` (
  `id` int NOT NULL,
  `volumeId` int DEFAULT NULL,
  `folderId` int NOT NULL,
  `uploaderId` int DEFAULT NULL,
  `filename` varchar(255) NOT NULL,
  `kind` varchar(50) NOT NULL DEFAULT 'unknown',
  `alt` text,
  `width` int unsigned DEFAULT NULL,
  `height` int unsigned DEFAULT NULL,
  `size` bigint unsigned DEFAULT NULL,
  `focalPoint` varchar(13) DEFAULT NULL,
  `deletedWithVolume` tinyint(1) DEFAULT NULL,
  `keptFile` tinyint(1) DEFAULT NULL,
  `dateModified` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_ozikipzhrlgaxjcwzrcgizrfcxgzhelxhetg` (`filename`,`folderId`),
  KEY `idx_zaiqkibhjczggcionqkhbskdkqgasagcopwo` (`folderId`),
  KEY `idx_uhnjzfzmgctddhaqexrsgowgzubylkmrkifj` (`volumeId`),
  KEY `fk_xwowiazccvshkadikzxoazckoexxhcpenmac` (`uploaderId`),
  CONSTRAINT `fk_bpwsvbgrkwybcjfynrgrdmxiwpdcvortnvmp` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_qdjfqpngggwkpeamfuifrwdfogqiwnbrefuw` FOREIGN KEY (`folderId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_urxyjcscmwhtitsqlvgmamsefubskwwnczif` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xwowiazccvshkadikzxoazckoexxhcpenmac` FOREIGN KEY (`uploaderId`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assets`
--

LOCK TABLES `assets` WRITE;
/*!40000 ALTER TABLE `assets` DISABLE KEYS */;
/*!40000 ALTER TABLE `assets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` int NOT NULL,
  `groupId` int NOT NULL,
  `parentId` int DEFAULT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_vsohxkbcqgapftzhjnixepdotojiufvsafbw` (`groupId`),
  KEY `fk_gsdqcgwfudxypugynrtfphsdqfqixknsdbqp` (`parentId`),
  CONSTRAINT `fk_gsdqcgwfudxypugynrtfphsdqfqixknsdbqp` FOREIGN KEY (`parentId`) REFERENCES `categories` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_nhzmwdgffnjrndyqbjuahrtiogrcdyprhrif` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_nzszhzeroerxglocbrzggwwzocjkvjokufmh` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categorygroups`
--

DROP TABLE IF EXISTS `categorygroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categorygroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_iuwgmtchodgpfygmrxcoztgiaercpporqmkz` (`name`),
  KEY `idx_ckmltzzwmzilefbploztspdsruwggfsqvpjx` (`handle`),
  KEY `idx_aqgmnrflqreigwgvnwwytdqzvibvdwnspifg` (`structureId`),
  KEY `idx_emxyphndvlsnlzhyvchlwvnkzsfkmoaotzqh` (`fieldLayoutId`),
  KEY `idx_jrdnecgbsbxhegzmgtbksggvishvzzyumgzu` (`dateDeleted`),
  CONSTRAINT `fk_iqzmsdnipgmhljqdapkecpwjllposkxkbsol` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xmogrhpcskdwuuiskdbrhrmodcidpbeezhpc` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorygroups`
--

LOCK TABLES `categorygroups` WRITE;
/*!40000 ALTER TABLE `categorygroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `categorygroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categorygroups_sites`
--

DROP TABLE IF EXISTS `categorygroups_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categorygroups_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `siteId` int NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_fewrkdjqoofqomiehyqfsfpjmrjyknfdhqsy` (`groupId`,`siteId`),
  KEY `idx_goasnjluzsgqsfcbtowbyfvjwqensjbqysnv` (`siteId`),
  CONSTRAINT `fk_qwedcjwotclmkfcirirtdpafhjrelsfvjake` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_slnhoamhzwpqrudkajjnkgrlupjqxwlzyclm` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorygroups_sites`
--

LOCK TABLES `categorygroups_sites` WRITE;
/*!40000 ALTER TABLE `categorygroups_sites` DISABLE KEYS */;
/*!40000 ALTER TABLE `categorygroups_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `changedattributes`
--

DROP TABLE IF EXISTS `changedattributes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `changedattributes` (
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `attribute` varchar(255) NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`attribute`),
  KEY `idx_mayvzngfuhmyqddgffgkvsjkolmermzmrmbb` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_nngqyyvddequajydujlhinsnqfucfdluhxrm` (`siteId`),
  KEY `fk_yyduopdxpyaijgqcpixvpymfqlmwouunmzpi` (`userId`),
  CONSTRAINT `fk_iajxhatdhesxhksgbbzhuavxxyarzliyscsh` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_nngqyyvddequajydujlhinsnqfucfdluhxrm` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_yyduopdxpyaijgqcpixvpymfqlmwouunmzpi` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `changedattributes`
--

LOCK TABLES `changedattributes` WRITE;
/*!40000 ALTER TABLE `changedattributes` DISABLE KEYS */;
INSERT INTO `changedattributes` VALUES (1,1,'firstName','2023-11-09 16:03:43',0,1),(1,1,'fullName','2023-11-09 16:03:43',0,1),(1,1,'lastName','2023-11-09 16:03:43',0,1),(2,1,'postDate','2023-11-04 15:29:41',0,1),(2,1,'slug','2023-11-04 15:29:21',0,1),(2,1,'title','2023-11-04 15:29:21',0,1),(2,1,'uri','2023-11-04 15:29:21',0,1),(4,1,'authorId','2023-11-11 12:12:33',0,121),(4,1,'postDate','2023-11-04 15:30:31',0,1),(4,1,'slug','2023-11-04 15:30:26',0,1),(4,1,'title','2023-11-04 15:30:26',0,1),(4,1,'uri','2023-11-04 15:30:26',0,1),(6,1,'authorId','2023-11-11 12:12:24',0,121),(6,1,'postDate','2023-11-04 15:30:46',0,1),(6,1,'slug','2023-11-04 15:30:40',0,1),(6,1,'title','2023-11-04 15:30:40',0,1),(6,1,'uri','2023-11-04 15:30:40',0,1),(9,1,'authorId','2023-11-11 10:23:58',0,1),(9,1,'postDate','2023-11-04 15:31:26',0,1),(9,1,'slug','2023-11-04 15:31:06',0,1),(9,1,'title','2023-11-04 15:31:06',0,1),(9,1,'uri','2023-11-04 15:31:06',0,1),(11,1,'postDate','2023-11-04 15:31:59',0,1),(11,1,'slug','2023-11-04 15:31:32',0,1),(11,1,'title','2023-11-04 15:31:32',0,1),(11,1,'uri','2023-11-04 15:31:32',0,1),(13,1,'postDate','2023-11-04 15:34:00',0,1),(13,1,'slug','2023-11-04 15:33:56',0,1),(13,1,'title','2023-11-04 15:33:56',0,1),(13,1,'uri','2023-11-04 15:33:56',0,1),(15,1,'postDate','2023-11-04 15:34:09',0,1),(15,1,'slug','2023-11-04 15:34:06',0,1),(15,1,'title','2023-11-04 15:34:06',0,1),(15,1,'uri','2023-11-04 15:34:06',0,1),(18,1,'postDate','2023-11-04 15:34:33',0,1),(18,1,'slug','2023-11-04 15:34:33',0,1),(18,1,'title','2023-11-04 15:34:32',0,1),(18,1,'uri','2023-11-04 15:34:33',0,1),(24,1,'postDate','2023-11-04 15:36:33',0,1),(24,1,'slug','2023-11-04 15:36:34',0,1),(24,1,'title','2023-11-04 15:36:33',0,1),(24,1,'uri','2023-11-04 15:36:34',0,1),(31,1,'postDate','2023-11-04 15:38:04',0,1),(31,1,'slug','2023-11-04 15:37:44',0,1),(31,1,'title','2023-11-04 15:37:44',0,1),(31,1,'uri','2023-11-04 15:37:44',0,1),(33,1,'postDate','2023-11-04 15:38:38',0,1),(33,1,'slug','2023-11-04 15:38:24',0,1),(33,1,'title','2023-11-04 15:38:24',0,1),(33,1,'uri','2023-11-04 15:38:24',0,1),(37,1,'postDate','2023-11-04 15:39:19',0,1),(37,1,'slug','2023-11-04 15:38:52',0,1),(37,1,'title','2023-11-04 15:38:52',0,1),(37,1,'uri','2023-11-04 15:38:52',0,1),(38,1,'postDate','2023-11-04 15:39:06',0,1),(38,1,'slug','2023-11-04 15:39:06',0,1),(38,1,'title','2023-11-04 15:39:01',0,1),(38,1,'uri','2023-11-04 15:39:06',0,1),(41,1,'postDate','2023-11-04 15:39:48',0,1),(41,1,'slug','2023-11-04 15:39:24',0,1),(41,1,'title','2023-11-04 15:39:48',0,1),(41,1,'uri','2023-11-04 15:39:24',0,1),(51,1,'postDate','2023-11-04 15:41:31',0,1),(51,1,'slug','2023-11-04 15:41:13',0,1),(51,1,'title','2023-11-04 15:41:13',0,1),(51,1,'uri','2023-11-04 15:41:13',0,1),(67,1,'postDate','2023-11-04 15:42:35',0,1),(67,1,'slug','2023-11-04 15:42:28',0,1),(67,1,'title','2023-11-04 15:42:28',0,1),(67,1,'uri','2023-11-04 15:42:28',0,1),(75,1,'title','2023-11-04 15:43:14',0,1),(83,1,'authorId','2023-11-11 10:22:20',0,1),(83,1,'postDate','2023-11-04 15:43:53',0,1),(83,1,'slug','2023-11-04 15:43:36',0,1),(83,1,'title','2023-11-04 15:43:36',0,1),(83,1,'uri','2023-11-04 15:43:36',0,1),(85,1,'authorId','2023-11-11 10:22:59',0,1),(85,1,'title','2023-11-11 10:22:59',0,1),(87,1,'authorId','2023-11-11 10:23:22',0,1),(89,1,'authorId','2023-11-09 17:40:09',0,1),(91,1,'authorId','2023-11-11 10:23:42',0,1),(93,1,'authorId','2023-11-09 17:34:47',0,1),(95,1,'authorId','2023-11-09 17:34:59',0,1),(118,1,'authorId','2023-11-11 12:12:15',0,121),(118,1,'postDate','2023-11-09 08:46:03',0,1),(118,1,'slug','2023-11-09 08:46:03',0,1),(118,1,'title','2023-11-09 08:45:51',0,1),(118,1,'uri','2023-11-09 08:46:03',0,1),(120,1,'lastPasswordChangeDate','2023-11-09 16:00:31',0,120),(120,1,'password','2023-11-09 16:00:31',0,120),(121,1,'admin','2023-11-15 18:48:37',0,1),(121,1,'lastPasswordChangeDate','2023-11-11 12:04:47',0,121),(121,1,'password','2023-11-11 12:04:47',0,121),(133,1,'authorId','2023-11-10 09:31:16',0,1),(133,1,'postDate','2023-11-10 09:31:06',0,1),(133,1,'slug','2023-11-10 09:30:25',0,1),(133,1,'title','2023-11-10 09:30:25',0,1),(133,1,'uri','2023-11-10 09:30:25',0,1),(134,1,'postDate','2023-11-10 09:30:50',0,1),(134,1,'slug','2023-11-10 09:30:50',0,1),(134,1,'title','2023-11-10 09:30:42',0,1),(134,1,'uri','2023-11-10 09:30:50',0,1),(170,1,'authorId','2023-11-12 16:40:43',0,1),(172,1,'authorId','2023-11-12 16:41:15',0,1),(176,1,'authorId','2023-11-12 16:41:25',0,1),(186,1,'authorId','2023-11-12 16:43:15',0,1),(205,1,'title','2023-11-15 19:35:04',0,121);
/*!40000 ALTER TABLE `changedattributes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `changedfields`
--

DROP TABLE IF EXISTS `changedfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `changedfields` (
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `fieldId` int NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`fieldId`),
  KEY `idx_ybdijtobsivwjjuopjzemrzdsmtrsyggjuxx` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_oufbfqqrpdircbwzfzbebljwywblhkoflrhg` (`siteId`),
  KEY `fk_dpcbizuaceuqyjpyiisqtminpopfadmcqpwn` (`fieldId`),
  KEY `fk_cojhrvbhtaswenludfyrwimtlaroqrnwflfx` (`userId`),
  CONSTRAINT `fk_cojhrvbhtaswenludfyrwimtlaroqrnwflfx` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_dpcbizuaceuqyjpyiisqtminpopfadmcqpwn` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_oufbfqqrpdircbwzfzbebljwywblhkoflrhg` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tzwuwwqsnsfflpebgvbuoedieebwcowmakce` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `changedfields`
--

LOCK TABLES `changedfields` WRITE;
/*!40000 ALTER TABLE `changedfields` DISABLE KEYS */;
INSERT INTO `changedfields` VALUES (1,1,7,'2023-11-09 16:03:43',0,1),(2,1,3,'2023-11-04 15:54:32',0,1),(2,1,4,'2023-11-04 15:29:38',0,1),(2,1,8,'2023-11-04 15:34:40',0,1),(2,1,10,'2023-11-04 15:34:40',0,1),(2,1,11,'2023-11-04 15:36:17',0,1),(4,1,1,'2023-11-04 15:30:29',0,1),(4,1,5,'2023-11-04 15:30:30',0,1),(4,1,12,'2023-11-11 09:06:32',0,1),(4,1,13,'2023-11-11 09:06:32',0,1),(6,1,1,'2023-11-04 15:30:44',0,1),(6,1,5,'2023-11-04 15:30:45',0,1),(6,1,12,'2023-11-11 09:05:55',0,1),(6,1,13,'2023-11-11 09:05:55',0,1),(9,1,3,'2023-11-11 10:23:58',0,1),(9,1,4,'2023-11-04 15:37:26',0,1),(9,1,8,'2023-11-04 15:31:11',0,1),(9,1,10,'2023-11-04 15:36:50',0,1),(9,1,11,'2023-11-04 15:36:50',0,1),(11,1,3,'2023-11-10 10:20:07',0,1),(11,1,4,'2023-11-10 10:20:07',0,1),(11,1,8,'2023-11-04 15:31:34',0,1),(11,1,10,'2023-11-04 15:37:01',0,1),(11,1,11,'2023-11-04 15:37:01',0,1),(13,1,8,'2023-11-04 15:33:59',0,1),(15,1,8,'2023-11-04 15:34:08',0,1),(31,1,3,'2023-11-04 15:38:03',0,1),(31,1,4,'2023-11-04 15:37:57',0,1),(31,1,8,'2023-11-04 15:37:46',0,1),(31,1,10,'2023-11-04 15:37:51',0,1),(31,1,11,'2023-11-04 15:37:48',0,1),(33,1,3,'2023-11-04 15:38:45',0,1),(33,1,4,'2023-11-04 15:38:35',0,1),(33,1,8,'2023-11-04 15:38:26',0,1),(33,1,10,'2023-11-04 15:38:32',0,1),(33,1,11,'2023-11-04 15:38:28',0,1),(37,1,3,'2023-11-04 15:39:18',0,1),(37,1,4,'2023-11-04 15:39:16',0,1),(37,1,8,'2023-11-04 15:38:54',0,1),(37,1,10,'2023-11-04 15:39:11',0,1),(37,1,11,'2023-11-04 15:39:07',0,1),(38,1,8,'2023-11-04 15:39:05',0,1),(41,1,3,'2023-11-04 15:39:47',0,1),(41,1,4,'2023-11-04 15:39:38',0,1),(41,1,8,'2023-11-04 15:39:26',0,1),(41,1,10,'2023-11-04 15:39:31',0,1),(41,1,11,'2023-11-04 15:39:29',0,1),(51,1,3,'2023-11-04 15:41:27',0,1),(51,1,4,'2023-11-04 15:41:25',0,1),(51,1,8,'2023-11-04 15:41:15',0,1),(51,1,10,'2023-11-04 15:41:20',0,1),(51,1,11,'2023-11-04 15:41:17',0,1),(57,1,3,'2023-11-04 17:19:47',0,1),(67,1,3,'2023-11-04 15:42:51',0,1),(67,1,4,'2023-11-04 15:42:14',0,1),(67,1,8,'2023-11-04 15:42:22',0,1),(67,1,10,'2023-11-04 15:42:17',0,1),(67,1,11,'2023-11-04 15:42:19',0,1),(73,1,3,'2023-11-04 17:13:15',0,1),(75,1,3,'2023-11-10 09:27:01',0,1),(75,1,4,'2023-11-04 15:43:14',0,1),(77,1,3,'2023-11-04 17:13:06',0,1),(83,1,3,'2023-11-11 10:20:54',0,1),(83,1,4,'2023-11-04 15:43:45',0,1),(83,1,8,'2023-11-11 10:22:20',0,1),(83,1,10,'2023-11-11 10:22:20',0,1),(83,1,11,'2023-11-04 15:43:40',0,1),(85,1,3,'2023-11-11 10:22:59',0,1),(85,1,4,'2023-11-11 10:22:59',0,1),(85,1,8,'2023-11-11 10:22:59',0,1),(85,1,10,'2023-11-11 10:22:59',0,1),(87,1,3,'2023-11-11 10:23:22',0,1),(89,1,3,'2023-11-04 17:13:47',0,1),(91,1,3,'2023-11-11 10:23:42',0,1),(93,1,3,'2023-11-04 16:21:02',0,1),(93,1,4,'2023-11-09 17:51:26',0,1),(93,1,8,'2023-11-09 17:34:47',0,1),(95,1,3,'2023-11-11 10:21:29',0,1),(95,1,8,'2023-11-11 10:21:13',0,1),(95,1,10,'2023-11-11 10:21:13',0,1),(118,1,1,'2023-11-15 19:00:09',0,121),(118,1,5,'2023-11-15 19:00:09',0,121),(118,1,12,'2023-11-11 09:06:17',0,1),(118,1,13,'2023-11-11 09:06:17',0,1),(120,1,7,'2023-11-09 16:01:20',0,120),(121,1,7,'2023-11-15 18:48:37',0,1),(133,1,3,'2023-11-10 09:31:05',0,1),(133,1,4,'2023-11-10 09:30:58',0,1),(133,1,8,'2023-11-10 09:30:34',0,1),(133,1,10,'2023-11-10 09:30:55',0,1),(133,1,11,'2023-11-10 09:30:53',0,1),(134,1,8,'2023-11-10 09:30:49',0,1),(205,1,8,'2023-11-15 19:35:04',0,121),(208,1,8,'2023-11-15 19:28:48',0,121),(220,1,8,'2023-11-15 19:34:51',0,121);
/*!40000 ALTER TABLE `changedfields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `content`
--

DROP TABLE IF EXISTS `content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `content` (
  `id` int NOT NULL AUTO_INCREMENT,
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  `field_venueCurrencyType_eowtagfq` text,
  `field_visitStart_zzxlubly` datetime DEFAULT NULL,
  `field_visitLanguage_akixlfui` text,
  `field_venueTicketPrice_odumgdut` decimal(12,2) DEFAULT NULL,
  `field_companyName_tcownruz` text,
  `field_venueOpeningTime_xsmoaddn` time DEFAULT NULL,
  `field_venueClosingTime_hjwvgxqr` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_pmcwybmtztsmxhwxixmyngzvgecwuqeyrtav` (`elementId`,`siteId`),
  KEY `idx_xqlutxblqtossrgbqqkzbufrftcbhkzokuxx` (`siteId`),
  KEY `idx_isvilalwpvbeypjhxjxisoedktozkjfgbgcn` (`title`),
  CONSTRAINT `fk_tzxumigxnqoaojsfwofewudbeobvsjcwyfby` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zoidghmrequxapuieijralgukzmraifoubia` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=225 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `content`
--

LOCK TABLES `content` WRITE;
/*!40000 ALTER TABLE `content` DISABLE KEYS */;
INSERT INTO `content` VALUES (1,1,1,NULL,'2023-11-04 14:04:30','2023-11-09 16:03:43','a8e13987-19db-47af-9d2c-fa7456327efb',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(2,2,1,'Entry 1','2023-11-04 15:29:16','2023-11-04 15:54:32','45ca69ee-49ee-49c8-8124-debab68b9908',NULL,'2023-11-05 00:00:00','ba',NULL,NULL,NULL,NULL),(3,3,1,'Entry 1','2023-11-04 15:29:41','2023-11-04 15:29:41','d7913382-526e-47a8-986d-cef9702273b5',NULL,'2023-11-04 00:00:00','ba',NULL,NULL,NULL,NULL),(4,4,1,'Hub 367','2023-11-04 15:30:16','2023-11-11 12:12:33','69c24034-8271-4648-9745-e548ebff6f95','BAM',NULL,NULL,10.00,NULL,'08:00:00','20:00:00'),(5,5,1,'Hub 367','2023-11-04 15:30:31','2023-11-04 15:30:31','2c3f1630-101f-463e-8b57-6443d5a11a48','BAM',NULL,NULL,10.00,NULL,NULL,NULL),(6,6,1,'Diocletian Museum','2023-11-04 15:30:34','2023-11-11 12:12:24','23b993c0-6bbb-463f-a7fc-3bc851faa1a8','Kuna',NULL,NULL,10.00,NULL,'08:00:00','18:00:00'),(7,7,1,'Diocletian Museum','2023-11-04 15:30:46','2023-11-04 15:30:46','28b37f9b-e9a2-453b-8f2a-0de0cee9f57e','Kuna',NULL,NULL,10.00,NULL,NULL,NULL),(8,8,1,NULL,'2023-11-04 15:30:53','2023-11-04 15:30:53','01099900-8d66-4a46-8408-123bca521337',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(9,9,1,'Entry 2','2023-11-04 15:31:02','2023-11-11 10:23:58','7d63d44e-e24a-42a2-95b0-c7321e3a7c12',NULL,'2023-11-11 11:30:00','cr',NULL,NULL,NULL,NULL),(10,10,1,'Entry 2','2023-11-04 15:31:26','2023-11-04 15:31:26','3255132f-702e-4d8c-bc1a-a6076252ee55',NULL,'2023-11-04 00:00:00','CR',NULL,NULL,NULL,NULL),(11,11,1,'Entry 3','2023-11-04 15:31:28','2023-11-10 10:20:07','e810b52f-5362-4adb-b660-242bd7a563f1',NULL,'2023-11-11 09:30:00','pt',NULL,NULL,NULL,NULL),(12,12,1,'Entry 3','2023-11-04 15:31:59','2023-11-04 15:31:59','12c4cc43-f63c-4750-8038-bddca22eb61e',NULL,'2023-11-04 09:30:00','fr',NULL,NULL,NULL,NULL),(13,13,1,'Headset 1','2023-11-04 15:33:52','2023-11-04 15:34:00','613f102f-2fb8-4038-9fbf-bc71c586e9f3',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(14,14,1,'Headset 1','2023-11-04 15:34:00','2023-11-04 15:34:00','9645c6b5-074f-466c-98f1-caa22f7d0a80',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(15,15,1,'Headset 2','2023-11-04 15:34:02','2023-11-04 15:34:09','241847d6-948b-4e8c-b063-73e62e6e1afb',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(16,16,1,'Headset 2','2023-11-04 15:34:09','2023-11-04 15:34:09','a52c82a8-ab07-47b5-977f-9b8d6b708f39',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(18,18,1,'Echoes of Sarajevo','2023-11-04 15:34:26','2023-11-04 15:34:33','9ec6848e-38e2-466d-bb82-3fee3adf7f3b',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(19,19,1,'Echoes of Sarajevo','2023-11-04 15:34:33','2023-11-04 15:34:33','6074db14-04e4-4f42-85ef-fa347ed8379c',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(20,20,1,'Entry 1','2023-11-04 15:34:40','2023-11-04 15:34:40','8c1e2290-e38c-4a0a-bfe0-13bc49b78c5a',NULL,'2023-11-04 00:00:00','ba',NULL,NULL,NULL,NULL),(22,22,1,'Entry 1','2023-11-04 15:36:17','2023-11-04 15:36:17','b5ecbbb8-2132-48f8-a7a7-f6e6823168e1',NULL,'2023-11-04 00:00:00','ba',NULL,NULL,NULL,NULL),(24,24,1,'Diocletian\'s Dream','2023-11-04 15:36:27','2023-11-04 15:36:34','1d4e8961-ef7e-45e4-80d0-d72d6f805dea',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(25,25,1,'Diocletian\'s Dream','2023-11-04 15:36:34','2023-11-04 15:36:34','f02e9f04-6cef-4c10-8c9d-5612290327d0',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(26,26,1,'Entry 2','2023-11-04 15:36:50','2023-11-04 15:36:50','c760cbc0-ace7-44f1-b947-b6326418fe03',NULL,'2023-11-04 11:30:00','CR',NULL,NULL,NULL,NULL),(28,28,1,'Entry 3','2023-11-04 15:37:01','2023-11-04 15:37:01','1dc8e0f0-d464-4500-bbde-69a31cddf319',NULL,'2023-11-04 09:30:00','fr',NULL,NULL,NULL,NULL),(30,30,1,'Entry 2','2023-11-04 15:37:25','2023-11-04 15:37:25','89fd16af-3f53-446f-904e-118264661138',NULL,'2023-11-04 11:30:00','cr',NULL,NULL,NULL,NULL),(31,31,1,'Entry 4','2023-11-04 15:37:41','2023-11-04 15:38:04','004c298a-912f-4416-b777-af80c1bbbebf',NULL,'2023-11-04 13:30:00','cr',NULL,NULL,NULL,NULL),(32,32,1,'Entry 4','2023-11-04 15:38:04','2023-11-04 15:38:04','61b1fb67-28d6-4968-9c48-72fbcdde4bbf',NULL,'2023-11-04 13:30:00','cr',NULL,NULL,NULL,NULL),(33,33,1,'Entry 5 BA','2023-11-04 15:38:19','2023-11-04 15:38:45','6368d9dc-6f26-43f3-964c-7ec461444e0d',NULL,'2023-11-03 10:00:00','ba',NULL,NULL,NULL,NULL),(34,34,1,'Entry 5 BA','2023-11-04 15:38:38','2023-11-04 15:38:38','906b2d6a-f768-409b-ae6d-038216fec1d1',NULL,'2023-11-03 00:00:00','ba',NULL,NULL,NULL,NULL),(36,36,1,'Entry 5 BA','2023-11-04 15:38:45','2023-11-04 15:38:45','d53eed7f-c463-43d3-a3ca-b3303668362c',NULL,'2023-11-03 10:00:00','ba',NULL,NULL,NULL,NULL),(37,37,1,'Entry 6 BA','2023-11-04 15:38:47','2023-11-04 15:39:19','c00c96fe-932d-4edc-8938-9e634cf53d7b',NULL,'2023-11-03 00:00:00','en',NULL,NULL,NULL,NULL),(38,38,1,'Headset 2','2023-11-04 15:38:56','2023-11-04 15:39:06','b74ac3a0-5452-46af-a787-106986f55429',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(39,39,1,'Headset 2','2023-11-04 15:39:06','2023-11-04 15:39:06','421cb021-223f-4e7d-8175-897b73bc3e37',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(40,40,1,'Entry 6 BA','2023-11-04 15:39:19','2023-11-04 15:39:19','b34896bd-4f47-4770-b6d7-59d38f30a80a',NULL,'2023-11-03 00:00:00','en',NULL,NULL,NULL,NULL),(41,41,1,'Entry 7','2023-11-04 15:39:21','2023-11-04 15:39:48','8cd47ff4-98d6-4609-9ad0-bf0cc250ec6f',NULL,'2023-11-02 10:00:00','de',NULL,NULL,NULL,NULL),(42,42,1,'Entry 7','2023-11-04 15:39:48','2023-11-04 15:39:48','1f2b66c3-629a-4f29-883f-e1b4700b7636',NULL,'2023-11-02 10:00:00','de',NULL,NULL,NULL,NULL),(43,43,1,'Entry 6 BA','2023-11-04 15:40:11','2023-11-04 15:40:11','513dd773-7349-427b-92cc-cf2d22edca0f',NULL,'2023-11-03 00:00:00','en',NULL,NULL,NULL,NULL),(44,44,1,'Entry 6 BA','2023-11-04 15:40:12','2023-11-04 15:40:12','29ffedbd-0507-48ba-b90b-e5c2dd382d2d',NULL,'2023-11-03 00:00:00','en',NULL,NULL,NULL,NULL),(45,45,1,'Entry 7','2023-11-04 15:40:12','2023-11-04 15:40:12','c3f12b90-d8c1-40c4-8724-f78f0d57fa08',NULL,'2023-11-02 10:00:00','de',NULL,NULL,NULL,NULL),(46,46,1,'Entry 7','2023-11-04 15:40:12','2023-11-04 15:40:12','eba65e86-8976-47e4-aa28-bb80c99bda28',NULL,'2023-11-02 10:00:00','de',NULL,NULL,NULL,NULL),(47,47,1,'Entry 6 BA','2023-11-04 15:40:50','2023-11-04 15:40:50','10fe0914-d264-420a-93ed-625133f36977',NULL,'2023-11-03 00:00:00','en',NULL,NULL,NULL,NULL),(48,48,1,'Entry 6 BA','2023-11-04 15:40:50','2023-11-04 15:40:50','960e98ea-0c77-44a2-ba2c-7f2ac787b9de',NULL,'2023-11-03 00:00:00','en',NULL,NULL,NULL,NULL),(49,49,1,'Entry 7','2023-11-04 15:40:50','2023-11-04 15:40:50','0ab68d8d-ccab-4aed-9abb-b236c88bce9e',NULL,'2023-11-02 10:00:00','de',NULL,NULL,NULL,NULL),(50,50,1,'Entry 7','2023-11-04 15:40:50','2023-11-04 15:40:50','4ae6256b-c62a-41d3-afcc-50435c657983',NULL,'2023-11-02 10:00:00','de',NULL,NULL,NULL,NULL),(51,51,1,'Entry ES','2023-11-04 15:41:09','2023-11-04 15:41:31','4529913a-ad91-4f7f-877b-2ee099260ad4',NULL,'2023-11-01 09:30:00','es',NULL,NULL,NULL,NULL),(52,52,1,'Entry ES','2023-11-04 15:41:31','2023-11-04 15:41:31','2ef04170-33cb-48b9-b7d2-0baa564f8c07',NULL,'2023-11-01 09:30:00','es',NULL,NULL,NULL,NULL),(53,53,1,'Entry ES','2023-11-04 15:41:43','2023-11-04 15:41:43','97d64afc-036e-48f3-b571-f30dee0af3b6',NULL,'2023-11-01 09:30:00','es',NULL,NULL,NULL,NULL),(54,54,1,'Entry ES','2023-11-04 15:41:43','2023-11-04 15:41:43','fb07f98a-0c72-479a-ba71-851ee90b2158',NULL,'2023-11-01 09:30:00','es',NULL,NULL,NULL,NULL),(55,55,1,'Entry ES','2023-11-04 15:41:47','2023-11-04 15:41:47','22780cfa-bb20-4c9a-9317-4467d26667bc',NULL,'2023-11-01 09:30:00','es',NULL,NULL,NULL,NULL),(56,56,1,'Entry ES','2023-11-04 15:41:47','2023-11-04 15:41:47','05594ba5-13bb-49b9-b1f9-fb51d9c4276c',NULL,'2023-11-01 09:30:00','es',NULL,NULL,NULL,NULL),(57,57,1,'Entry ES','2023-11-04 15:41:47','2023-11-04 17:19:47','826b6627-4b73-47f2-bc99-97a2cb94e524',NULL,'2023-11-02 09:30:00','es',NULL,NULL,NULL,NULL),(58,58,1,'Entry ES','2023-11-04 15:41:47','2023-11-04 15:41:47','8ac0e1d9-7237-44ff-ac8d-865934aa0fe8',NULL,'2023-11-01 09:30:00','es',NULL,NULL,NULL,NULL),(59,59,1,'Entry ES','2023-11-04 15:41:51','2023-11-04 15:41:51','aecee081-d476-49d8-b413-5b07a5dc313c',NULL,'2023-11-01 09:30:00','es',NULL,NULL,NULL,NULL),(60,60,1,'Entry ES','2023-11-04 15:41:52','2023-11-04 15:41:52','9e510d96-ab4c-44f8-991e-4a76e8794593',NULL,'2023-11-01 09:30:00','es',NULL,NULL,NULL,NULL),(61,61,1,'Entry ES','2023-11-04 15:41:52','2023-11-04 15:41:52','c5bec756-0a85-4140-b3b5-78b496c38f76',NULL,'2023-11-01 09:30:00','es',NULL,NULL,NULL,NULL),(62,62,1,'Entry ES','2023-11-04 15:41:52','2023-11-04 15:41:52','a210362c-9ab3-4340-976e-18fd37d1bc16',NULL,'2023-11-01 09:30:00','es',NULL,NULL,NULL,NULL),(63,63,1,'Entry ES','2023-11-04 15:41:52','2023-11-04 15:41:52','74e25857-c746-4bf7-b878-bcee4aa17b65',NULL,'2023-11-01 09:30:00','es',NULL,NULL,NULL,NULL),(64,64,1,'Entry ES','2023-11-04 15:41:52','2023-11-04 15:41:52','c9813e4e-2d53-4bd6-be4a-7c9afcddb704',NULL,'2023-11-01 09:30:00','es',NULL,NULL,NULL,NULL),(65,65,1,'Entry ES','2023-11-04 15:41:52','2023-11-04 15:41:52','c197f1a5-8f6e-4551-a85c-71b175bf6af6',NULL,'2023-11-01 09:30:00','es',NULL,NULL,NULL,NULL),(66,66,1,'Entry ES','2023-11-04 15:41:52','2023-11-04 15:41:52','d3259fcf-01f5-43f3-9645-668a7f9298b0',NULL,'2023-11-01 09:30:00','es',NULL,NULL,NULL,NULL),(67,67,1,'Entry en','2023-11-04 15:42:07','2023-11-04 15:42:51','97ce5055-ef94-4931-8dad-57af467d7145',NULL,'2023-10-31 14:00:00','en',NULL,NULL,NULL,NULL),(68,68,1,'Entry en','2023-11-04 15:42:35','2023-11-04 15:42:35','d07955eb-7dd4-414d-b08e-3c27735cf437',NULL,'2023-11-01 14:00:00','en',NULL,NULL,NULL,NULL),(69,69,1,'Entry en','2023-11-04 15:42:40','2023-11-04 15:42:40','5e65416b-12a3-4008-9168-fb6e1378fe11',NULL,'2023-11-01 14:00:00','en',NULL,NULL,NULL,NULL),(70,70,1,'Entry en','2023-11-04 15:42:40','2023-11-04 15:42:40','d7dd6c09-a1a3-4b68-ad9c-4fb959dee6c6',NULL,'2023-11-01 14:00:00','en',NULL,NULL,NULL,NULL),(72,72,1,'Entry en','2023-11-04 15:42:51','2023-11-04 15:42:51','3a8db181-601f-493a-be20-67eecc2b7d8f',NULL,'2023-10-31 14:00:00','en',NULL,NULL,NULL,NULL),(73,73,1,'Entry en','2023-11-04 15:42:56','2023-11-04 17:13:15','5799dbde-3477-4020-b6e8-724e90f9265c',NULL,'2023-11-23 14:00:00','en',NULL,NULL,NULL,NULL),(74,74,1,'Entry en','2023-11-04 15:42:56','2023-11-04 15:42:56','657a1145-39f6-4621-9800-cfff39ba8308',NULL,'2023-10-31 14:00:00','en',NULL,NULL,NULL,NULL),(75,75,1,'Entry ba','2023-11-04 15:42:59','2023-11-10 09:27:01','94412d4f-ba2b-4967-8a65-72c342ceadfe',NULL,'2023-11-10 13:00:00','ba',NULL,NULL,NULL,NULL),(76,76,1,'Entry en','2023-11-04 15:42:59','2023-11-04 15:42:59','2093edc8-b077-4a25-a567-7bd47fa235f3',NULL,'2023-10-31 14:00:00','en',NULL,NULL,NULL,NULL),(77,77,1,'Entry en','2023-11-04 15:42:59','2023-11-04 17:13:34','25fe9686-f642-480c-b842-ab8d1a1f87a3',NULL,'2023-11-17 14:00:00','en',NULL,NULL,NULL,NULL),(78,78,1,'Entry en','2023-11-04 15:42:59','2023-11-04 15:42:59','32c91df9-3046-4e99-ac70-7e94af4d4b43',NULL,'2023-11-01 14:00:00','en',NULL,NULL,NULL,NULL),(80,80,1,'Entry ba','2023-11-04 15:43:14','2023-11-04 15:43:14','3aa8f474-cfe7-4caf-bddd-1ac9b4f59745',NULL,'2023-10-30 03:30:00','ba',NULL,NULL,NULL,NULL),(81,81,1,'Entry ba','2023-11-04 15:43:22','2023-11-04 15:43:22','8626f27e-0d1b-4a47-a1ed-a4594b01403b',NULL,'2023-10-30 03:30:00','ba',NULL,NULL,NULL,NULL),(82,82,1,'Entry ba','2023-11-04 15:43:22','2023-11-04 15:43:22','6890d58a-0ae6-4163-bff8-1be57d093572',NULL,'2023-10-30 03:30:00','ba',NULL,NULL,NULL,NULL),(83,83,1,'Entry fr','2023-11-04 15:43:34','2023-11-11 10:22:20','399a1063-def7-4bab-8187-5be9846e6706',NULL,'2023-11-11 17:00:00','fr',NULL,NULL,NULL,NULL),(84,84,1,'Entry fr','2023-11-04 15:43:53','2023-11-04 15:43:53','67ef4aa1-c249-4cc3-ae6b-7c15b6c90869',NULL,'2023-10-30 17:00:00','fr',NULL,NULL,NULL,NULL),(85,85,1,'Entry es','2023-11-04 15:43:57','2023-11-11 10:22:59','29a83f52-14a3-41b9-b6a6-0be827184836',NULL,'2023-11-11 16:00:00','es',NULL,NULL,NULL,NULL),(86,86,1,'Entry fr','2023-11-04 15:43:57','2023-11-04 15:43:57','83c97b8d-4801-44d5-be47-622495c634a4',NULL,'2023-10-30 17:00:00','fr',NULL,NULL,NULL,NULL),(87,87,1,'Entry fr','2023-11-04 15:44:03','2023-11-11 10:23:22','1b56d9cd-00ea-4833-8108-a81e19c1bd2b',NULL,'2023-11-11 17:00:00','fr',NULL,NULL,NULL,NULL),(88,88,1,'Entry fr','2023-11-04 15:44:03','2023-11-04 15:44:03','78e9f6bb-c081-4d50-b4fb-b47b85184684',NULL,'2023-10-30 17:00:00','fr',NULL,NULL,NULL,NULL),(89,89,1,'Entry fr','2023-11-04 15:44:03','2023-11-09 17:40:09','f6d0933a-8955-43f2-ad10-64fb2c80fd0b',NULL,'2023-11-09 17:00:00','fr',NULL,NULL,NULL,NULL),(90,90,1,'Entry fr','2023-11-04 15:44:03','2023-11-04 15:44:03','6f10f0cc-90f5-4ea1-9e46-72de7a83cdcc',NULL,'2023-10-30 17:00:00','fr',NULL,NULL,NULL,NULL),(91,91,1,'Entry fr','2023-11-04 15:44:10','2023-11-11 10:23:42','9c44d190-8426-4704-8b08-7b1e966d6803',NULL,'2023-11-11 14:30:00','fr',NULL,NULL,NULL,NULL),(92,92,1,'Entry fr','2023-11-04 15:44:10','2023-11-04 15:44:10','75492ebb-5bda-497b-9ff6-d67a22c8f6dd',NULL,'2023-10-30 17:00:00','fr',NULL,NULL,NULL,NULL),(93,93,1,'Entry fr','2023-11-04 15:44:10','2023-11-09 17:51:26','1dfb1b52-a57e-4990-bf67-406d2fc541eb',NULL,'2023-11-09 17:00:00','de',NULL,NULL,NULL,NULL),(94,94,1,'Entry fr','2023-11-04 15:44:10','2023-11-04 15:44:10','fbbda734-641d-4085-a5f7-0ba1a0b99f89',NULL,'2023-10-30 17:00:00','fr',NULL,NULL,NULL,NULL),(95,95,1,'Entry fr','2023-11-04 15:44:10','2023-11-11 10:21:29','c20b21a7-dae4-4b12-a48a-6b1fd16f54b9',NULL,'2023-11-11 17:00:00','fr',NULL,NULL,NULL,NULL),(96,96,1,'Entry fr','2023-11-04 15:44:10','2023-11-04 15:44:10','ca0376da-4743-49bb-948a-fc6b30863de4',NULL,'2023-10-30 17:00:00','fr',NULL,NULL,NULL,NULL),(97,97,1,'Entry fr','2023-11-04 15:44:25','2023-11-04 15:44:25','03dddf80-3c33-441c-8722-4eb67c9f2b62',NULL,'2023-10-30 17:00:00','fr',NULL,NULL,NULL,NULL),(99,99,1,'Entry fr','2023-11-04 15:44:34','2023-11-04 15:44:34','7cc6e561-f2ef-4a57-98ea-48f0ab911947',NULL,'2023-10-29 17:00:00','fr',NULL,NULL,NULL,NULL),(101,101,1,'Entry 1','2023-11-04 15:54:32','2023-11-04 15:54:32','ce2bfdd6-bd49-4a4b-a165-ea1e6287df0e',NULL,'2023-11-05 00:00:00','ba',NULL,NULL,NULL,NULL),(103,103,1,'Entry fr','2023-11-04 16:21:02','2023-11-04 16:21:02','a26a3473-2dec-446e-b809-11dd911025f2',NULL,'2023-11-09 17:00:00','fr',NULL,NULL,NULL,NULL),(105,105,1,'Entry en','2023-11-04 17:13:06','2023-11-04 17:13:06','0551876e-49e0-4430-ad54-d339a47faba5',NULL,'2023-11-17 14:00:00','en',NULL,NULL,NULL,NULL),(107,107,1,'Entry en','2023-11-04 17:13:15','2023-11-04 17:13:15','1256ee3e-e241-43b8-8d3e-53f3ed8a6d88',NULL,'2023-11-23 14:00:00','en',NULL,NULL,NULL,NULL),(108,108,1,'Entry en','2023-11-04 17:13:34','2023-11-04 17:13:34','611ebcf4-5bbb-49cd-ad82-41ae75a48d03',NULL,'2023-11-17 14:00:00','en',NULL,NULL,NULL,NULL),(110,110,1,'Entry fr','2023-11-04 17:13:47','2023-11-04 17:13:47','8470a807-866a-41ae-82f5-78968b349773',NULL,'2023-11-09 17:00:00','fr',NULL,NULL,NULL,NULL),(112,112,1,'Entry fr','2023-11-04 17:14:08','2023-11-04 17:14:08','d319a1f6-221c-454c-9cfb-8fcf90ea3019',NULL,'2023-11-16 17:00:00','fr',NULL,NULL,NULL,NULL),(114,114,1,'Entry fr','2023-11-04 17:14:18','2023-11-04 17:14:18','71c705d7-5cae-4c41-89c8-27dc3d97a2a4',NULL,'2023-11-16 17:00:00','fr',NULL,NULL,NULL,NULL),(116,116,1,'Entry ES','2023-11-04 17:19:47','2023-11-04 17:19:47','edd0872a-330e-445a-8631-50e7ea1f9f83',NULL,'2023-11-02 09:30:00','es',NULL,NULL,NULL,NULL),(118,118,1,'Hvar Festival','2023-11-09 08:45:42','2023-11-15 19:00:09','48e8818b-8664-4700-8fee-26aae076eb7e','Kuna',NULL,NULL,15.00,NULL,'09:00:00','16:00:00'),(119,119,1,'Hvar Festival','2023-11-09 08:46:03','2023-11-09 08:46:03','801ba571-54a3-4cbd-ae9f-fb8e80e232de','Kuna',NULL,NULL,20.00,NULL,NULL,NULL),(120,120,1,NULL,'2023-11-09 16:00:00','2023-11-09 16:01:20','602a4376-f664-4d70-bfb6-a4dc51f31517',NULL,NULL,NULL,NULL,'Sarajevo VRX',NULL,NULL),(121,121,1,NULL,'2023-11-09 16:01:08','2023-11-15 18:48:37','6b934362-0a51-4d67-b56d-dae56b6c3201',NULL,NULL,NULL,NULL,'Palace Productions',NULL,NULL),(122,122,1,'Entry fr','2023-11-09 17:34:47','2023-11-09 17:34:47','82607f7a-150b-4301-871f-7452b8be9795',NULL,'2023-11-09 17:00:00','fr',NULL,NULL,NULL,NULL),(124,124,1,'Entry fr','2023-11-09 17:34:59','2023-11-09 17:34:59','c4fc9f33-4040-4f3b-9742-d34f40f3939d',NULL,'2023-10-29 17:00:00','fr',NULL,NULL,NULL,NULL),(126,126,1,'Entry fr','2023-11-09 17:40:09','2023-11-09 17:40:09','5f8bb123-3718-435e-a5b2-c8457e5c5639',NULL,'2023-11-09 17:00:00','fr',NULL,NULL,NULL,NULL),(128,128,1,'Entry fr','2023-11-09 17:51:26','2023-11-09 17:51:26','d9558d61-031e-4ef4-ad4f-3810d74a3dd1',NULL,'2023-11-09 17:00:00','de',NULL,NULL,NULL,NULL),(130,130,1,'Entry fr','2023-11-10 09:26:37','2023-11-10 09:26:37','90bbd01d-8b92-41b1-8e95-85aca7079c08',NULL,'2023-11-09 17:00:00','fr',NULL,NULL,NULL,NULL),(132,132,1,'Entry ba','2023-11-10 09:27:01','2023-11-10 09:27:01','0d636419-5da6-4e8b-9d95-c5b6222c749e',NULL,'2023-11-10 13:00:00','ba',NULL,NULL,NULL,NULL),(133,133,1,'Entry IT','2023-11-10 09:30:11','2023-11-11 10:20:29','172bc645-25b9-4a70-873b-9857b2175b00',NULL,'2023-11-11 11:00:00','it',NULL,NULL,NULL,NULL),(134,134,1,'Headset 3','2023-11-10 09:30:38','2023-11-10 09:30:50','800a3053-4a5c-43ef-b6bd-7f8a05ecc8bb',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(135,135,1,'Headset 3','2023-11-10 09:30:50','2023-11-10 09:30:50','9f8629ea-20dc-4ac4-b7b0-e331c75ebbb3',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(136,136,1,'Entry IT','2023-11-10 09:31:06','2023-11-10 09:31:06','da00088d-84d6-47e5-822f-6771c79e8c65',NULL,'2023-11-11 11:00:00','it',NULL,NULL,NULL,NULL),(138,138,1,'Entry IT','2023-11-10 09:31:16','2023-11-10 09:31:16','d2ac4f78-7a2c-4f9d-aa95-10e5b456643f',NULL,'2023-11-11 11:00:00','it',NULL,NULL,NULL,NULL),(140,140,1,'Entry 3','2023-11-10 10:20:07','2023-11-10 10:20:07','ed4fb3ac-305c-4b2a-a024-47601ca63b20',NULL,'2023-11-11 09:30:00','pt',NULL,NULL,NULL,NULL),(142,142,1,'Diocletian Museum','2023-11-11 09:05:55','2023-11-11 09:05:55','802e8f05-2b20-4e7a-88e5-e0fe69e35627','Kuna',NULL,NULL,10.00,NULL,'08:00:00','18:00:00'),(144,144,1,'Hvar Festival','2023-11-11 09:06:17','2023-11-11 09:06:17','502c0636-d0eb-4777-82bd-7897859d2166','Kuna',NULL,NULL,20.00,NULL,'09:00:00','16:00:00'),(146,146,1,'Hub 367','2023-11-11 09:06:32','2023-11-11 09:06:32','a51dc299-d2a7-4360-bd2b-bbf582b39f7c','BAM',NULL,NULL,10.00,NULL,'08:00:00','20:00:00'),(147,147,1,'Entry IT','2023-11-11 10:20:29','2023-11-11 10:20:29','c462a59a-f85d-43f6-a029-335da845e06b',NULL,'2023-11-11 11:00:00','it',NULL,NULL,NULL,NULL),(149,149,1,'Entry fr','2023-11-11 10:20:54','2023-11-11 10:20:54','661671ec-1d6a-46a8-8c29-4be43e238fb4',NULL,'2023-11-11 17:00:00','fr',NULL,NULL,NULL,NULL),(151,151,1,'Entry fr','2023-11-11 10:21:13','2023-11-11 10:21:13','ec55fdd8-72d7-4629-b64f-612d119585c5',NULL,'2023-10-29 17:00:00','fr',NULL,NULL,NULL,NULL),(153,153,1,'Entry fr','2023-11-11 10:21:29','2023-11-11 10:21:29','eb6b2e78-ca6f-48d5-89d4-10bd2eee03d9',NULL,'2023-11-11 17:00:00','fr',NULL,NULL,NULL,NULL),(155,155,1,'Entry fr','2023-11-11 10:22:20','2023-11-11 10:22:20','a4421ea0-7ec4-4137-8c54-00804661bcde',NULL,'2023-11-11 17:00:00','fr',NULL,NULL,NULL,NULL),(157,157,1,'Entry es','2023-11-11 10:22:59','2023-11-11 10:22:59','b69265bc-6f5d-4ce3-aa2d-af76bb7c51a9',NULL,'2023-11-11 16:00:00','es',NULL,NULL,NULL,NULL),(159,159,1,'Entry fr','2023-11-11 10:23:22','2023-11-11 10:23:22','85b3b6d8-dbca-4202-8744-39ea1381877f',NULL,'2023-11-11 17:00:00','fr',NULL,NULL,NULL,NULL),(161,161,1,'Entry fr','2023-11-11 10:23:42','2023-11-11 10:23:42','5b18bb9e-94c9-46ce-b653-8fc804c74d3b',NULL,'2023-11-11 14:30:00','fr',NULL,NULL,NULL,NULL),(163,163,1,'Entry 2','2023-11-11 10:23:58','2023-11-11 10:23:58','92f19720-a30a-45af-bd45-39d1504d4cf0',NULL,'2023-11-11 11:30:00','cr',NULL,NULL,NULL,NULL),(165,165,1,'Hvar Festival','2023-11-11 12:12:15','2023-11-11 12:12:15','e84f7a90-8313-4333-a720-ba66c4d9ab27','Kuna',NULL,NULL,20.00,NULL,'09:00:00','16:00:00'),(167,167,1,'Diocletian Museum','2023-11-11 12:12:24','2023-11-11 12:12:24','3ab541a1-382d-43f6-a8a7-a6dcea14a24c','Kuna',NULL,NULL,10.00,NULL,'08:00:00','18:00:00'),(169,169,1,'Hub 367','2023-11-11 12:12:33','2023-11-11 12:12:33','dce499a8-1bea-4f1b-8f3f-388e2ac8dc71','BAM',NULL,NULL,10.00,NULL,'08:00:00','20:00:00'),(170,170,1,'graphQL entry again','2023-11-12 16:37:46','2023-11-12 16:40:43','a96737f0-0020-4c59-8327-4234cc29f690',NULL,'2023-11-12 10:45:01','en',NULL,NULL,NULL,NULL),(171,171,1,'graphQL entry again','2023-11-12 16:37:46','2023-11-12 16:37:46','5a988b27-b270-4468-876b-b67b8d5071d5',NULL,'2023-11-12 10:45:01','en',NULL,NULL,NULL,NULL),(172,172,1,'graphQL entry again','2023-11-12 16:37:53','2023-11-12 16:41:15','79bdfc74-2fad-4459-8ee8-c07d12fb6805',NULL,'2023-11-12 10:45:01','en',NULL,NULL,NULL,NULL),(173,173,1,'graphQL entry again','2023-11-12 16:37:53','2023-11-12 16:37:53','5d7ddf8a-0a5c-4e5a-a870-c2c54f6e1206',NULL,'2023-11-12 10:45:01','en',NULL,NULL,NULL,NULL),(175,175,1,'graphQL entry again','2023-11-12 16:39:01','2023-11-12 16:39:01','1870d624-0166-4b1e-bad2-f14254853566',NULL,'2023-11-12 10:45:01','en',NULL,NULL,NULL,NULL),(176,176,1,'graphQL entry again','2023-11-12 16:40:16','2023-11-12 16:41:25','4da2df3b-850a-488a-abf1-3851e8c86ed3',NULL,'2023-11-12 10:45:01','en',NULL,NULL,NULL,NULL),(177,177,1,'graphQL entry again','2023-11-12 16:40:16','2023-11-12 16:40:16','0ef08bd6-d1a4-4380-a773-f478ca297d0a',NULL,'2023-11-12 10:45:01','en',NULL,NULL,NULL,NULL),(179,179,1,'graphQL entry again','2023-11-12 16:40:43','2023-11-12 16:40:43','38e206c4-16f2-454b-bac3-ed5cb74e2a28',NULL,'2023-11-12 10:45:01','en',NULL,NULL,NULL,NULL),(181,181,1,'graphQL entry again','2023-11-12 16:41:15','2023-11-12 16:41:15','15add723-bbe3-4a30-8d0b-61d4afdab228',NULL,'2023-11-12 10:45:01','en',NULL,NULL,NULL,NULL),(183,183,1,'graphQL entry again','2023-11-12 16:41:25','2023-11-12 16:41:25','eddd68f3-54f3-4064-a0c6-82f3444e718a',NULL,'2023-11-12 10:45:01','en',NULL,NULL,NULL,NULL),(186,186,1,'graphQL entry again','2023-11-12 16:42:21','2023-11-12 16:43:15','715d2359-8096-4e0e-9f48-4989623b3d95',NULL,'2023-11-12 10:45:01','en',NULL,NULL,NULL,NULL),(187,187,1,'graphQL entry again','2023-11-12 16:42:21','2023-11-12 16:42:21','63c7a214-d972-4a73-990d-09ab8672ad11',NULL,'2023-11-12 10:45:01','en',NULL,NULL,NULL,NULL),(188,188,1,'graphQL entry again','2023-11-12 16:42:50','2023-11-12 16:42:50','4164633e-a85b-470c-9fe8-d77925066b90',NULL,'2023-11-12 10:45:01','en',NULL,NULL,NULL,NULL),(189,189,1,'graphQL entry again','2023-11-12 16:42:50','2023-11-12 16:42:50','f8cdcc4a-2a2e-425f-be1f-9b15dbe45504',NULL,'2023-11-12 10:45:01','en',NULL,NULL,NULL,NULL),(191,191,1,'graphQL entry again','2023-11-12 16:43:15','2023-11-12 16:43:15','8fb9e7f3-dc7b-4464-b50b-c42216b0fb4a',NULL,'2023-11-12 10:45:01','en',NULL,NULL,NULL,NULL),(192,192,1,'graphQL jovana again','2023-11-12 16:43:29','2023-11-12 16:43:29','7bc09cc7-e7de-4cf8-97a6-7378c899070a',NULL,'2023-11-12 10:45:01','en',NULL,NULL,NULL,NULL),(193,193,1,'graphQL jovana again','2023-11-12 16:43:29','2023-11-12 16:43:29','b73d4e4a-2035-44a0-a006-98cbcbfb5d70',NULL,'2023-11-12 10:45:01','en',NULL,NULL,NULL,NULL),(194,194,1,'graphQL jovana again','2023-11-12 16:52:34','2023-11-12 16:52:34','02a5ec62-e068-4aa2-bcfc-b5c8cb20e2de',NULL,'2023-11-12 10:45:01','en',NULL,NULL,NULL,NULL),(195,195,1,'graphQL jovana again','2023-11-12 16:52:34','2023-11-12 16:52:34','cf727bba-2528-45d5-8199-47525f498fd8',NULL,'2023-11-12 10:45:01','en',NULL,NULL,NULL,NULL),(196,196,1,'graphQL jovana again','2023-11-12 16:52:45','2023-11-12 16:52:45','9fe9e7ab-0e4a-4cd6-a559-b48b3d22701b',NULL,'2023-11-12 10:45:01','en',NULL,NULL,NULL,NULL),(197,197,1,'graphQL jovana again','2023-11-12 16:52:45','2023-11-12 16:52:45','7f25a5e8-528b-42a0-b0e0-3ecf884334ac',NULL,'2023-11-12 10:45:01','en',NULL,NULL,NULL,NULL),(198,198,1,'graphQL entry again','2023-11-12 16:53:24','2023-11-12 16:53:24','1a409f40-f1f1-4f88-aa2d-f6d0da6201f9',NULL,'2023-11-11 10:45:01','en',NULL,NULL,NULL,NULL),(199,199,1,'graphQL entry again','2023-11-12 16:53:24','2023-11-12 16:53:24','89f5a2fe-64c3-4f9e-9ef9-dc6b8060efc6',NULL,'2023-11-11 10:45:01','en',NULL,NULL,NULL,NULL),(200,200,1,NULL,'2023-11-13 10:31:55','2023-11-13 10:31:55','07f5063c-7ca7-47b5-8fea-7b2a137c4c73',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(201,201,1,'Hvar Festival','2023-11-15 19:00:00','2023-11-15 19:00:00','673b517d-cb58-4954-9d36-930da3a90709','Kuna',NULL,NULL,10.00,NULL,'09:00:00','16:00:00'),(202,202,1,'Hvar Festival','2023-11-15 19:00:09','2023-11-15 19:00:09','5b848891-0997-4c66-8220-ef99be057707','Kuna',NULL,NULL,15.00,NULL,'09:00:00','16:00:00'),(203,203,1,'test','2023-11-15 19:03:14','2023-11-15 19:03:14','9c44d5b8-4c93-4ccf-904a-ae07c72a0fff','eur',NULL,NULL,20.00,NULL,NULL,NULL),(204,204,1,'test','2023-11-15 19:03:14','2023-11-15 19:03:14','7d727358-c776-48e4-858e-14562204de1c','eur',NULL,NULL,20.00,NULL,NULL,NULL),(205,205,1,'Headset 4','2023-11-15 19:09:48','2023-11-15 19:35:04','6190f81d-d8d3-4314-89ba-97f6b2b55a7c',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(206,206,1,'Headset 4','2023-11-15 19:09:48','2023-11-15 19:09:48','ae1b53cc-7b70-469e-bd2c-22a4ab424754',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(207,207,1,'Headset 4','2023-11-15 19:15:46','2023-11-15 19:15:46','1cd8518b-921e-4fa3-95f5-afe4215954e1',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(208,208,1,'Headset 5','2023-11-15 19:16:48','2023-11-15 19:28:48','0c48d951-5f83-47e6-9ca9-90fdc44a3bd3',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(209,209,1,'Headset 5','2023-11-15 19:16:48','2023-11-15 19:16:48','bb014a6e-186a-47e0-9e0c-de53be69fde4',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(211,211,1,'Headset 5','2023-11-15 19:17:03','2023-11-15 19:17:03','71963c76-830c-40a8-95a0-421cd6a78cfa',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(212,212,1,'Headset 5','2023-11-15 19:19:47','2023-11-15 19:19:47','b3415d55-cf72-43fe-9f0e-2435d6cda77b',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(213,213,1,'Headset 5','2023-11-15 19:19:53','2023-11-15 19:19:53','9b6758b3-c510-4656-bbf8-9c60d90e3281',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(214,214,1,'Headset 4','2023-11-15 19:21:55','2023-11-15 19:21:55','7f9a5644-616a-42d7-81a3-a3f578e08cbb',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(215,215,1,'Headset 4','2023-11-15 19:26:21','2023-11-15 19:26:21','d362ad55-3f5b-412d-b416-21a8da06cd90',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(216,216,1,'Headset 5','2023-11-15 19:26:26','2023-11-15 19:26:26','df6ee0f6-933e-4738-af35-705e10e2772c',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(217,217,1,'Headset 5','2023-11-15 19:28:48','2023-11-15 19:28:48','030a2211-b893-449e-a611-27d3c70829d8',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(218,218,1,'Headset 4','2023-11-15 19:28:53','2023-11-15 19:28:53','6cad5de9-9890-4834-af49-14ff45913cf5',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(219,219,1,'Headset 4a','2023-11-15 19:28:58','2023-11-15 19:28:58','cf8fa178-3962-4048-a35e-eb5804363ef3',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(220,220,1,'Headset 6','2023-11-15 19:31:11','2023-11-15 19:34:51','a299400d-6d7c-443b-ba7d-d38a98442f32',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(221,221,1,'Headset 6','2023-11-15 19:31:11','2023-11-15 19:31:11','26cd67e8-d131-4a21-b9e7-811ce6105b3a',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(222,222,1,'Headset 6','2023-11-15 19:34:51','2023-11-15 19:34:51','85756ef0-ee06-4f11-ab30-24ca55cde422',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(223,223,1,'Headset 4a','2023-11-15 19:34:56','2023-11-15 19:34:56','53b125c4-1cee-46a7-8bf1-89d45314e4b2',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(224,224,1,'Headset 4','2023-11-15 19:35:04','2023-11-15 19:35:04','ab70c7f1-c911-4e90-9907-bc389b97b7f9',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craftidtokens`
--

DROP TABLE IF EXISTS `craftidtokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craftidtokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `accessToken` text NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_divkwxqnoqzncalveugvvmpdwrgxigcchgrh` (`userId`),
  CONSTRAINT `fk_divkwxqnoqzncalveugvvmpdwrgxigcchgrh` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craftidtokens`
--

LOCK TABLES `craftidtokens` WRITE;
/*!40000 ALTER TABLE `craftidtokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `craftidtokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deprecationerrors`
--

DROP TABLE IF EXISTS `deprecationerrors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `deprecationerrors` (
  `id` int NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `fingerprint` varchar(255) NOT NULL,
  `lastOccurrence` datetime NOT NULL,
  `file` varchar(255) NOT NULL,
  `line` smallint unsigned DEFAULT NULL,
  `message` text,
  `traces` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_qzlbznytlxctepzbtqrcttluaelguodemdzb` (`key`,`fingerprint`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deprecationerrors`
--

LOCK TABLES `deprecationerrors` WRITE;
/*!40000 ALTER TABLE `deprecationerrors` DISABLE KEYS */;
/*!40000 ALTER TABLE `deprecationerrors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drafts`
--

DROP TABLE IF EXISTS `drafts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `drafts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int DEFAULT NULL,
  `creatorId` int DEFAULT NULL,
  `provisional` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `notes` text,
  `trackChanges` tinyint(1) NOT NULL DEFAULT '0',
  `dateLastMerged` datetime DEFAULT NULL,
  `saved` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idx_zqyzhttttjeqfcasijsrushzresdzifbvrsc` (`creatorId`,`provisional`),
  KEY `idx_hevzxudibvutirujtbgapgktktyieohfubhp` (`saved`),
  KEY `fk_lulxligvkhmxjjjbfmzmdlkjrjpetwbchyux` (`canonicalId`),
  CONSTRAINT `fk_cjzedrrcpuenuddihqptlmvxpqvhnwoqegjq` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_lulxligvkhmxjjjbfmzmdlkjrjpetwbchyux` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=68 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drafts`
--

LOCK TABLES `drafts` WRITE;
/*!40000 ALTER TABLE `drafts` DISABLE KEYS */;
INSERT INTO `drafts` VALUES (4,NULL,1,0,'First draft',NULL,0,NULL,0),(66,NULL,1,0,'First draft',NULL,0,NULL,0);
/*!40000 ALTER TABLE `drafts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elementactivity`
--

DROP TABLE IF EXISTS `elementactivity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elementactivity` (
  `elementId` int NOT NULL,
  `userId` int NOT NULL,
  `siteId` int NOT NULL,
  `draftId` int DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `timestamp` datetime DEFAULT NULL,
  PRIMARY KEY (`elementId`,`userId`,`type`),
  KEY `idx_qoblxevrhdnlqnkkwdgrovfinnknxkrpkjzz` (`elementId`,`timestamp`,`userId`),
  KEY `fk_oyvtzafpczudapdpkautrtfoeqlyqattryob` (`userId`),
  KEY `fk_oqszfxzitzkmgkohqopmbukzqprgfkwkxvwn` (`siteId`),
  KEY `fk_edxoaaerquifdijwhioeohmnldpgcayykjxl` (`draftId`),
  CONSTRAINT `fk_edxoaaerquifdijwhioeohmnldpgcayykjxl` FOREIGN KEY (`draftId`) REFERENCES `drafts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_gmhgzyoyjuveklawciiroxmsaugzcliooukr` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_oqszfxzitzkmgkohqopmbukzqprgfkwkxvwn` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_oyvtzafpczudapdpkautrtfoeqlyqattryob` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elementactivity`
--

LOCK TABLES `elementactivity` WRITE;
/*!40000 ALTER TABLE `elementactivity` DISABLE KEYS */;
INSERT INTO `elementactivity` VALUES (2,1,1,NULL,'edit','2023-11-04 15:54:31'),(2,1,1,NULL,'save','2023-11-04 15:54:32'),(2,1,1,NULL,'view','2023-11-04 15:54:28'),(4,1,1,NULL,'edit','2023-11-11 09:06:31'),(4,1,1,NULL,'save','2023-11-11 09:06:32'),(4,1,1,NULL,'view','2023-11-11 09:06:19'),(4,121,1,NULL,'edit','2023-11-11 12:12:32'),(4,121,1,NULL,'save','2023-11-11 12:12:33'),(4,121,1,NULL,'view','2023-11-11 12:12:27'),(6,1,1,NULL,'edit','2023-11-11 09:05:51'),(6,1,1,NULL,'save','2023-11-11 09:05:55'),(6,1,1,NULL,'view','2023-11-11 09:05:54'),(6,121,1,NULL,'edit','2023-11-11 12:12:23'),(6,121,1,NULL,'save','2023-11-11 12:12:24'),(6,121,1,NULL,'view','2023-11-11 12:12:18'),(8,1,1,NULL,'view','2023-11-04 15:30:53'),(9,1,1,NULL,'edit','2023-11-11 10:23:57'),(9,1,1,NULL,'save','2023-11-11 10:23:58'),(9,1,1,NULL,'view','2023-11-11 10:23:50'),(11,1,1,NULL,'edit','2023-11-10 10:20:05'),(11,1,1,NULL,'save','2023-11-10 10:20:07'),(11,1,1,NULL,'view','2023-11-10 10:19:57'),(13,1,1,NULL,'save','2023-11-04 15:34:00'),(13,1,1,NULL,'view','2023-11-13 10:33:50'),(15,1,1,NULL,'save','2023-11-04 15:34:09'),(15,1,1,NULL,'view','2023-11-04 15:34:03'),(18,1,1,NULL,'save','2023-11-04 15:34:33'),(24,1,1,NULL,'save','2023-11-04 15:36:34'),(24,1,1,NULL,'view','2023-11-13 10:31:41'),(31,1,1,NULL,'save','2023-11-04 15:38:04'),(31,1,1,NULL,'view','2023-11-04 15:37:57'),(33,1,1,NULL,'edit','2023-11-04 15:38:44'),(33,1,1,NULL,'save','2023-11-04 15:38:45'),(33,1,1,NULL,'view','2023-11-04 15:38:40'),(37,1,1,NULL,'save','2023-11-04 15:39:19'),(37,1,1,NULL,'view','2023-11-04 15:39:18'),(38,1,1,NULL,'save','2023-11-04 15:39:06'),(41,1,1,NULL,'save','2023-11-04 15:39:48'),(41,1,1,NULL,'view','2023-11-04 15:39:36'),(51,1,1,NULL,'save','2023-11-04 15:41:31'),(51,1,1,NULL,'view','2023-11-04 15:41:25'),(53,1,1,NULL,'view','2023-11-04 17:19:06'),(57,1,1,NULL,'edit','2023-11-04 17:19:45'),(57,1,1,NULL,'save','2023-11-04 17:19:47'),(57,1,1,NULL,'view','2023-11-04 17:19:45'),(67,1,1,NULL,'edit','2023-11-04 15:42:50'),(67,1,1,NULL,'save','2023-11-04 15:42:51'),(67,1,1,NULL,'view','2023-11-04 15:42:44'),(73,1,1,NULL,'edit','2023-11-04 17:13:12'),(73,1,1,NULL,'save','2023-11-04 17:13:15'),(73,1,1,NULL,'view','2023-11-04 17:13:08'),(75,1,1,NULL,'edit','2023-11-10 09:26:59'),(75,1,1,NULL,'save','2023-11-10 09:27:01'),(75,1,1,NULL,'view','2023-11-10 09:26:48'),(77,1,1,NULL,'edit','2023-11-04 17:13:05'),(77,1,1,NULL,'save','2023-11-04 17:13:34'),(77,1,1,NULL,'view','2023-11-04 17:13:28'),(83,1,1,NULL,'edit','2023-11-11 10:22:19'),(83,1,1,NULL,'save','2023-11-11 10:22:20'),(83,1,1,NULL,'view','2023-11-11 10:22:18'),(85,1,1,NULL,'edit','2023-11-11 10:22:56'),(85,1,1,NULL,'save','2023-11-11 10:22:59'),(85,1,1,NULL,'view','2023-11-11 10:22:55'),(87,1,1,NULL,'edit','2023-11-11 10:23:21'),(87,1,1,NULL,'save','2023-11-11 10:23:22'),(87,1,1,NULL,'view','2023-11-11 10:23:12'),(89,1,1,NULL,'edit','2023-11-09 17:40:08'),(89,1,1,NULL,'save','2023-11-09 17:40:09'),(89,1,1,NULL,'view','2023-11-09 17:40:02'),(91,1,1,NULL,'edit','2023-11-11 10:23:41'),(91,1,1,NULL,'save','2023-11-11 10:23:42'),(91,1,1,NULL,'view','2023-11-11 10:23:41'),(93,1,1,NULL,'edit','2023-11-09 17:51:25'),(93,1,1,NULL,'save','2023-11-09 17:51:26'),(93,1,1,NULL,'view','2023-11-09 17:51:21'),(95,1,1,NULL,'edit','2023-11-11 10:21:28'),(95,1,1,NULL,'save','2023-11-11 10:21:29'),(95,1,1,NULL,'view','2023-11-11 10:21:21'),(118,1,1,NULL,'edit','2023-11-11 09:06:16'),(118,1,1,NULL,'save','2023-11-11 09:06:17'),(118,1,1,NULL,'view','2023-11-11 09:06:16'),(118,121,1,NULL,'edit','2023-11-11 12:12:14'),(118,121,1,NULL,'save','2023-11-11 12:12:15'),(118,121,1,NULL,'view','2023-11-11 12:12:09'),(133,1,1,NULL,'edit','2023-11-10 09:31:14'),(133,1,1,NULL,'save','2023-11-11 10:20:29'),(133,1,1,NULL,'view','2023-11-11 10:20:25'),(134,1,1,NULL,'save','2023-11-10 09:30:50'),(170,1,1,NULL,'edit','2023-11-12 16:40:41'),(170,1,1,NULL,'save','2023-11-12 16:40:44'),(170,1,1,NULL,'view','2023-11-12 16:40:34'),(172,1,1,NULL,'edit','2023-11-12 16:41:14'),(172,1,1,NULL,'save','2023-11-12 16:41:15'),(172,1,1,NULL,'view','2023-11-12 16:41:08'),(176,1,1,NULL,'edit','2023-11-12 16:41:24'),(176,1,1,NULL,'save','2023-11-12 16:41:25'),(176,1,1,NULL,'view','2023-11-12 16:41:18'),(186,1,1,NULL,'edit','2023-11-12 16:43:14'),(186,1,1,NULL,'save','2023-11-12 16:43:15'),(186,1,1,NULL,'view','2023-11-12 16:43:07'),(194,1,1,NULL,'view','2023-11-12 16:53:17'),(198,1,1,NULL,'view','2023-11-13 10:31:25'),(200,1,1,NULL,'view','2023-11-13 10:31:55'),(205,1,1,NULL,'view','2023-11-15 19:28:15'),(208,1,1,NULL,'edit','2023-11-15 19:17:02'),(208,1,1,NULL,'save','2023-11-15 19:17:03'),(208,1,1,NULL,'view','2023-11-15 19:28:19');
/*!40000 ALTER TABLE `elementactivity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elements`
--

DROP TABLE IF EXISTS `elements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int DEFAULT NULL,
  `draftId` int DEFAULT NULL,
  `revisionId` int DEFAULT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `archived` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateLastMerged` datetime DEFAULT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_rddruplmzovnlbandsagaxawlvfblidhxnqt` (`dateDeleted`),
  KEY `idx_zhbezhtunfgbmllcjqawejxnszoaaupxnsle` (`fieldLayoutId`),
  KEY `idx_btbcgfmftyggqikxojpdkkngyiqvqnnijadi` (`type`),
  KEY `idx_zvtlhefleflqejpbtraogsctsrtutqacjrdd` (`enabled`),
  KEY `idx_wfebpiydjdkuhzqwfgpxxjltsyslikzswlon` (`canonicalId`),
  KEY `idx_asvbdvqmyfkpldrquykuyqdrcpedzkptmksa` (`archived`,`dateCreated`),
  KEY `idx_xumtxjzpoyrpkkclvrzizcsbxyszaymuttuq` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`),
  KEY `idx_ayftuuaxblqqdbqjisxjsrjqmqyogzwizcgf` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`,`enabled`),
  KEY `fk_ysfyyivnstwqysnyqotxytxwwncdtucoarbc` (`draftId`),
  KEY `fk_xbwpjezowmizlsllpkputoraugpjbrjcpquc` (`revisionId`),
  CONSTRAINT `fk_hmwaririztucxnbtbeqhfudvuzisuozkmyfu` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_xbwpjezowmizlsllpkputoraugpjbrjcpquc` FOREIGN KEY (`revisionId`) REFERENCES `revisions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ymvvdwopxpfibdlyturasnrxrokblkicfuca` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_ysfyyivnstwqysnyqotxytxwwncdtucoarbc` FOREIGN KEY (`draftId`) REFERENCES `drafts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=225 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elements`
--

LOCK TABLES `elements` WRITE;
/*!40000 ALTER TABLE `elements` DISABLE KEYS */;
INSERT INTO `elements` VALUES (1,NULL,NULL,NULL,5,'craft\\elements\\User',1,0,'2023-11-04 14:04:30','2023-11-09 16:03:43',NULL,NULL,'d941abec-fedc-4600-9bea-5dad09245dfd'),(2,NULL,NULL,NULL,3,'craft\\elements\\Entry',1,0,'2023-11-04 15:29:16','2023-11-04 15:54:32',NULL,NULL,'0288aeb3-2a20-422a-a10b-fcbb1c5e7f0c'),(3,2,NULL,1,3,'craft\\elements\\Entry',1,0,'2023-11-04 15:29:41','2023-11-04 15:29:41',NULL,NULL,'69d7d696-6a18-4406-8674-763f25136146'),(4,NULL,NULL,NULL,2,'craft\\elements\\Entry',1,0,'2023-11-04 15:30:16','2023-11-11 12:12:33',NULL,NULL,'7b5a98c4-856f-4303-9e39-953fa326be51'),(5,4,NULL,2,2,'craft\\elements\\Entry',1,0,'2023-11-04 15:30:31','2023-11-04 15:30:31',NULL,NULL,'c196612e-bce4-4d8a-9e36-5dd6c9da70c2'),(6,NULL,NULL,NULL,2,'craft\\elements\\Entry',1,0,'2023-11-04 15:30:34','2023-11-11 12:12:24',NULL,NULL,'23f13ce7-b95a-438d-8f0b-c70b04098dd5'),(7,6,NULL,3,2,'craft\\elements\\Entry',1,0,'2023-11-04 15:30:46','2023-11-04 15:30:46',NULL,NULL,'bbcf1c3d-91f7-427f-8b1f-2691cf2fe41a'),(8,NULL,4,NULL,1,'craft\\elements\\Entry',1,0,'2023-11-04 15:30:53','2023-11-04 15:30:53',NULL,NULL,'b94be32d-70f5-462b-9668-95e6fcf43704'),(9,NULL,NULL,NULL,3,'craft\\elements\\Entry',1,0,'2023-11-04 15:31:02','2023-11-11 10:23:58',NULL,NULL,'8b532174-8e28-4961-9c07-1a2c38c29bc3'),(10,9,NULL,4,3,'craft\\elements\\Entry',1,0,'2023-11-04 15:31:26','2023-11-04 15:31:26',NULL,NULL,'d2d8849f-78ae-41fe-9fb8-51d868773aa3'),(11,NULL,NULL,NULL,3,'craft\\elements\\Entry',1,0,'2023-11-04 15:31:28','2023-11-10 10:20:07',NULL,NULL,'6692836f-59f2-49ad-98c7-cef39d61a05f'),(12,11,NULL,5,3,'craft\\elements\\Entry',1,0,'2023-11-04 15:31:59','2023-11-04 15:31:59',NULL,NULL,'46760901-3f07-4f80-a637-183a94b0f3e4'),(13,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2023-11-04 15:33:52','2023-11-04 15:34:00',NULL,NULL,'ca34444c-c4eb-42a4-80cc-d7b43cea0244'),(14,13,NULL,6,1,'craft\\elements\\Entry',1,0,'2023-11-04 15:34:00','2023-11-04 15:34:00',NULL,NULL,'865857c3-e592-4753-b52a-c0f39f4979ce'),(15,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2023-11-04 15:34:02','2023-11-04 15:34:09',NULL,NULL,'96c6b63b-d037-47c1-814c-6b74b3ca5532'),(16,15,NULL,7,1,'craft\\elements\\Entry',1,0,'2023-11-04 15:34:09','2023-11-04 15:34:09',NULL,NULL,'ff5e9aa1-2ed0-4c0d-a6b9-6d01a4d81f56'),(18,NULL,NULL,NULL,6,'craft\\elements\\Entry',1,0,'2023-11-04 15:34:26','2023-11-04 15:34:33',NULL,NULL,'5315f6e0-9f1b-4771-8120-465be3430dff'),(19,18,NULL,8,6,'craft\\elements\\Entry',1,0,'2023-11-04 15:34:33','2023-11-04 15:34:33',NULL,NULL,'b3c70184-17b4-4a40-98e6-829fb2f5efa9'),(20,2,NULL,9,3,'craft\\elements\\Entry',1,0,'2023-11-04 15:34:40','2023-11-04 15:34:40',NULL,NULL,'53582e1f-09fc-411e-9b88-001d2f81688e'),(22,2,NULL,10,3,'craft\\elements\\Entry',1,0,'2023-11-04 15:36:17','2023-11-04 15:36:17',NULL,NULL,'054026ba-55fd-474e-b8cf-47e4e1a67629'),(24,NULL,NULL,NULL,6,'craft\\elements\\Entry',1,0,'2023-11-04 15:36:27','2023-11-04 15:36:34',NULL,NULL,'95bd1742-cf86-4d42-8c22-042ba8e62156'),(25,24,NULL,11,6,'craft\\elements\\Entry',1,0,'2023-11-04 15:36:34','2023-11-04 15:36:34',NULL,NULL,'dedb7c25-801d-421b-93d0-39fbcd90b68f'),(26,9,NULL,12,3,'craft\\elements\\Entry',1,0,'2023-11-04 15:36:50','2023-11-04 15:36:50',NULL,NULL,'661f90b9-4ed5-4b94-9ee8-8c42e7ca289e'),(28,11,NULL,13,3,'craft\\elements\\Entry',1,0,'2023-11-04 15:37:01','2023-11-04 15:37:01',NULL,NULL,'f274520c-c928-41b1-bf2d-3c2429ab71b4'),(30,9,NULL,14,3,'craft\\elements\\Entry',1,0,'2023-11-04 15:37:25','2023-11-04 15:37:25',NULL,NULL,'0ada4fe8-2655-4ed4-a7f0-8e6183bbc3e4'),(31,NULL,NULL,NULL,3,'craft\\elements\\Entry',1,0,'2023-11-04 15:37:41','2023-11-04 15:38:04',NULL,NULL,'a2daa0a7-d81c-47d0-b757-3649ebf977fe'),(32,31,NULL,15,3,'craft\\elements\\Entry',1,0,'2023-11-04 15:38:04','2023-11-04 15:38:04',NULL,NULL,'3fcda624-abae-4a38-b343-16c96083e703'),(33,NULL,NULL,NULL,3,'craft\\elements\\Entry',1,0,'2023-11-04 15:38:19','2023-11-04 15:38:45',NULL,NULL,'15778d0d-0a20-438f-830c-3518fd32aec6'),(34,33,NULL,16,3,'craft\\elements\\Entry',1,0,'2023-11-04 15:38:38','2023-11-04 15:38:38',NULL,NULL,'90c956a0-20bf-458c-8cc1-44734ad659ae'),(36,33,NULL,17,3,'craft\\elements\\Entry',1,0,'2023-11-04 15:38:45','2023-11-04 15:38:45',NULL,NULL,'e9e9eecf-8924-4a74-a462-100aa70325bf'),(37,NULL,NULL,NULL,3,'craft\\elements\\Entry',1,0,'2023-11-04 15:38:47','2023-11-04 15:39:19',NULL,NULL,'08d0f01c-89ec-4a68-8821-7a2baf44039c'),(38,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2023-11-04 15:38:56','2023-11-04 15:39:06',NULL,NULL,'a06f7698-8eac-44bf-8ba4-b7d30be083fb'),(39,38,NULL,18,1,'craft\\elements\\Entry',1,0,'2023-11-04 15:39:06','2023-11-04 15:39:06',NULL,NULL,'973599fc-74ba-4766-9f92-1d423b4bf8c0'),(40,37,NULL,19,3,'craft\\elements\\Entry',1,0,'2023-11-04 15:39:19','2023-11-04 15:39:19',NULL,NULL,'ec45293e-6caa-4bbf-9411-e39ccb6bf76c'),(41,NULL,NULL,NULL,3,'craft\\elements\\Entry',1,0,'2023-11-04 15:39:21','2023-11-04 15:39:48',NULL,NULL,'1904b95a-16c8-476f-915c-a7665ecb9003'),(42,41,NULL,20,3,'craft\\elements\\Entry',1,0,'2023-11-04 15:39:48','2023-11-04 15:39:48',NULL,NULL,'c2099451-be64-42a5-b337-1baf48fe0964'),(43,NULL,NULL,NULL,3,'craft\\elements\\Entry',1,0,'2023-11-04 15:40:11','2023-11-04 15:40:11',NULL,NULL,'707a18df-755d-47c7-8440-1f10416e8f89'),(44,43,NULL,21,3,'craft\\elements\\Entry',1,0,'2023-11-04 15:40:11','2023-11-04 15:40:12',NULL,NULL,'cfecc383-c4f1-41be-856d-86f54201d5ff'),(45,NULL,NULL,NULL,3,'craft\\elements\\Entry',1,0,'2023-11-04 15:40:12','2023-11-04 15:40:12',NULL,NULL,'3b8b4a3d-3798-4552-a19c-2a597a1ed086'),(46,45,NULL,22,3,'craft\\elements\\Entry',1,0,'2023-11-04 15:40:12','2023-11-04 15:40:12',NULL,NULL,'1cd35914-96df-4dba-bc78-c3ff6c78515d'),(47,NULL,NULL,NULL,3,'craft\\elements\\Entry',1,0,'2023-11-04 15:40:50','2023-11-04 15:40:50',NULL,NULL,'a5f2fb74-a379-4fb6-98c4-209ad98313f2'),(48,47,NULL,23,3,'craft\\elements\\Entry',1,0,'2023-11-04 15:40:50','2023-11-04 15:40:50',NULL,NULL,'bb1c5d63-9067-49e5-a54f-05c92cb183c9'),(49,NULL,NULL,NULL,3,'craft\\elements\\Entry',1,0,'2023-11-04 15:40:50','2023-11-04 15:40:50',NULL,NULL,'ac36cab6-6d29-4815-a592-6c9586ef2e66'),(50,49,NULL,24,3,'craft\\elements\\Entry',1,0,'2023-11-04 15:40:50','2023-11-04 15:40:50',NULL,NULL,'d76a49c2-482c-474f-895c-5256e377b620'),(51,NULL,NULL,NULL,3,'craft\\elements\\Entry',1,0,'2023-11-04 15:41:09','2023-11-04 15:41:31',NULL,NULL,'3802587e-0ce3-487c-b7b0-d31753461344'),(52,51,NULL,25,3,'craft\\elements\\Entry',1,0,'2023-11-04 15:41:31','2023-11-04 15:41:31',NULL,NULL,'e12a80ce-e4f6-4722-a1ed-61b58807f139'),(53,NULL,NULL,NULL,3,'craft\\elements\\Entry',1,0,'2023-11-04 15:41:43','2023-11-04 15:41:43',NULL,NULL,'a0d41e8f-ddc3-4532-9292-7dcbecc26c57'),(54,53,NULL,26,3,'craft\\elements\\Entry',1,0,'2023-11-04 15:41:43','2023-11-04 15:41:43',NULL,NULL,'41299b7b-6528-4bb9-9e96-505db6bc4893'),(55,NULL,NULL,NULL,3,'craft\\elements\\Entry',1,0,'2023-11-04 15:41:47','2023-11-04 15:41:47',NULL,NULL,'8facc767-fcf6-4792-8ee8-2a59c8d1911c'),(56,55,NULL,27,3,'craft\\elements\\Entry',1,0,'2023-11-04 15:41:47','2023-11-04 15:41:47',NULL,NULL,'2069eb7a-b21c-4852-92a8-fb24eb3914da'),(57,NULL,NULL,NULL,3,'craft\\elements\\Entry',1,0,'2023-11-04 15:41:47','2023-11-04 17:19:47',NULL,NULL,'83cf949a-59e6-48fe-bb94-18359d67cceb'),(58,57,NULL,28,3,'craft\\elements\\Entry',1,0,'2023-11-04 15:41:47','2023-11-04 15:41:47',NULL,NULL,'6a97e69d-1b41-499a-9cdb-7a6a269aa972'),(59,NULL,NULL,NULL,3,'craft\\elements\\Entry',1,0,'2023-11-04 15:41:51','2023-11-04 15:41:51',NULL,NULL,'66c5d96c-f01e-4c87-94de-e26e2ffa4767'),(60,59,NULL,29,3,'craft\\elements\\Entry',1,0,'2023-11-04 15:41:51','2023-11-04 15:41:52',NULL,NULL,'10e580ff-33da-43d1-8b9d-736c49ea1ad0'),(61,NULL,NULL,NULL,3,'craft\\elements\\Entry',1,0,'2023-11-04 15:41:52','2023-11-04 15:41:52',NULL,NULL,'6e60e4ff-0d0a-49be-9483-80e1915c840d'),(62,61,NULL,30,3,'craft\\elements\\Entry',1,0,'2023-11-04 15:41:52','2023-11-04 15:41:52',NULL,NULL,'e3aecc5c-ce7e-4a77-9bdd-8e8137a994e3'),(63,NULL,NULL,NULL,3,'craft\\elements\\Entry',1,0,'2023-11-04 15:41:52','2023-11-04 15:41:52',NULL,NULL,'7885e47b-e475-4586-84ef-8c2c6d61144d'),(64,63,NULL,31,3,'craft\\elements\\Entry',1,0,'2023-11-04 15:41:52','2023-11-04 15:41:52',NULL,NULL,'27cd3cc9-6064-48ce-ac80-9e68a13ba20a'),(65,NULL,NULL,NULL,3,'craft\\elements\\Entry',1,0,'2023-11-04 15:41:52','2023-11-04 15:41:52',NULL,NULL,'1bf6418b-06ba-464e-808d-9d2887887017'),(66,65,NULL,32,3,'craft\\elements\\Entry',1,0,'2023-11-04 15:41:52','2023-11-04 15:41:52',NULL,NULL,'56a9130c-dd96-4c1d-a3db-b59f785e730e'),(67,NULL,NULL,NULL,3,'craft\\elements\\Entry',1,0,'2023-11-04 15:42:07','2023-11-04 15:42:51',NULL,NULL,'36bd2e9d-c89c-4fe3-ac92-cc0ed7227f42'),(68,67,NULL,33,3,'craft\\elements\\Entry',1,0,'2023-11-04 15:42:35','2023-11-04 15:42:35',NULL,NULL,'fa5251e9-3349-4e56-9c6e-934db184c749'),(69,NULL,NULL,NULL,3,'craft\\elements\\Entry',1,0,'2023-11-04 15:42:40','2023-11-04 15:42:40',NULL,NULL,'a54a5abd-34d1-4c76-b867-b6746f18e228'),(70,69,NULL,34,3,'craft\\elements\\Entry',1,0,'2023-11-04 15:42:40','2023-11-04 15:42:40',NULL,NULL,'dbb44f4a-8df1-4a27-9c50-7cbe2ab9aa77'),(72,67,NULL,35,3,'craft\\elements\\Entry',1,0,'2023-11-04 15:42:51','2023-11-04 15:42:51',NULL,NULL,'22dbc5fc-f1f2-4f07-8c82-b67abbedd26f'),(73,NULL,NULL,NULL,3,'craft\\elements\\Entry',1,0,'2023-11-04 15:42:56','2023-11-04 17:13:15',NULL,NULL,'09ebcc5e-9613-4adb-aefc-a426553b9cdf'),(74,73,NULL,36,3,'craft\\elements\\Entry',1,0,'2023-11-04 15:42:56','2023-11-04 15:42:56',NULL,NULL,'ce6b4431-6b32-41ca-9558-90b75cfd2156'),(75,NULL,NULL,NULL,3,'craft\\elements\\Entry',1,0,'2023-11-04 15:42:59','2023-11-10 09:27:01',NULL,NULL,'a5e1e1f1-68ef-421f-a444-17b934354060'),(76,75,NULL,37,3,'craft\\elements\\Entry',1,0,'2023-11-04 15:42:59','2023-11-04 15:42:59',NULL,NULL,'39e1d2ac-e93e-423f-ad3c-c9ef1669a03b'),(77,NULL,NULL,NULL,3,'craft\\elements\\Entry',1,0,'2023-11-04 15:42:59','2023-11-04 17:13:34',NULL,NULL,'3e6023ea-9eaa-4a5e-950a-d75c73ccdcc6'),(78,77,NULL,38,3,'craft\\elements\\Entry',1,0,'2023-11-04 15:42:59','2023-11-04 15:42:59',NULL,NULL,'7c613072-d091-4420-b466-196fb3f78e2d'),(80,75,NULL,39,3,'craft\\elements\\Entry',1,0,'2023-11-04 15:43:14','2023-11-04 15:43:14',NULL,NULL,'982f2294-1b2d-4546-81fa-58c29a7e1a32'),(81,NULL,NULL,NULL,3,'craft\\elements\\Entry',1,0,'2023-11-04 15:43:22','2023-11-04 15:43:22',NULL,NULL,'4aef0305-d2bc-4ce2-8586-2819fb4eb947'),(82,81,NULL,40,3,'craft\\elements\\Entry',1,0,'2023-11-04 15:43:22','2023-11-04 15:43:22',NULL,NULL,'89fffd1b-c76a-4905-9e9b-80c51b42f06c'),(83,NULL,NULL,NULL,3,'craft\\elements\\Entry',1,0,'2023-11-04 15:43:34','2023-11-11 10:22:20',NULL,NULL,'9f6621b2-868e-43c2-b982-eafe1ed4818c'),(84,83,NULL,41,3,'craft\\elements\\Entry',1,0,'2023-11-04 15:43:53','2023-11-04 15:43:53',NULL,NULL,'0576576a-cc26-42c0-a176-a9911cdf060d'),(85,NULL,NULL,NULL,3,'craft\\elements\\Entry',1,0,'2023-11-04 15:43:57','2023-11-11 10:22:59',NULL,NULL,'e869ff15-e5e1-46dc-b715-94a62f50d798'),(86,85,NULL,42,3,'craft\\elements\\Entry',1,0,'2023-11-04 15:43:57','2023-11-04 15:43:57',NULL,NULL,'19e7e5be-f50b-4971-87b5-96fee8231cf0'),(87,NULL,NULL,NULL,3,'craft\\elements\\Entry',1,0,'2023-11-04 15:44:03','2023-11-11 10:23:22',NULL,NULL,'42f187a4-a678-4a06-9394-e379d0899258'),(88,87,NULL,43,3,'craft\\elements\\Entry',1,0,'2023-11-04 15:44:03','2023-11-04 15:44:03',NULL,NULL,'dacc7519-947b-410f-9f7b-2a28e5e04724'),(89,NULL,NULL,NULL,3,'craft\\elements\\Entry',1,0,'2023-11-04 15:44:03','2023-11-09 17:40:09',NULL,NULL,'1dfb3a2f-950f-4536-a34c-c12395c00fcf'),(90,89,NULL,44,3,'craft\\elements\\Entry',1,0,'2023-11-04 15:44:03','2023-11-04 15:44:03',NULL,NULL,'fc25a809-f368-4f4c-a481-28b129b21e50'),(91,NULL,NULL,NULL,3,'craft\\elements\\Entry',1,0,'2023-11-04 15:44:10','2023-11-11 10:23:42',NULL,NULL,'851f3e33-3b30-4244-a3bc-9e29f192bbf3'),(92,91,NULL,45,3,'craft\\elements\\Entry',1,0,'2023-11-04 15:44:10','2023-11-04 15:44:10',NULL,NULL,'6079802d-d1b7-4be7-9487-0db297fac286'),(93,NULL,NULL,NULL,3,'craft\\elements\\Entry',1,0,'2023-11-04 15:44:10','2023-11-09 17:51:26',NULL,NULL,'1aaee1ae-c3b6-45a4-a65f-a9fbd0b931c5'),(94,93,NULL,46,3,'craft\\elements\\Entry',1,0,'2023-11-04 15:44:10','2023-11-04 15:44:10',NULL,NULL,'997c7717-a084-4b11-ac70-45cde982ef39'),(95,NULL,NULL,NULL,3,'craft\\elements\\Entry',1,0,'2023-11-04 15:44:10','2023-11-11 10:21:29',NULL,NULL,'7240e391-ae9e-4c74-84eb-4db64c76292f'),(96,95,NULL,47,3,'craft\\elements\\Entry',1,0,'2023-11-04 15:44:10','2023-11-04 15:44:10',NULL,NULL,'e04836c0-7ec4-487b-833c-0cd2bda1d521'),(97,93,NULL,48,3,'craft\\elements\\Entry',1,0,'2023-11-04 15:44:25','2023-11-04 15:44:25',NULL,NULL,'8f9b0562-50d5-4472-b5e1-3d9d6d8f1a23'),(99,95,NULL,49,3,'craft\\elements\\Entry',1,0,'2023-11-04 15:44:34','2023-11-04 15:44:34',NULL,NULL,'f551bedc-0b95-40df-bd33-dbd6952c050f'),(101,2,NULL,50,3,'craft\\elements\\Entry',1,0,'2023-11-04 15:54:32','2023-11-04 15:54:32',NULL,NULL,'df02b7c5-3e94-4ced-bf6e-0c5cc6827025'),(103,93,NULL,51,3,'craft\\elements\\Entry',1,0,'2023-11-04 16:21:02','2023-11-04 16:21:02',NULL,NULL,'a8832dc0-2d5f-44b3-ab94-efccdb50f4d5'),(105,77,NULL,52,3,'craft\\elements\\Entry',1,0,'2023-11-04 17:13:06','2023-11-04 17:13:06',NULL,NULL,'6f7ee099-5602-49e3-b75d-9e81a89fc8f8'),(107,73,NULL,53,3,'craft\\elements\\Entry',1,0,'2023-11-04 17:13:15','2023-11-04 17:13:15',NULL,NULL,'98795008-a384-40d4-8d0f-68d097c68ac9'),(108,77,NULL,54,3,'craft\\elements\\Entry',1,0,'2023-11-04 17:13:34','2023-11-04 17:13:34',NULL,NULL,'af8896b5-49db-4eae-a090-f6c0f8a5e86f'),(110,89,NULL,55,3,'craft\\elements\\Entry',1,0,'2023-11-04 17:13:47','2023-11-04 17:13:47',NULL,NULL,'6e0af530-5994-43ae-8805-f1d11a1ba05a'),(112,87,NULL,56,3,'craft\\elements\\Entry',1,0,'2023-11-04 17:14:08','2023-11-04 17:14:08',NULL,NULL,'fd5990ce-e22a-4bd0-8a9a-267bda94949b'),(114,91,NULL,57,3,'craft\\elements\\Entry',1,0,'2023-11-04 17:14:18','2023-11-04 17:14:18',NULL,NULL,'a2bada5c-2fbc-4e4e-a915-f067872047a2'),(116,57,NULL,58,3,'craft\\elements\\Entry',1,0,'2023-11-04 17:19:47','2023-11-04 17:19:47',NULL,NULL,'015f40ed-276c-4457-84d5-508050dd3710'),(118,NULL,NULL,NULL,2,'craft\\elements\\Entry',1,0,'2023-11-09 08:45:42','2023-11-15 19:00:09',NULL,NULL,'7ca2186d-3de2-492c-8add-327f56b69ae1'),(119,118,NULL,59,2,'craft\\elements\\Entry',1,0,'2023-11-09 08:46:03','2023-11-09 08:46:03',NULL,NULL,'8a9a9fe7-ddac-4cce-878b-7c94fdd0ce31'),(120,NULL,NULL,NULL,5,'craft\\elements\\User',1,0,'2023-11-09 16:00:00','2023-11-09 16:01:20',NULL,NULL,'8ab5d5bd-396c-4d32-8d19-e6a4ecde0277'),(121,NULL,NULL,NULL,5,'craft\\elements\\User',1,0,'2023-11-09 16:01:08','2023-11-15 18:48:37',NULL,NULL,'4861d33b-a1cb-4aea-8bee-907c70411df5'),(122,93,NULL,60,3,'craft\\elements\\Entry',1,0,'2023-11-09 17:34:47','2023-11-09 17:34:47',NULL,NULL,'b5386f9e-700b-49b3-9177-54ca60a2a576'),(124,95,NULL,61,3,'craft\\elements\\Entry',1,0,'2023-11-09 17:34:59','2023-11-09 17:34:59',NULL,NULL,'4180523a-9e46-464c-bee3-5ad1fa9f0949'),(126,89,NULL,62,3,'craft\\elements\\Entry',1,0,'2023-11-09 17:40:09','2023-11-09 17:40:09',NULL,NULL,'1eee4eda-a2ee-4a3c-bc0a-2c8a1f5a75cb'),(128,93,NULL,63,3,'craft\\elements\\Entry',1,0,'2023-11-09 17:51:26','2023-11-09 17:51:26',NULL,NULL,'b0a22a0a-adf3-4f11-a23d-40f69b3ff5e0'),(130,91,NULL,64,3,'craft\\elements\\Entry',1,0,'2023-11-10 09:26:37','2023-11-10 09:26:37',NULL,NULL,'d3b85f8a-7a2d-485f-8e46-e9107a2061ab'),(132,75,NULL,65,3,'craft\\elements\\Entry',1,0,'2023-11-10 09:27:01','2023-11-10 09:27:01',NULL,NULL,'8287119a-87f1-42c4-baa3-d7e8eccfda6c'),(133,NULL,NULL,NULL,3,'craft\\elements\\Entry',1,0,'2023-11-10 09:30:11','2023-11-11 10:20:29',NULL,NULL,'814cd7c2-9791-45fc-bd5f-9c51a2845992'),(134,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2023-11-10 09:30:38','2023-11-10 09:30:50',NULL,NULL,'dfb32c68-80f7-43e7-b138-e50bdd01f044'),(135,134,NULL,66,1,'craft\\elements\\Entry',1,0,'2023-11-10 09:30:50','2023-11-10 09:30:50',NULL,NULL,'143bb738-1a1f-43b0-afe1-6bc6301b4f17'),(136,133,NULL,67,3,'craft\\elements\\Entry',1,0,'2023-11-10 09:31:06','2023-11-10 09:31:06',NULL,NULL,'899217f8-e5b9-49c0-90d4-26da0e30ee1a'),(138,133,NULL,68,3,'craft\\elements\\Entry',1,0,'2023-11-10 09:31:16','2023-11-10 09:31:16',NULL,NULL,'083acfaf-9fd2-4b94-ae0c-f8edfcfb0769'),(140,11,NULL,69,3,'craft\\elements\\Entry',1,0,'2023-11-10 10:20:07','2023-11-10 10:20:07',NULL,NULL,'4b7f870c-ea2e-4e59-b50b-9a911a12d030'),(142,6,NULL,70,2,'craft\\elements\\Entry',1,0,'2023-11-11 09:05:55','2023-11-11 09:05:55',NULL,NULL,'72f61519-ca8d-432e-a7e9-7424cd05e567'),(144,118,NULL,71,2,'craft\\elements\\Entry',1,0,'2023-11-11 09:06:17','2023-11-11 09:06:17',NULL,NULL,'7306432b-6f5e-4afb-9402-56f9c738783e'),(146,4,NULL,72,2,'craft\\elements\\Entry',1,0,'2023-11-11 09:06:32','2023-11-11 09:06:32',NULL,NULL,'39735c71-fdae-46f4-acc8-94bb0f9b9063'),(147,133,NULL,73,3,'craft\\elements\\Entry',1,0,'2023-11-11 10:20:29','2023-11-11 10:20:29',NULL,NULL,'6c5173ec-3639-4a6e-954a-4a90fdba5910'),(149,83,NULL,74,3,'craft\\elements\\Entry',1,0,'2023-11-11 10:20:54','2023-11-11 10:20:54',NULL,NULL,'8c887c2f-58a2-4aca-a663-60a9653469d6'),(151,95,NULL,75,3,'craft\\elements\\Entry',1,0,'2023-11-11 10:21:13','2023-11-11 10:21:13',NULL,NULL,'dd81797a-4ec9-4db7-9ada-d5752b844c2a'),(153,95,NULL,76,3,'craft\\elements\\Entry',1,0,'2023-11-11 10:21:29','2023-11-11 10:21:29',NULL,NULL,'230f70fe-4744-4c30-adbe-d8953c0d040a'),(155,83,NULL,77,3,'craft\\elements\\Entry',1,0,'2023-11-11 10:22:20','2023-11-11 10:22:20',NULL,NULL,'cc0cadbf-4163-424b-9135-4162f8f8a5e3'),(157,85,NULL,78,3,'craft\\elements\\Entry',1,0,'2023-11-11 10:22:59','2023-11-11 10:22:59',NULL,NULL,'622a43a1-bf72-4be5-8db1-8449a772818c'),(159,87,NULL,79,3,'craft\\elements\\Entry',1,0,'2023-11-11 10:23:22','2023-11-11 10:23:22',NULL,NULL,'85b86f2f-efde-4974-95cd-9f0835e3cdf6'),(161,91,NULL,80,3,'craft\\elements\\Entry',1,0,'2023-11-11 10:23:42','2023-11-11 10:23:42',NULL,NULL,'903c03bc-3b5c-4ce1-b729-f2ebd81f32c2'),(163,9,NULL,81,3,'craft\\elements\\Entry',1,0,'2023-11-11 10:23:58','2023-11-11 10:23:58',NULL,NULL,'86ab61e8-007d-472b-b902-34a40e1722cb'),(165,118,NULL,82,2,'craft\\elements\\Entry',1,0,'2023-11-11 12:12:15','2023-11-11 12:12:15',NULL,NULL,'9eb521af-b277-4446-96c3-eaa91df4dea8'),(167,6,NULL,83,2,'craft\\elements\\Entry',1,0,'2023-11-11 12:12:24','2023-11-11 12:12:24',NULL,NULL,'225bdf74-f1d6-4299-9cda-80bbf7b603fa'),(169,4,NULL,84,2,'craft\\elements\\Entry',1,0,'2023-11-11 12:12:33','2023-11-11 12:12:33',NULL,NULL,'cee4f387-86e8-4d4f-944c-3db0829fbf94'),(170,NULL,NULL,NULL,3,'craft\\elements\\Entry',1,0,'2023-11-12 16:37:46','2023-11-12 16:40:43',NULL,NULL,'d3d5b4f6-0b82-4bc7-9e52-aed0321865d8'),(171,170,NULL,85,3,'craft\\elements\\Entry',1,0,'2023-11-12 16:37:46','2023-11-12 16:37:46',NULL,NULL,'aecd8cd1-3a25-4c7c-8b12-7bf8dc0419ba'),(172,NULL,NULL,NULL,3,'craft\\elements\\Entry',1,0,'2023-11-12 16:37:53','2023-11-12 16:41:15',NULL,NULL,'4a051404-1c53-4c55-9330-5d320449e64b'),(173,172,NULL,86,3,'craft\\elements\\Entry',1,0,'2023-11-12 16:37:53','2023-11-12 16:37:53',NULL,NULL,'f47846fd-6ac7-4818-9715-354aab21afdf'),(175,172,NULL,87,3,'craft\\elements\\Entry',1,0,'2023-11-12 16:39:01','2023-11-12 16:39:01',NULL,NULL,'0bf9ac46-2319-425b-9d2e-2584e76d1fb9'),(176,NULL,NULL,NULL,3,'craft\\elements\\Entry',1,0,'2023-11-12 16:40:16','2023-11-12 16:41:25',NULL,NULL,'ef6a9216-91a6-435e-ae17-20091b800966'),(177,176,NULL,88,3,'craft\\elements\\Entry',1,0,'2023-11-12 16:40:16','2023-11-12 16:40:16',NULL,NULL,'da7b3033-a46c-47da-aca9-37dc586e665b'),(179,170,NULL,89,3,'craft\\elements\\Entry',1,0,'2023-11-12 16:40:43','2023-11-12 16:40:43',NULL,NULL,'ee005e71-0626-4609-bea2-fe4e460a1199'),(181,172,NULL,90,3,'craft\\elements\\Entry',1,0,'2023-11-12 16:41:15','2023-11-12 16:41:15',NULL,NULL,'ef0361c0-a85e-47ff-b9b0-5ead16202a1f'),(183,176,NULL,91,3,'craft\\elements\\Entry',1,0,'2023-11-12 16:41:25','2023-11-12 16:41:25',NULL,NULL,'5e022f0e-bea6-4aae-b430-c1abeaacbc17'),(186,NULL,NULL,NULL,3,'craft\\elements\\Entry',1,0,'2023-11-12 16:42:21','2023-11-12 16:43:15',NULL,NULL,'9f95781c-7820-4f42-aca6-53bd7b540d47'),(187,186,NULL,92,3,'craft\\elements\\Entry',1,0,'2023-11-12 16:42:21','2023-11-12 16:42:21',NULL,NULL,'270b75e5-816c-45b8-a58e-e5517f6c7197'),(188,NULL,NULL,NULL,3,'craft\\elements\\Entry',1,0,'2023-11-12 16:42:50','2023-11-12 16:42:50',NULL,NULL,'02b6a54e-6be9-4a1b-808f-878f2b16f6e3'),(189,188,NULL,93,3,'craft\\elements\\Entry',1,0,'2023-11-12 16:42:50','2023-11-12 16:42:50',NULL,NULL,'6872dccc-6272-405b-ac38-26e8f8143f38'),(191,186,NULL,94,3,'craft\\elements\\Entry',1,0,'2023-11-12 16:43:15','2023-11-12 16:43:15',NULL,NULL,'d14a6c81-f6be-42c3-8e45-8a104d5661b0'),(192,NULL,NULL,NULL,3,'craft\\elements\\Entry',1,0,'2023-11-12 16:43:29','2023-11-12 16:43:29',NULL,NULL,'494e80ea-fa29-440e-a803-d68e609d275a'),(193,192,NULL,95,3,'craft\\elements\\Entry',1,0,'2023-11-12 16:43:29','2023-11-12 16:43:29',NULL,NULL,'f9953864-6f80-4e3d-ab9e-d30f0ad67132'),(194,NULL,NULL,NULL,3,'craft\\elements\\Entry',1,0,'2023-11-12 16:52:34','2023-11-12 16:52:34',NULL,NULL,'2d255fcf-ea86-406b-a066-7203c50b71d3'),(195,194,NULL,96,3,'craft\\elements\\Entry',1,0,'2023-11-12 16:52:34','2023-11-12 16:52:34',NULL,NULL,'3fb27e71-f944-4a48-a803-090eb5169748'),(196,NULL,NULL,NULL,3,'craft\\elements\\Entry',1,0,'2023-11-12 16:52:45','2023-11-12 16:52:45',NULL,NULL,'511a14ad-9d1a-4cdc-bf38-15913061af73'),(197,196,NULL,97,3,'craft\\elements\\Entry',1,0,'2023-11-12 16:52:45','2023-11-12 16:52:45',NULL,NULL,'cda5f910-686a-45e3-bacf-9b0ddd0913c9'),(198,NULL,NULL,NULL,3,'craft\\elements\\Entry',1,0,'2023-11-12 16:53:24','2023-11-12 16:53:24',NULL,NULL,'63fb4ad7-8bf2-44cb-b6fa-83f102c5f38c'),(199,198,NULL,98,3,'craft\\elements\\Entry',1,0,'2023-11-12 16:53:24','2023-11-12 16:53:24',NULL,NULL,'977ffd07-0eb1-49b6-b7c0-db51a7fa49bb'),(200,NULL,66,NULL,6,'craft\\elements\\Entry',1,0,'2023-11-13 10:31:55','2023-11-13 10:31:55',NULL,NULL,'4ab94a57-9968-4ff4-88ec-ce692d5bb380'),(201,118,NULL,99,2,'craft\\elements\\Entry',1,0,'2023-11-15 19:00:00','2023-11-15 19:00:00',NULL,NULL,'b8d0c32f-cda7-4460-8b99-1cc0d83339d3'),(202,118,NULL,100,2,'craft\\elements\\Entry',1,0,'2023-11-15 19:00:09','2023-11-15 19:00:09',NULL,NULL,'ef82a1e5-014a-43a1-9d64-55f697f421da'),(203,NULL,NULL,NULL,2,'craft\\elements\\Entry',1,0,'2023-11-15 19:03:14','2023-11-15 19:03:14',NULL,NULL,'7b72655f-69aa-44b4-b931-6a140ccc2568'),(204,203,NULL,101,2,'craft\\elements\\Entry',1,0,'2023-11-15 19:03:14','2023-11-15 19:03:14',NULL,NULL,'e58a5ebb-2b5e-48f6-a184-63930da047a4'),(205,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2023-11-15 19:09:48','2023-11-15 19:35:04',NULL,NULL,'13aa6235-b987-400c-9546-225b648f9a7a'),(206,205,NULL,102,1,'craft\\elements\\Entry',1,0,'2023-11-15 19:09:48','2023-11-15 19:09:48',NULL,NULL,'711251eb-3c31-42b8-a578-9e1f7b202a44'),(207,205,NULL,103,1,'craft\\elements\\Entry',1,0,'2023-11-15 19:15:46','2023-11-15 19:15:46',NULL,NULL,'fd215792-3329-4468-91e0-533c4d6c0a06'),(208,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2023-11-15 19:16:48','2023-11-15 19:28:48',NULL,NULL,'c74c4da0-6a6b-49fe-a226-ea4cab72f1a8'),(209,208,NULL,104,1,'craft\\elements\\Entry',1,0,'2023-11-15 19:16:48','2023-11-15 19:16:48',NULL,NULL,'888602db-cc6c-4804-978a-19f40a1117f5'),(211,208,NULL,105,1,'craft\\elements\\Entry',1,0,'2023-11-15 19:17:03','2023-11-15 19:17:03',NULL,NULL,'4285306b-32df-46a5-ae30-4300ed48cd45'),(212,208,NULL,106,1,'craft\\elements\\Entry',1,0,'2023-11-15 19:19:47','2023-11-15 19:19:47',NULL,NULL,'feb390a4-5ce7-4f8e-a361-8250205be41c'),(213,208,NULL,107,1,'craft\\elements\\Entry',1,0,'2023-11-15 19:19:53','2023-11-15 19:19:53',NULL,NULL,'5e2014d4-3428-428a-b8b8-60d2bc4945d0'),(214,205,NULL,108,1,'craft\\elements\\Entry',1,0,'2023-11-15 19:21:55','2023-11-15 19:21:55',NULL,NULL,'5f55e446-79d2-463d-b2f9-f8c13d3214a1'),(215,205,NULL,109,1,'craft\\elements\\Entry',1,0,'2023-11-15 19:26:21','2023-11-15 19:26:21',NULL,NULL,'effb45b3-337a-4db5-8615-2c6121fc2519'),(216,208,NULL,110,1,'craft\\elements\\Entry',1,0,'2023-11-15 19:26:26','2023-11-15 19:26:26',NULL,NULL,'ce361cc0-b1a1-4537-a349-98153df18dfe'),(217,208,NULL,111,1,'craft\\elements\\Entry',1,0,'2023-11-15 19:28:48','2023-11-15 19:28:48',NULL,NULL,'f9b31a4f-01c4-4d81-8a6b-1bbe669d3013'),(218,205,NULL,112,1,'craft\\elements\\Entry',1,0,'2023-11-15 19:28:53','2023-11-15 19:28:53',NULL,NULL,'5ae28081-12c6-4c5e-a7f4-9b922134e04b'),(219,205,NULL,113,1,'craft\\elements\\Entry',1,0,'2023-11-15 19:28:58','2023-11-15 19:28:58',NULL,NULL,'2c8421ad-a9cc-4436-96b6-a1b7b00bf96d'),(220,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2023-11-15 19:31:11','2023-11-15 19:34:51',NULL,NULL,'c51547c0-6d23-4a03-a612-81f43dea2429'),(221,220,NULL,114,1,'craft\\elements\\Entry',1,0,'2023-11-15 19:31:11','2023-11-15 19:31:11',NULL,NULL,'7563411d-ad18-4aa8-b9ef-f98b28a8ea76'),(222,220,NULL,115,1,'craft\\elements\\Entry',1,0,'2023-11-15 19:34:51','2023-11-15 19:34:51',NULL,NULL,'83497541-82be-47d7-b48b-8d0ed3e53f3d'),(223,205,NULL,116,1,'craft\\elements\\Entry',1,0,'2023-11-15 19:34:56','2023-11-15 19:34:56',NULL,NULL,'fd0db40a-0afe-4a6a-9554-dd12f5b7393e'),(224,205,NULL,117,1,'craft\\elements\\Entry',1,0,'2023-11-15 19:35:04','2023-11-15 19:35:04',NULL,NULL,'3a56b854-8d3c-44cd-8374-bcadef094180');
/*!40000 ALTER TABLE `elements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elements_sites`
--

DROP TABLE IF EXISTS `elements_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_xerzmwyfmnudmgizijvmcqwnggxitchalscu` (`elementId`,`siteId`),
  KEY `idx_dnqjptcjolnzjfotcdgnqtgvuzlamawiomzr` (`siteId`),
  KEY `idx_unnihiykewjtirygqzwleegjgqvdxitcojnm` (`slug`,`siteId`),
  KEY `idx_nexlgcyayhbuxjzrjhkjreacttprqxycgmrs` (`enabled`),
  KEY `idx_nstegdiemvcsnajsxdmtvxdfyfyhjurdtyqd` (`uri`,`siteId`),
  CONSTRAINT `fk_clvwbpjnruyazctfoyapoxaxicguafxcdtmn` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_yefcrprzofrrwadkiwgarasowppihdqxzdxs` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=225 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elements_sites`
--

LOCK TABLES `elements_sites` WRITE;
/*!40000 ALTER TABLE `elements_sites` DISABLE KEYS */;
INSERT INTO `elements_sites` VALUES (1,1,1,NULL,NULL,1,'2023-11-04 14:04:30','2023-11-04 14:04:30','bf191eea-11ef-45ba-8213-cf88dc83ea47'),(2,2,1,'entry-1','statistics/entry-1',1,'2023-11-04 15:29:16','2023-11-04 15:29:21','b8213c4f-c8e9-4330-bde7-0354c58b8db7'),(3,3,1,'entry-1','statistics/entry-1',1,'2023-11-04 15:29:41','2023-11-04 15:29:41','9ab4aa65-e15a-4597-b17b-5563ff5624cd'),(4,4,1,'hub-367','venues/hub-367',1,'2023-11-04 15:30:16','2023-11-04 15:30:26','fdf0ac10-e1ac-4beb-82fd-341b31f3c375'),(5,5,1,'hub-367','venues/hub-367',1,'2023-11-04 15:30:31','2023-11-04 15:30:31','3af7c278-84fb-4679-94c0-2b26991d19cb'),(6,6,1,'diocletian-museum','venues/diocletian-museum',1,'2023-11-04 15:30:34','2023-11-04 15:30:40','a11dc373-908a-4530-b7ab-680bf87c50fb'),(7,7,1,'diocletian-museum','venues/diocletian-museum',1,'2023-11-04 15:30:46','2023-11-04 15:30:46','feb6088d-5b29-495e-a9c6-2558d63aaa9b'),(8,8,1,'__temp_iuuftuboqfzmycvibtkzyqagtgmwheocdalt','headsets/__temp_iuuftuboqfzmycvibtkzyqagtgmwheocdalt',1,'2023-11-04 15:30:53','2023-11-04 15:30:53','db3c5300-2bf9-4625-9dd8-8490c7992ebb'),(9,9,1,'entry-2','statistics/entry-2',1,'2023-11-04 15:31:02','2023-11-04 15:31:06','93974e2a-2495-4b5d-b108-6dd9e5dfb96d'),(10,10,1,'entry-2','statistics/entry-2',1,'2023-11-04 15:31:26','2023-11-04 15:31:26','39749e35-325c-427f-9e02-6f3c9065d097'),(11,11,1,'entry-3','statistics/entry-3',1,'2023-11-04 15:31:28','2023-11-04 15:31:32','e82c3d09-0604-4003-82b8-90c3acbb67ee'),(12,12,1,'entry-3','statistics/entry-3',1,'2023-11-04 15:31:59','2023-11-04 15:31:59','326cd815-32a8-4d3d-b830-29f17fd261ee'),(13,13,1,'headset-1','headsets/headset-1',1,'2023-11-04 15:33:52','2023-11-04 15:33:56','2d4dd6a5-4475-4a5f-b9cc-eb24485094ed'),(14,14,1,'headset-1','headsets/headset-1',1,'2023-11-04 15:34:00','2023-11-04 15:34:00','c9723d2e-8d56-4b3b-946c-63696390d961'),(15,15,1,'headset-2','headsets/headset-2',1,'2023-11-04 15:34:02','2023-11-04 15:34:06','3b06df71-a348-4b20-8d84-1a92c67447bf'),(16,16,1,'headset-2','headsets/headset-2',1,'2023-11-04 15:34:09','2023-11-04 15:34:09','d45d77c4-e4ea-472c-a427-f5f29d2cdd0b'),(18,18,1,'echoes-of-sarajevo','movies/echoes-of-sarajevo',1,'2023-11-04 15:34:26','2023-11-04 15:34:33','5c00ef52-17e6-4297-9dbd-027d4d110002'),(19,19,1,'echoes-of-sarajevo','movies/echoes-of-sarajevo',1,'2023-11-04 15:34:33','2023-11-04 15:34:33','1fe2a0c5-ad73-4a10-b0f1-0834cea00340'),(20,20,1,'entry-1','statistics/entry-1',1,'2023-11-04 15:34:40','2023-11-04 15:34:40','daf1df16-6247-41ee-939a-1b3f6c434eef'),(22,22,1,'entry-1','statistics/entry-1',1,'2023-11-04 15:36:17','2023-11-04 15:36:17','7b6d5740-0ec0-4530-843c-5b9e3e23d1c5'),(24,24,1,'diocletians-dream','movies/diocletians-dream',1,'2023-11-04 15:36:27','2023-11-04 15:36:34','5822c612-1fb3-456f-a87b-c4881fac1c65'),(25,25,1,'diocletians-dream','movies/diocletians-dream',1,'2023-11-04 15:36:34','2023-11-04 15:36:34','d45f6a58-03c4-472f-a826-d213e34f0f71'),(26,26,1,'entry-2','statistics/entry-2',1,'2023-11-04 15:36:50','2023-11-04 15:36:50','0772916e-ab11-4a2a-afe4-71be1f4b24a3'),(28,28,1,'entry-3','statistics/entry-3',1,'2023-11-04 15:37:01','2023-11-04 15:37:01','678847c1-cc9b-4cdb-abd4-812dbe1a0fab'),(30,30,1,'entry-2','statistics/entry-2',1,'2023-11-04 15:37:25','2023-11-04 15:37:25','c60912ec-db15-4c90-bb36-697af8efe07a'),(31,31,1,'entry-4','statistics/entry-4',1,'2023-11-04 15:37:41','2023-11-04 15:37:44','986d2597-5483-4fdc-aa42-d4ddc3e0e43f'),(32,32,1,'entry-4','statistics/entry-4',1,'2023-11-04 15:38:04','2023-11-04 15:38:04','80da3a0d-f3af-4295-a617-da5e55bda418'),(33,33,1,'entry-5-ba','statistics/entry-5-ba',1,'2023-11-04 15:38:19','2023-11-04 15:38:24','b125e0e1-afc5-41fd-873c-82064ec0c201'),(34,34,1,'entry-5-ba','statistics/entry-5-ba',1,'2023-11-04 15:38:38','2023-11-04 15:38:38','ce382374-bd57-49b1-a92d-36f7dd98f2e1'),(36,36,1,'entry-5-ba','statistics/entry-5-ba',1,'2023-11-04 15:38:45','2023-11-04 15:38:45','724c9505-e5c4-4400-b27e-09fa7a79a0d0'),(37,37,1,'entry-6-ba','statistics/entry-6-ba',1,'2023-11-04 15:38:47','2023-11-04 15:38:52','0804a176-cd95-49b5-892c-e400d06831a0'),(38,38,1,'headset-2-2','headsets/headset-2-2',1,'2023-11-04 15:38:56','2023-11-04 15:39:06','6f8663d1-b907-4476-809d-dfa042bc82c8'),(39,39,1,'headset-2-2','headsets/headset-2-2',1,'2023-11-04 15:39:06','2023-11-04 15:39:06','ff9ce409-03fa-430c-bf63-5206d260dbcc'),(40,40,1,'entry-6-ba','statistics/entry-6-ba',1,'2023-11-04 15:39:19','2023-11-04 15:39:19','2437de74-d601-4bf8-80fd-cc314fcc8ab9'),(41,41,1,'entry-7','statistics/entry-7',1,'2023-11-04 15:39:21','2023-11-04 15:39:24','f5fb4518-a80d-4731-b0ea-9da562a8d9dd'),(42,42,1,'entry-7','statistics/entry-7',1,'2023-11-04 15:39:48','2023-11-04 15:39:48','6176914e-6162-45b2-8888-1852d8c2e626'),(43,43,1,'entry-6-ba-2','statistics/entry-6-ba-2',1,'2023-11-04 15:40:11','2023-11-04 15:40:11','41d8bc7f-e57a-42d6-b4cb-e0c946139dae'),(44,44,1,'entry-6-ba-2','statistics/entry-6-ba-2',1,'2023-11-04 15:40:12','2023-11-04 15:40:12','eaa26840-75d2-463c-bfdd-917155e58912'),(45,45,1,'entry-7-2','statistics/entry-7-2',1,'2023-11-04 15:40:12','2023-11-04 15:40:12','0f7b0697-635b-4f3f-b7fe-f52398315c41'),(46,46,1,'entry-7-2','statistics/entry-7-2',1,'2023-11-04 15:40:12','2023-11-04 15:40:12','72c4dc63-c5e2-4283-bf95-d7074d8f530d'),(47,47,1,'entry-6-ba-3','statistics/entry-6-ba-3',1,'2023-11-04 15:40:50','2023-11-04 15:40:50','8644d08b-2ae7-47b8-bb34-a37bae6a9004'),(48,48,1,'entry-6-ba-3','statistics/entry-6-ba-3',1,'2023-11-04 15:40:50','2023-11-04 15:40:50','7cf29e4a-b40d-4c46-a908-fda17013fc8c'),(49,49,1,'entry-7-3','statistics/entry-7-3',1,'2023-11-04 15:40:50','2023-11-04 15:40:50','fd440492-af95-4033-812a-7e60cffddc75'),(50,50,1,'entry-7-3','statistics/entry-7-3',1,'2023-11-04 15:40:50','2023-11-04 15:40:50','21930c0d-c5e1-412c-9563-145093d5a477'),(51,51,1,'entry-es','statistics/entry-es',1,'2023-11-04 15:41:09','2023-11-04 15:41:13','181626a9-504f-42c9-901e-184329625068'),(52,52,1,'entry-es','statistics/entry-es',1,'2023-11-04 15:41:31','2023-11-04 15:41:31','05f602c2-deae-4e5e-9d66-77a3de303886'),(53,53,1,'entry-es-2','statistics/entry-es-2',1,'2023-11-04 15:41:43','2023-11-04 15:41:43','d866b746-af29-4b08-88e2-7d5175c7aaa7'),(54,54,1,'entry-es-2','statistics/entry-es-2',1,'2023-11-04 15:41:43','2023-11-04 15:41:43','59c14969-b8fa-48b6-b093-a344e0108cc8'),(55,55,1,'entry-es-3','statistics/entry-es-3',1,'2023-11-04 15:41:47','2023-11-04 15:41:47','2bc9feb5-4f70-4024-bd6e-65d722adf426'),(56,56,1,'entry-es-3','statistics/entry-es-3',1,'2023-11-04 15:41:47','2023-11-04 15:41:47','fdd8cf61-141b-45e3-991f-266072de480f'),(57,57,1,'entry-es-2-2','statistics/entry-es-2-2',1,'2023-11-04 15:41:47','2023-11-04 15:41:47','010bf4e2-6637-4e9e-b588-c985caf93091'),(58,58,1,'entry-es-2-2','statistics/entry-es-2-2',1,'2023-11-04 15:41:47','2023-11-04 15:41:47','b1cb89af-0638-400f-9200-c38c91922d3f'),(59,59,1,'entry-es-4','statistics/entry-es-4',1,'2023-11-04 15:41:51','2023-11-04 15:41:51','28d9d556-7ff0-4462-a0af-d7dd87bce480'),(60,60,1,'entry-es-4','statistics/entry-es-4',1,'2023-11-04 15:41:52','2023-11-04 15:41:52','c4a7a213-a512-48c3-a8b8-6ab75e56bac4'),(61,61,1,'entry-es-2-3','statistics/entry-es-2-3',1,'2023-11-04 15:41:52','2023-11-04 15:41:52','ff6ce288-ff2c-4480-a40f-cacb986ad8ff'),(62,62,1,'entry-es-2-3','statistics/entry-es-2-3',1,'2023-11-04 15:41:52','2023-11-04 15:41:52','f6d9fae5-f807-47d5-95c5-d03f9ba5feac'),(63,63,1,'entry-es-3-2','statistics/entry-es-3-2',1,'2023-11-04 15:41:52','2023-11-04 15:41:52','ce99432e-b9c3-445d-8eaf-9241f3e40b17'),(64,64,1,'entry-es-3-2','statistics/entry-es-3-2',1,'2023-11-04 15:41:52','2023-11-04 15:41:52','a2ac1ac4-125b-43ef-b6fe-43ce1febb185'),(65,65,1,'entry-es-2-2-2','statistics/entry-es-2-2-2',1,'2023-11-04 15:41:52','2023-11-04 15:41:52','d638734b-3bb5-438d-972b-3f336b126c42'),(66,66,1,'entry-es-2-2-2','statistics/entry-es-2-2-2',1,'2023-11-04 15:41:52','2023-11-04 15:41:52','8c7db01b-834d-45b1-97e3-f6ae664e663d'),(67,67,1,'entry-en','statistics/entry-en',1,'2023-11-04 15:42:07','2023-11-04 15:42:28','aa2e00cf-b0bf-4b08-839b-d9ecde6fcfbc'),(68,68,1,'entry-en','statistics/entry-en',1,'2023-11-04 15:42:35','2023-11-04 15:42:35','ec203970-c15f-4814-9ff1-86a1a9830b23'),(69,69,1,'entry-en-2','statistics/entry-en-2',1,'2023-11-04 15:42:40','2023-11-04 15:42:40','e84866d6-6a3a-4db0-900b-dee06c2b6951'),(70,70,1,'entry-en-2','statistics/entry-en-2',1,'2023-11-04 15:42:40','2023-11-04 15:42:40','b7175369-aca9-4617-9a60-b78e8ad39db7'),(72,72,1,'entry-en','statistics/entry-en',1,'2023-11-04 15:42:51','2023-11-04 15:42:51','bbcae68d-f081-472c-92bf-107bdb43287b'),(73,73,1,'entry-en-3','statistics/entry-en-3',1,'2023-11-04 15:42:56','2023-11-04 15:42:56','74aee297-555d-49fc-91dd-0563147008b0'),(74,74,1,'entry-en-3','statistics/entry-en-3',1,'2023-11-04 15:42:56','2023-11-04 15:42:56','42dc090c-3662-4bae-8630-b857ef722230'),(75,75,1,'entry-en-4','statistics/entry-en-4',1,'2023-11-04 15:42:59','2023-11-04 15:42:59','1c97ec0e-4226-426c-8cef-e7de8098f932'),(76,76,1,'entry-en-4','statistics/entry-en-4',1,'2023-11-04 15:42:59','2023-11-04 15:42:59','51a25675-550a-4c37-bedb-b71debdda71c'),(77,77,1,'entry-en-2-2','statistics/entry-en-2-2',1,'2023-11-04 15:42:59','2023-11-04 15:42:59','169bf569-46e9-4a39-a3de-cabdae935628'),(78,78,1,'entry-en-2-2','statistics/entry-en-2-2',1,'2023-11-04 15:42:59','2023-11-04 15:42:59','667b35b6-0c36-47a3-aa94-3b067a116739'),(80,80,1,'entry-en-4','statistics/entry-en-4',1,'2023-11-04 15:43:14','2023-11-04 15:43:14','41e31e20-b91f-4586-89ac-d7d380fd1c92'),(81,81,1,'entry-en-4-2','statistics/entry-en-4-2',1,'2023-11-04 15:43:22','2023-11-04 15:43:22','025bfdbf-2ad8-446c-9589-526c14c5f1b2'),(82,82,1,'entry-en-4-2','statistics/entry-en-4-2',1,'2023-11-04 15:43:22','2023-11-04 15:43:22','1a2fcf96-5e9c-4fa3-8f11-f223c9ac445e'),(83,83,1,'entry-fr','statistics/entry-fr',1,'2023-11-04 15:43:34','2023-11-04 15:43:36','9648cf7e-5570-4607-aee8-edeefb4d3677'),(84,84,1,'entry-fr','statistics/entry-fr',1,'2023-11-04 15:43:53','2023-11-04 15:43:53','2a39c16e-569a-4e1b-a69b-4cce0c3de2ca'),(85,85,1,'entry-fr-2','statistics/entry-fr-2',1,'2023-11-04 15:43:57','2023-11-04 15:43:57','d58cbe27-f15c-4230-b86a-93cc16b35642'),(86,86,1,'entry-fr-2','statistics/entry-fr-2',1,'2023-11-04 15:43:57','2023-11-04 15:43:57','8352fcb8-5fa3-4ba4-b2a3-ad2c94c558af'),(87,87,1,'entry-fr-3','statistics/entry-fr-3',1,'2023-11-04 15:44:03','2023-11-04 15:44:03','639b014e-73ba-413f-8164-4155680371b8'),(88,88,1,'entry-fr-3','statistics/entry-fr-3',1,'2023-11-04 15:44:03','2023-11-04 15:44:03','d38a200a-c426-4553-8eee-79aa762d869e'),(89,89,1,'entry-fr-2-2','statistics/entry-fr-2-2',1,'2023-11-04 15:44:03','2023-11-04 15:44:03','5b1d9c1c-2336-492a-a92d-dbc5409f5f6a'),(90,90,1,'entry-fr-2-2','statistics/entry-fr-2-2',1,'2023-11-04 15:44:03','2023-11-04 15:44:03','2b97e6f3-285b-441c-8aa4-82bdd66d865d'),(91,91,1,'entry-fr-4','statistics/entry-fr-4',1,'2023-11-04 15:44:10','2023-11-04 15:44:10','5cca0319-506d-4c65-aac7-7830d0a1429e'),(92,92,1,'entry-fr-4','statistics/entry-fr-4',1,'2023-11-04 15:44:10','2023-11-04 15:44:10','4307b4a1-a9ac-499d-bcec-ee7f952e21ad'),(93,93,1,'entry-fr-2-3','statistics/entry-fr-2-3',1,'2023-11-04 15:44:10','2023-11-04 15:44:10','a295b405-7af4-4dd0-b992-1bc8bbedb3e1'),(94,94,1,'entry-fr-2-3','statistics/entry-fr-2-3',1,'2023-11-04 15:44:10','2023-11-04 15:44:10','d764de0c-cbbe-433e-9442-26fef0a552f9'),(95,95,1,'entry-fr-3-2','statistics/entry-fr-3-2',1,'2023-11-04 15:44:10','2023-11-04 15:44:10','2e24da2e-922e-4bb3-ab39-48ae87887c9b'),(96,96,1,'entry-fr-3-2','statistics/entry-fr-3-2',1,'2023-11-04 15:44:10','2023-11-04 15:44:10','6f000478-bb19-440b-afbe-f8cc3e8a2377'),(97,97,1,'entry-fr-2-3','statistics/entry-fr-2-3',1,'2023-11-04 15:44:25','2023-11-04 15:44:25','e91dd07b-f70e-42e4-91cc-304a9a8a1b76'),(99,99,1,'entry-fr-3-2','statistics/entry-fr-3-2',1,'2023-11-04 15:44:34','2023-11-04 15:44:34','c9bbf3af-d131-49c5-b11b-445b6d492a20'),(101,101,1,'entry-1','statistics/entry-1',1,'2023-11-04 15:54:32','2023-11-04 15:54:32','40122b2f-5981-4297-a3a3-6d6b7732111a'),(103,103,1,'entry-fr-2-3','statistics/entry-fr-2-3',1,'2023-11-04 16:21:02','2023-11-04 16:21:02','a6798b68-3459-417d-bf94-9e5631d01079'),(105,105,1,'entry-en-2-2','statistics/entry-en-2-2',1,'2023-11-04 17:13:06','2023-11-04 17:13:06','f0507b85-bb78-461d-b5ea-e67706d351dc'),(107,107,1,'entry-en-3','statistics/entry-en-3',1,'2023-11-04 17:13:15','2023-11-04 17:13:15','23c0db4f-b483-4c58-b427-ab755a3dae35'),(108,108,1,'entry-en-2-2','statistics/entry-en-2-2',1,'2023-11-04 17:13:34','2023-11-04 17:13:34','a4fe3a20-1a42-4e49-900f-6c25056dbcbf'),(110,110,1,'entry-fr-2-2','statistics/entry-fr-2-2',1,'2023-11-04 17:13:47','2023-11-04 17:13:47','ea4a25c8-9991-4912-bc9d-cf86eb56bcb9'),(112,112,1,'entry-fr-3','statistics/entry-fr-3',1,'2023-11-04 17:14:08','2023-11-04 17:14:08','2eeff5e4-4011-45d2-a604-66c644bcf705'),(114,114,1,'entry-fr-4','statistics/entry-fr-4',1,'2023-11-04 17:14:18','2023-11-04 17:14:18','fc986ecd-b0d1-462c-a3ff-cefe53ee924c'),(116,116,1,'entry-es-2-2','statistics/entry-es-2-2',1,'2023-11-04 17:19:47','2023-11-04 17:19:47','759f24c5-7a98-4cc7-b5f8-2d39469b742f'),(118,118,1,'hvar-festival','venues/hvar-festival',1,'2023-11-09 08:45:42','2023-11-09 08:46:03','01d71e6d-1ce7-4d96-bf14-6d6509172ab1'),(119,119,1,'hvar-festival','venues/hvar-festival',1,'2023-11-09 08:46:03','2023-11-09 08:46:03','0de92c2c-a1c8-4200-99fd-a6ce4068fed6'),(120,120,1,NULL,NULL,1,'2023-11-09 16:00:00','2023-11-09 16:00:00','aaaa24af-62e3-48b4-9dda-12ad3614fc4b'),(121,121,1,NULL,NULL,1,'2023-11-09 16:01:08','2023-11-09 16:01:08','7f0e038c-352b-4199-ad17-a885872d73c5'),(122,122,1,'entry-fr-2-3','statistics/entry-fr-2-3',1,'2023-11-09 17:34:47','2023-11-09 17:34:47','6d85dba7-ebb2-494d-947f-fa8fa590a5c5'),(124,124,1,'entry-fr-3-2','statistics/entry-fr-3-2',1,'2023-11-09 17:34:59','2023-11-09 17:34:59','e9161651-3c4a-4846-9079-a8990f79b0dc'),(126,126,1,'entry-fr-2-2','statistics/entry-fr-2-2',1,'2023-11-09 17:40:09','2023-11-09 17:40:09','56403c94-4603-49af-b06f-83b1fd817f07'),(128,128,1,'entry-fr-2-3','statistics/entry-fr-2-3',1,'2023-11-09 17:51:26','2023-11-09 17:51:26','18896683-b13d-450c-ae32-e4b0226cef40'),(130,130,1,'entry-fr-4','statistics/entry-fr-4',1,'2023-11-10 09:26:37','2023-11-10 09:26:37','0a6291d8-6977-4538-9797-4bab6987179d'),(132,132,1,'entry-en-4','statistics/entry-en-4',1,'2023-11-10 09:27:01','2023-11-10 09:27:01','9edcef2c-57c5-422d-b1d1-63b15de0bb8d'),(133,133,1,'entry-it','statistics/entry-it',1,'2023-11-10 09:30:11','2023-11-10 09:30:25','f4fa3b75-11bd-42fd-b477-fc577df10406'),(134,134,1,'headset-3','headsets/headset-3',1,'2023-11-10 09:30:38','2023-11-10 09:30:50','320dea8a-9504-49d8-b0d8-2c9ebb6910a6'),(135,135,1,'headset-3','headsets/headset-3',1,'2023-11-10 09:30:50','2023-11-10 09:30:50','f8abf43c-f957-4939-b358-efc4ba4600bb'),(136,136,1,'entry-it','statistics/entry-it',1,'2023-11-10 09:31:06','2023-11-10 09:31:06','03d845c7-1749-42f1-a74e-e04bcb8c4fbb'),(138,138,1,'entry-it','statistics/entry-it',1,'2023-11-10 09:31:16','2023-11-10 09:31:16','b1c4b0cf-deb1-4e97-a479-059acd0df8a0'),(140,140,1,'entry-3','statistics/entry-3',1,'2023-11-10 10:20:07','2023-11-10 10:20:07','99ec6ae8-f0a9-4a3b-9719-2dc610b32d72'),(142,142,1,'diocletian-museum','venues/diocletian-museum',1,'2023-11-11 09:05:55','2023-11-11 09:05:55','eb099e58-c3e5-490e-b362-355bae3fc08a'),(144,144,1,'hvar-festival','venues/hvar-festival',1,'2023-11-11 09:06:17','2023-11-11 09:06:17','bd5e2063-b457-4334-a89f-0db375eb55d1'),(146,146,1,'hub-367','venues/hub-367',1,'2023-11-11 09:06:32','2023-11-11 09:06:32','e11686d5-7160-4d4b-bc24-92340e028f62'),(147,147,1,'entry-it','statistics/entry-it',1,'2023-11-11 10:20:29','2023-11-11 10:20:29','c1ce1f23-2dda-4c37-a607-be6d8ed59702'),(149,149,1,'entry-fr','statistics/entry-fr',1,'2023-11-11 10:20:54','2023-11-11 10:20:54','7b01d543-6a77-47eb-9a78-be54a60404af'),(151,151,1,'entry-fr-3-2','statistics/entry-fr-3-2',1,'2023-11-11 10:21:13','2023-11-11 10:21:13','7955f28e-1d67-4bc8-8e7c-391fe23170cf'),(153,153,1,'entry-fr-3-2','statistics/entry-fr-3-2',1,'2023-11-11 10:21:29','2023-11-11 10:21:29','a848da94-a84a-456d-99e1-fedac8e18174'),(155,155,1,'entry-fr','statistics/entry-fr',1,'2023-11-11 10:22:20','2023-11-11 10:22:20','ac851615-6db0-4138-a251-24ed44d14b3b'),(157,157,1,'entry-fr-2','statistics/entry-fr-2',1,'2023-11-11 10:22:59','2023-11-11 10:22:59','92fb4a95-83c6-47f7-94ca-ba7846eae2b8'),(159,159,1,'entry-fr-3','statistics/entry-fr-3',1,'2023-11-11 10:23:22','2023-11-11 10:23:22','8977f5f3-cd5e-4e75-a076-3c7502006c17'),(161,161,1,'entry-fr-4','statistics/entry-fr-4',1,'2023-11-11 10:23:42','2023-11-11 10:23:42','230b1cd5-67c9-43c9-9cdc-662abdeb13a2'),(163,163,1,'entry-2','statistics/entry-2',1,'2023-11-11 10:23:58','2023-11-11 10:23:58','910ee62d-44d9-4dec-b614-f915856d6596'),(165,165,1,'hvar-festival','venues/hvar-festival',1,'2023-11-11 12:12:15','2023-11-11 12:12:15','f3f35cfd-9575-4b3f-90f9-3e6b1a89fd33'),(167,167,1,'diocletian-museum','venues/diocletian-museum',1,'2023-11-11 12:12:24','2023-11-11 12:12:24','624e9a1f-6dd9-46f2-8f33-4b1312cbc861'),(169,169,1,'hub-367','venues/hub-367',1,'2023-11-11 12:12:33','2023-11-11 12:12:33','60e3a470-ebc2-4c29-9b9e-e82b7e0b6b83'),(170,170,1,'graphql-entry-again','statistics/graphql-entry-again',1,'2023-11-12 16:37:46','2023-11-12 16:37:46','3c8b0a45-1b45-431b-b7af-4198c11c5e8e'),(171,171,1,'graphql-entry-again','statistics/graphql-entry-again',1,'2023-11-12 16:37:46','2023-11-12 16:37:46','2bc21e67-9d18-4d82-a621-743c08aa9f38'),(172,172,1,'graphql-entry-again-2','statistics/graphql-entry-again-2',1,'2023-11-12 16:37:53','2023-11-12 16:37:53','cae17bc6-87c6-4000-aa22-f5c5dea13065'),(173,173,1,'graphql-entry-again-2','statistics/graphql-entry-again-2',1,'2023-11-12 16:37:53','2023-11-12 16:37:53','45b6d79e-e426-4fb1-89ba-fb7718df8649'),(175,175,1,'graphql-entry-again-2','statistics/graphql-entry-again-2',1,'2023-11-12 16:39:01','2023-11-12 16:39:01','7e8c58de-8f96-4218-bb5b-9b93aa9dd368'),(176,176,1,'graphql-entry-again-3','statistics/graphql-entry-again-3',1,'2023-11-12 16:40:16','2023-11-12 16:40:16','d2f4911a-2b86-4799-9d3b-794622d8e37b'),(177,177,1,'graphql-entry-again-3','statistics/graphql-entry-again-3',1,'2023-11-12 16:40:16','2023-11-12 16:40:16','815f227c-aa0f-4e5e-a775-ef1c1e4db3c2'),(179,179,1,'graphql-entry-again','statistics/graphql-entry-again',1,'2023-11-12 16:40:43','2023-11-12 16:40:43','980cea52-02a9-49cd-b50b-87131f777baf'),(181,181,1,'graphql-entry-again-2','statistics/graphql-entry-again-2',1,'2023-11-12 16:41:15','2023-11-12 16:41:15','8581e2c8-c41e-4af1-b016-71ea194abb2d'),(183,183,1,'graphql-entry-again-3','statistics/graphql-entry-again-3',1,'2023-11-12 16:41:25','2023-11-12 16:41:25','529dcfb8-7470-4acd-a128-7e66744f0c55'),(186,186,1,'graphql-entry-again-4','statistics/graphql-entry-again-4',1,'2023-11-12 16:42:21','2023-11-12 16:42:21','ea96fb95-f75f-46ee-a3f3-039d03e72b94'),(187,187,1,'graphql-entry-again-4','statistics/graphql-entry-again-4',1,'2023-11-12 16:42:21','2023-11-12 16:42:21','0858a3c1-010e-4745-8f76-2c52f3be8d6c'),(188,188,1,'graphql-entry-again-5','statistics/graphql-entry-again-5',1,'2023-11-12 16:42:50','2023-11-12 16:42:50','c7b38f22-9dcc-4084-a1c3-877f0a3d5a90'),(189,189,1,'graphql-entry-again-5','statistics/graphql-entry-again-5',1,'2023-11-12 16:42:50','2023-11-12 16:42:50','0f5b45f0-e47a-4963-a844-4fdda10cf8bb'),(191,191,1,'graphql-entry-again-4','statistics/graphql-entry-again-4',1,'2023-11-12 16:43:15','2023-11-12 16:43:15','4504163a-6c88-4f60-85da-4806f9a82a2c'),(192,192,1,'graphql-jovana-again','statistics/graphql-jovana-again',1,'2023-11-12 16:43:29','2023-11-12 16:43:29','843e15ee-5785-4bd7-8ac4-a98a8258e22f'),(193,193,1,'graphql-jovana-again','statistics/graphql-jovana-again',1,'2023-11-12 16:43:29','2023-11-12 16:43:29','0e35d1ff-054c-4f41-8c00-224f0a13d950'),(194,194,1,'graphql-jovana-again-2','statistics/graphql-jovana-again-2',1,'2023-11-12 16:52:34','2023-11-12 16:52:34','2222826d-c601-4880-82b8-be646082853f'),(195,195,1,'graphql-jovana-again-2','statistics/graphql-jovana-again-2',1,'2023-11-12 16:52:34','2023-11-12 16:52:34','1eb6c0f6-d613-41f6-962a-2636b9b346b8'),(196,196,1,'graphql-jovana-again-3','statistics/graphql-jovana-again-3',1,'2023-11-12 16:52:45','2023-11-12 16:52:45','17cdf65b-c204-4b5b-854d-a8afe9dc5cb2'),(197,197,1,'graphql-jovana-again-3','statistics/graphql-jovana-again-3',1,'2023-11-12 16:52:45','2023-11-12 16:52:45','62efe05c-18b1-4350-ac70-e9f51e202ec0'),(198,198,1,'graphql-entry-again-6','statistics/graphql-entry-again-6',1,'2023-11-12 16:53:24','2023-11-12 16:53:24','1e224860-559d-425a-b026-a59ef4a0c237'),(199,199,1,'graphql-entry-again-6','statistics/graphql-entry-again-6',1,'2023-11-12 16:53:24','2023-11-12 16:53:24','1529a5c1-8386-418d-98ae-d98f1740584a'),(200,200,1,'__temp_ixlxooulelexehuqwmmvmawadeineurwnzsy','movies/__temp_ixlxooulelexehuqwmmvmawadeineurwnzsy',1,'2023-11-13 10:31:55','2023-11-13 10:31:55','15580b85-a4c5-405c-806f-e96188d99c94'),(201,201,1,'hvar-festival','venues/hvar-festival',1,'2023-11-15 19:00:00','2023-11-15 19:00:00','2ab53746-8ca4-4ecf-bebe-6cf84ce74017'),(202,202,1,'hvar-festival','venues/hvar-festival',1,'2023-11-15 19:00:09','2023-11-15 19:00:09','ac519892-7bbd-47b4-822b-0ddd138eac13'),(203,203,1,'test','venues/test',1,'2023-11-15 19:03:14','2023-11-15 19:03:14','fd3eb493-448b-47a9-915a-70eb79543b51'),(204,204,1,'test','venues/test',1,'2023-11-15 19:03:14','2023-11-15 19:03:14','de617352-a6ea-441a-9084-bd2828207e9c'),(205,205,1,'headset-4','headsets/headset-4',1,'2023-11-15 19:09:48','2023-11-15 19:09:48','95312dc8-b063-42bf-9c21-21a175159e8e'),(206,206,1,'headset-4','headsets/headset-4',1,'2023-11-15 19:09:48','2023-11-15 19:09:48','26e7e10f-d0bf-4377-9d00-aca703898d4b'),(207,207,1,'headset-4','headsets/headset-4',1,'2023-11-15 19:15:46','2023-11-15 19:15:46','5dd71a2f-306d-46f2-84a8-fd8561e7970d'),(208,208,1,'headset-5','headsets/headset-5',1,'2023-11-15 19:16:48','2023-11-15 19:16:48','b36c0eec-2865-4b3f-8790-949edb10eccb'),(209,209,1,'headset-5','headsets/headset-5',1,'2023-11-15 19:16:48','2023-11-15 19:16:48','1a956917-88a5-4aa5-af34-fd373eda3f55'),(211,211,1,'headset-5','headsets/headset-5',1,'2023-11-15 19:17:03','2023-11-15 19:17:03','ef200a50-560e-408b-b197-f82a495db2c3'),(212,212,1,'headset-5','headsets/headset-5',1,'2023-11-15 19:19:47','2023-11-15 19:19:47','78bdca5d-ee48-4f4e-9a1e-a2b64c17ff3c'),(213,213,1,'headset-5','headsets/headset-5',1,'2023-11-15 19:19:53','2023-11-15 19:19:53','a7051376-8ea8-4c29-affc-0383d325b093'),(214,214,1,'headset-4','headsets/headset-4',1,'2023-11-15 19:21:55','2023-11-15 19:21:55','74d248ee-064a-408c-b169-2dfd1d5ff69c'),(215,215,1,'headset-4','headsets/headset-4',1,'2023-11-15 19:26:21','2023-11-15 19:26:21','2a1ef712-c1ba-4c91-bda1-c49278ee30e4'),(216,216,1,'headset-5','headsets/headset-5',1,'2023-11-15 19:26:26','2023-11-15 19:26:26','c2796544-1311-43cc-8e78-ae26a35c08d2'),(217,217,1,'headset-5','headsets/headset-5',1,'2023-11-15 19:28:48','2023-11-15 19:28:48','0d290db2-1af0-4d2f-9aae-254230f2367b'),(218,218,1,'headset-4','headsets/headset-4',1,'2023-11-15 19:28:53','2023-11-15 19:28:53','277a4a6c-e430-4232-998f-039082c81ac9'),(219,219,1,'headset-4','headsets/headset-4',1,'2023-11-15 19:28:58','2023-11-15 19:28:58','5bb9094c-1b08-42bc-929e-51e9457e5b8b'),(220,220,1,'headset-6','headsets/headset-6',1,'2023-11-15 19:31:11','2023-11-15 19:31:11','576efbeb-8127-4dfa-a1bd-ca1c892d13b8'),(221,221,1,'headset-6','headsets/headset-6',1,'2023-11-15 19:31:11','2023-11-15 19:31:11','da970e2f-6353-4606-8591-0694bf2101cd'),(222,222,1,'headset-6','headsets/headset-6',1,'2023-11-15 19:34:51','2023-11-15 19:34:51','eb894270-60a6-40b7-b5e8-da468d70b2f3'),(223,223,1,'headset-4','headsets/headset-4',1,'2023-11-15 19:34:56','2023-11-15 19:34:56','e94488f1-26a4-42b6-9e15-477e98f7aedb'),(224,224,1,'headset-4','headsets/headset-4',1,'2023-11-15 19:35:04','2023-11-15 19:35:04','a7deac6d-a516-4fd9-84ee-281359ebbced');
/*!40000 ALTER TABLE `elements_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entries`
--

DROP TABLE IF EXISTS `entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entries` (
  `id` int NOT NULL,
  `sectionId` int NOT NULL,
  `parentId` int DEFAULT NULL,
  `typeId` int NOT NULL,
  `authorId` int DEFAULT NULL,
  `postDate` datetime DEFAULT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `deletedWithEntryType` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_zuoijhoqqyqxmgokrpncefcrqpfsvfdewcsb` (`postDate`),
  KEY `idx_nevvckpamwywrkivdbfdghudmgmcfgqilubg` (`expiryDate`),
  KEY `idx_biwmpzhalreusnrqmywmygfecdyitblltyqc` (`authorId`),
  KEY `idx_ktdjavronzjivakqlxzypidvsuhhcebxairu` (`sectionId`),
  KEY `idx_ibzgfmteitluvkgiiqqumygfhexgdqlitgsn` (`typeId`),
  KEY `fk_auenmptwsfbbyvbtssfywnkwkehuqapwmign` (`parentId`),
  CONSTRAINT `fk_auenmptwsfbbyvbtssfywnkwkehuqapwmign` FOREIGN KEY (`parentId`) REFERENCES `entries` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_prjklzluvhbdvknswwgplmfwxvwmahphjexn` FOREIGN KEY (`typeId`) REFERENCES `entrytypes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_sdnevzkiaxivwygvofcreiyfyurzjhvnsgtz` FOREIGN KEY (`authorId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_ywfexmbpeqifsztukyjrsfgugzgfvxpdlfls` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zdsvwvpccwvhlmewfjsohioluubdxjpiyvrb` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entries`
--

LOCK TABLES `entries` WRITE;
/*!40000 ALTER TABLE `entries` DISABLE KEYS */;
INSERT INTO `entries` VALUES (2,2,NULL,3,1,'2023-11-04 15:29:00',NULL,NULL,'2023-11-04 15:29:16','2023-11-04 15:29:41'),(3,2,NULL,3,1,'2023-11-04 15:29:00',NULL,NULL,'2023-11-04 15:29:41','2023-11-04 15:29:41'),(4,3,NULL,2,120,'2023-11-04 15:30:00',NULL,NULL,'2023-11-04 15:30:16','2023-11-11 12:12:33'),(5,3,NULL,2,1,'2023-11-04 15:30:00',NULL,NULL,'2023-11-04 15:30:31','2023-11-04 15:30:31'),(6,3,NULL,2,121,'2023-11-04 15:30:00',NULL,NULL,'2023-11-04 15:30:34','2023-11-11 12:12:24'),(7,3,NULL,2,1,'2023-11-04 15:30:00',NULL,NULL,'2023-11-04 15:30:46','2023-11-04 15:30:46'),(8,1,NULL,1,1,'2023-11-04 15:30:53',NULL,NULL,'2023-11-04 15:30:53','2023-11-04 15:30:53'),(9,2,NULL,3,121,'2023-11-04 15:31:00',NULL,NULL,'2023-11-04 15:31:02','2023-11-11 10:23:58'),(10,2,NULL,3,1,'2023-11-04 15:31:00',NULL,NULL,'2023-11-04 15:31:26','2023-11-04 15:31:26'),(11,2,NULL,3,1,'2023-11-04 15:31:00',NULL,NULL,'2023-11-04 15:31:28','2023-11-04 15:31:59'),(12,2,NULL,3,1,'2023-11-04 15:31:00',NULL,NULL,'2023-11-04 15:31:59','2023-11-04 15:31:59'),(13,1,NULL,1,1,'2023-11-04 15:34:00',NULL,NULL,'2023-11-04 15:33:52','2023-11-04 15:34:00'),(14,1,NULL,1,1,'2023-11-04 15:34:00',NULL,NULL,'2023-11-04 15:34:00','2023-11-04 15:34:00'),(15,1,NULL,1,1,'2023-11-04 15:34:00',NULL,NULL,'2023-11-04 15:34:02','2023-11-04 15:34:09'),(16,1,NULL,1,1,'2023-11-04 15:34:00',NULL,NULL,'2023-11-04 15:34:09','2023-11-04 15:34:09'),(18,4,NULL,4,1,'2023-11-04 15:34:00',NULL,NULL,'2023-11-04 15:34:26','2023-11-04 15:34:33'),(19,4,NULL,4,1,'2023-11-04 15:34:00',NULL,NULL,'2023-11-04 15:34:33','2023-11-04 15:34:33'),(20,2,NULL,3,1,'2023-11-04 15:29:00',NULL,NULL,'2023-11-04 15:34:40','2023-11-04 15:34:40'),(22,2,NULL,3,1,'2023-11-04 15:29:00',NULL,NULL,'2023-11-04 15:36:17','2023-11-04 15:36:17'),(24,4,NULL,4,1,'2023-11-04 15:36:00',NULL,NULL,'2023-11-04 15:36:27','2023-11-04 15:36:33'),(25,4,NULL,4,1,'2023-11-04 15:36:00',NULL,NULL,'2023-11-04 15:36:34','2023-11-04 15:36:34'),(26,2,NULL,3,1,'2023-11-04 15:31:00',NULL,NULL,'2023-11-04 15:36:50','2023-11-04 15:36:50'),(28,2,NULL,3,1,'2023-11-04 15:31:00',NULL,NULL,'2023-11-04 15:37:01','2023-11-04 15:37:01'),(30,2,NULL,3,1,'2023-11-04 15:31:00',NULL,NULL,'2023-11-04 15:37:25','2023-11-04 15:37:25'),(31,2,NULL,3,1,'2023-11-04 15:38:00',NULL,NULL,'2023-11-04 15:37:41','2023-11-04 15:38:04'),(32,2,NULL,3,1,'2023-11-04 15:38:00',NULL,NULL,'2023-11-04 15:38:04','2023-11-04 15:38:04'),(33,2,NULL,3,1,'2023-11-04 15:38:00',NULL,NULL,'2023-11-04 15:38:19','2023-11-04 15:38:38'),(34,2,NULL,3,1,'2023-11-04 15:38:00',NULL,NULL,'2023-11-04 15:38:38','2023-11-04 15:38:38'),(36,2,NULL,3,1,'2023-11-04 15:38:00',NULL,NULL,'2023-11-04 15:38:45','2023-11-04 15:38:45'),(37,2,NULL,3,1,'2023-11-04 15:39:00',NULL,NULL,'2023-11-04 15:38:47','2023-11-04 15:39:19'),(38,1,NULL,1,1,'2023-11-04 15:39:00',NULL,NULL,'2023-11-04 15:38:56','2023-11-04 15:39:06'),(39,1,NULL,1,1,'2023-11-04 15:39:00',NULL,NULL,'2023-11-04 15:39:06','2023-11-04 15:39:06'),(40,2,NULL,3,1,'2023-11-04 15:39:00',NULL,NULL,'2023-11-04 15:39:19','2023-11-04 15:39:19'),(41,2,NULL,3,1,'2023-11-04 15:39:00',NULL,NULL,'2023-11-04 15:39:21','2023-11-04 15:39:48'),(42,2,NULL,3,1,'2023-11-04 15:39:00',NULL,NULL,'2023-11-04 15:39:48','2023-11-04 15:39:48'),(43,2,NULL,3,1,'2023-11-04 15:39:00',NULL,NULL,'2023-11-04 15:40:11','2023-11-04 15:40:11'),(44,2,NULL,3,1,'2023-11-04 15:39:00',NULL,NULL,'2023-11-04 15:40:12','2023-11-04 15:40:12'),(45,2,NULL,3,1,'2023-11-04 15:39:00',NULL,NULL,'2023-11-04 15:40:12','2023-11-04 15:40:12'),(46,2,NULL,3,1,'2023-11-04 15:39:00',NULL,NULL,'2023-11-04 15:40:12','2023-11-04 15:40:12'),(47,2,NULL,3,1,'2023-11-04 15:39:00',NULL,NULL,'2023-11-04 15:40:50','2023-11-04 15:40:50'),(48,2,NULL,3,1,'2023-11-04 15:39:00',NULL,NULL,'2023-11-04 15:40:50','2023-11-04 15:40:50'),(49,2,NULL,3,1,'2023-11-04 15:39:00',NULL,NULL,'2023-11-04 15:40:50','2023-11-04 15:40:50'),(50,2,NULL,3,1,'2023-11-04 15:39:00',NULL,NULL,'2023-11-04 15:40:50','2023-11-04 15:40:50'),(51,2,NULL,3,1,'2023-11-04 15:41:00',NULL,NULL,'2023-11-04 15:41:09','2023-11-04 15:41:31'),(52,2,NULL,3,1,'2023-11-04 15:41:00',NULL,NULL,'2023-11-04 15:41:31','2023-11-04 15:41:31'),(53,2,NULL,3,1,'2023-11-04 15:41:00',NULL,NULL,'2023-11-04 15:41:43','2023-11-04 15:41:43'),(54,2,NULL,3,1,'2023-11-04 15:41:00',NULL,NULL,'2023-11-04 15:41:43','2023-11-04 15:41:43'),(55,2,NULL,3,1,'2023-11-04 15:41:00',NULL,NULL,'2023-11-04 15:41:47','2023-11-04 15:41:47'),(56,2,NULL,3,1,'2023-11-04 15:41:00',NULL,NULL,'2023-11-04 15:41:47','2023-11-04 15:41:47'),(57,2,NULL,3,1,'2023-11-04 15:41:00',NULL,NULL,'2023-11-04 15:41:47','2023-11-04 15:41:47'),(58,2,NULL,3,1,'2023-11-04 15:41:00',NULL,NULL,'2023-11-04 15:41:47','2023-11-04 15:41:47'),(59,2,NULL,3,1,'2023-11-04 15:41:00',NULL,NULL,'2023-11-04 15:41:51','2023-11-04 15:41:51'),(60,2,NULL,3,1,'2023-11-04 15:41:00',NULL,NULL,'2023-11-04 15:41:52','2023-11-04 15:41:52'),(61,2,NULL,3,1,'2023-11-04 15:41:00',NULL,NULL,'2023-11-04 15:41:52','2023-11-04 15:41:52'),(62,2,NULL,3,1,'2023-11-04 15:41:00',NULL,NULL,'2023-11-04 15:41:52','2023-11-04 15:41:52'),(63,2,NULL,3,1,'2023-11-04 15:41:00',NULL,NULL,'2023-11-04 15:41:52','2023-11-04 15:41:52'),(64,2,NULL,3,1,'2023-11-04 15:41:00',NULL,NULL,'2023-11-04 15:41:52','2023-11-04 15:41:52'),(65,2,NULL,3,1,'2023-11-04 15:41:00',NULL,NULL,'2023-11-04 15:41:52','2023-11-04 15:41:52'),(66,2,NULL,3,1,'2023-11-04 15:41:00',NULL,NULL,'2023-11-04 15:41:52','2023-11-04 15:41:52'),(67,2,NULL,3,1,'2023-11-04 15:42:00',NULL,NULL,'2023-11-04 15:42:07','2023-11-04 15:42:35'),(68,2,NULL,3,1,'2023-11-04 15:42:00',NULL,NULL,'2023-11-04 15:42:35','2023-11-04 15:42:35'),(69,2,NULL,3,1,'2023-11-04 15:42:00',NULL,NULL,'2023-11-04 15:42:40','2023-11-04 15:42:40'),(70,2,NULL,3,1,'2023-11-04 15:42:00',NULL,NULL,'2023-11-04 15:42:40','2023-11-04 15:42:40'),(72,2,NULL,3,1,'2023-11-04 15:42:00',NULL,NULL,'2023-11-04 15:42:51','2023-11-04 15:42:51'),(73,2,NULL,3,1,'2023-11-04 15:42:00',NULL,NULL,'2023-11-04 15:42:56','2023-11-04 15:42:56'),(74,2,NULL,3,1,'2023-11-04 15:42:00',NULL,NULL,'2023-11-04 15:42:56','2023-11-04 15:42:56'),(75,2,NULL,3,1,'2023-11-04 15:42:00',NULL,NULL,'2023-11-04 15:42:59','2023-11-04 15:42:59'),(76,2,NULL,3,1,'2023-11-04 15:42:00',NULL,NULL,'2023-11-04 15:42:59','2023-11-04 15:42:59'),(77,2,NULL,3,1,'2023-11-04 15:42:00',NULL,NULL,'2023-11-04 15:42:59','2023-11-04 15:42:59'),(78,2,NULL,3,1,'2023-11-04 15:42:00',NULL,NULL,'2023-11-04 15:42:59','2023-11-04 15:42:59'),(80,2,NULL,3,1,'2023-11-04 15:42:00',NULL,NULL,'2023-11-04 15:43:14','2023-11-04 15:43:14'),(81,2,NULL,3,1,'2023-11-04 15:42:00',NULL,NULL,'2023-11-04 15:43:22','2023-11-04 15:43:22'),(82,2,NULL,3,1,'2023-11-04 15:42:00',NULL,NULL,'2023-11-04 15:43:22','2023-11-04 15:43:22'),(83,2,NULL,3,121,'2023-11-04 15:43:00',NULL,NULL,'2023-11-04 15:43:34','2023-11-11 10:22:20'),(84,2,NULL,3,1,'2023-11-04 15:43:00',NULL,NULL,'2023-11-04 15:43:53','2023-11-04 15:43:53'),(85,2,NULL,3,121,'2023-11-04 15:43:00',NULL,NULL,'2023-11-04 15:43:57','2023-11-11 10:22:59'),(86,2,NULL,3,1,'2023-11-04 15:43:00',NULL,NULL,'2023-11-04 15:43:57','2023-11-04 15:43:57'),(87,2,NULL,3,121,'2023-11-04 15:43:00',NULL,NULL,'2023-11-04 15:44:03','2023-11-11 10:23:22'),(88,2,NULL,3,1,'2023-11-04 15:43:00',NULL,NULL,'2023-11-04 15:44:03','2023-11-04 15:44:03'),(89,2,NULL,3,120,'2023-11-04 15:43:00',NULL,NULL,'2023-11-04 15:44:03','2023-11-09 17:40:09'),(90,2,NULL,3,1,'2023-11-04 15:43:00',NULL,NULL,'2023-11-04 15:44:03','2023-11-04 15:44:03'),(91,2,NULL,3,121,'2023-11-04 15:43:00',NULL,NULL,'2023-11-04 15:44:10','2023-11-11 10:23:42'),(92,2,NULL,3,1,'2023-11-04 15:43:00',NULL,NULL,'2023-11-04 15:44:10','2023-11-04 15:44:10'),(93,2,NULL,3,121,'2023-11-04 15:43:00',NULL,NULL,'2023-11-04 15:44:10','2023-11-09 17:34:47'),(94,2,NULL,3,1,'2023-11-04 15:43:00',NULL,NULL,'2023-11-04 15:44:10','2023-11-04 15:44:10'),(95,2,NULL,3,121,'2023-11-04 15:43:00',NULL,NULL,'2023-11-04 15:44:10','2023-11-09 17:34:59'),(96,2,NULL,3,1,'2023-11-04 15:43:00',NULL,NULL,'2023-11-04 15:44:10','2023-11-04 15:44:10'),(97,2,NULL,3,1,'2023-11-04 15:43:00',NULL,NULL,'2023-11-04 15:44:25','2023-11-04 15:44:25'),(99,2,NULL,3,1,'2023-11-04 15:43:00',NULL,NULL,'2023-11-04 15:44:34','2023-11-04 15:44:34'),(101,2,NULL,3,1,'2023-11-04 15:29:00',NULL,NULL,'2023-11-04 15:54:32','2023-11-04 15:54:32'),(103,2,NULL,3,1,'2023-11-04 15:43:00',NULL,NULL,'2023-11-04 16:21:02','2023-11-04 16:21:02'),(105,2,NULL,3,1,'2023-11-04 15:42:00',NULL,NULL,'2023-11-04 17:13:06','2023-11-04 17:13:06'),(107,2,NULL,3,1,'2023-11-04 15:42:00',NULL,NULL,'2023-11-04 17:13:15','2023-11-04 17:13:15'),(108,2,NULL,3,1,'2023-11-04 15:42:00',NULL,NULL,'2023-11-04 17:13:34','2023-11-04 17:13:34'),(110,2,NULL,3,1,'2023-11-04 15:43:00',NULL,NULL,'2023-11-04 17:13:47','2023-11-04 17:13:47'),(112,2,NULL,3,1,'2023-11-04 15:43:00',NULL,NULL,'2023-11-04 17:14:08','2023-11-04 17:14:08'),(114,2,NULL,3,1,'2023-11-04 15:43:00',NULL,NULL,'2023-11-04 17:14:18','2023-11-04 17:14:18'),(116,2,NULL,3,1,'2023-11-04 15:41:00',NULL,NULL,'2023-11-04 17:19:47','2023-11-04 17:19:47'),(118,3,NULL,2,121,'2023-11-09 08:46:00',NULL,NULL,'2023-11-09 08:45:42','2023-11-11 12:12:15'),(119,3,NULL,2,1,'2023-11-09 08:46:00',NULL,NULL,'2023-11-09 08:46:03','2023-11-09 08:46:03'),(122,2,NULL,3,121,'2023-11-04 15:43:00',NULL,NULL,'2023-11-09 17:34:47','2023-11-09 17:34:47'),(124,2,NULL,3,121,'2023-11-04 15:43:00',NULL,NULL,'2023-11-09 17:34:59','2023-11-09 17:34:59'),(126,2,NULL,3,120,'2023-11-04 15:43:00',NULL,NULL,'2023-11-09 17:40:09','2023-11-09 17:40:09'),(128,2,NULL,3,121,'2023-11-04 15:43:00',NULL,NULL,'2023-11-09 17:51:26','2023-11-09 17:51:26'),(130,2,NULL,3,1,'2023-11-04 15:43:00',NULL,NULL,'2023-11-10 09:26:37','2023-11-10 09:26:37'),(132,2,NULL,3,1,'2023-11-04 15:42:00',NULL,NULL,'2023-11-10 09:27:01','2023-11-10 09:27:01'),(133,2,NULL,3,121,'2023-11-10 09:31:00',NULL,NULL,'2023-11-10 09:30:11','2023-11-10 09:31:16'),(134,1,NULL,1,1,'2023-11-10 09:30:00',NULL,NULL,'2023-11-10 09:30:38','2023-11-10 09:30:50'),(135,1,NULL,1,1,'2023-11-10 09:30:00',NULL,NULL,'2023-11-10 09:30:50','2023-11-10 09:30:50'),(136,2,NULL,3,1,'2023-11-10 09:31:00',NULL,NULL,'2023-11-10 09:31:06','2023-11-10 09:31:06'),(138,2,NULL,3,121,'2023-11-10 09:31:00',NULL,NULL,'2023-11-10 09:31:16','2023-11-10 09:31:16'),(140,2,NULL,3,1,'2023-11-04 15:31:00',NULL,NULL,'2023-11-10 10:20:07','2023-11-10 10:20:07'),(142,3,NULL,2,1,'2023-11-04 15:30:00',NULL,NULL,'2023-11-11 09:05:55','2023-11-11 09:05:55'),(144,3,NULL,2,1,'2023-11-09 08:46:00',NULL,NULL,'2023-11-11 09:06:17','2023-11-11 09:06:17'),(146,3,NULL,2,1,'2023-11-04 15:30:00',NULL,NULL,'2023-11-11 09:06:32','2023-11-11 09:06:32'),(147,2,NULL,3,121,'2023-11-10 09:31:00',NULL,NULL,'2023-11-11 10:20:29','2023-11-11 10:20:29'),(149,2,NULL,3,1,'2023-11-04 15:43:00',NULL,NULL,'2023-11-11 10:20:54','2023-11-11 10:20:54'),(151,2,NULL,3,121,'2023-11-04 15:43:00',NULL,NULL,'2023-11-11 10:21:13','2023-11-11 10:21:13'),(153,2,NULL,3,121,'2023-11-04 15:43:00',NULL,NULL,'2023-11-11 10:21:29','2023-11-11 10:21:29'),(155,2,NULL,3,121,'2023-11-04 15:43:00',NULL,NULL,'2023-11-11 10:22:20','2023-11-11 10:22:20'),(157,2,NULL,3,121,'2023-11-04 15:43:00',NULL,NULL,'2023-11-11 10:22:59','2023-11-11 10:22:59'),(159,2,NULL,3,121,'2023-11-04 15:43:00',NULL,NULL,'2023-11-11 10:23:22','2023-11-11 10:23:22'),(161,2,NULL,3,121,'2023-11-04 15:43:00',NULL,NULL,'2023-11-11 10:23:42','2023-11-11 10:23:42'),(163,2,NULL,3,121,'2023-11-04 15:31:00',NULL,NULL,'2023-11-11 10:23:58','2023-11-11 10:23:58'),(165,3,NULL,2,121,'2023-11-09 08:46:00',NULL,NULL,'2023-11-11 12:12:15','2023-11-11 12:12:15'),(167,3,NULL,2,121,'2023-11-04 15:30:00',NULL,NULL,'2023-11-11 12:12:24','2023-11-11 12:12:24'),(169,3,NULL,2,120,'2023-11-04 15:30:00',NULL,NULL,'2023-11-11 12:12:33','2023-11-11 12:12:33'),(170,2,NULL,3,120,'2023-11-12 16:37:00',NULL,NULL,'2023-11-12 16:37:46','2023-11-12 16:40:43'),(171,2,NULL,3,1,'2023-11-12 16:37:00',NULL,NULL,'2023-11-12 16:37:46','2023-11-12 16:37:46'),(172,2,NULL,3,120,'2023-11-12 16:37:00',NULL,NULL,'2023-11-12 16:37:53','2023-11-12 16:41:15'),(173,2,NULL,3,1,'2023-11-12 16:37:00',NULL,NULL,'2023-11-12 16:37:53','2023-11-12 16:37:53'),(175,2,NULL,3,121,'2023-11-12 16:37:00',NULL,NULL,'2023-11-12 16:39:01','2023-11-12 16:39:01'),(176,2,NULL,3,120,'2023-11-12 16:40:00',NULL,NULL,'2023-11-12 16:40:16','2023-11-12 16:41:25'),(177,2,NULL,3,121,'2023-11-12 16:40:00',NULL,NULL,'2023-11-12 16:40:16','2023-11-12 16:40:16'),(179,2,NULL,3,120,'2023-11-12 16:37:00',NULL,NULL,'2023-11-12 16:40:43','2023-11-12 16:40:43'),(181,2,NULL,3,120,'2023-11-12 16:37:00',NULL,NULL,'2023-11-12 16:41:15','2023-11-12 16:41:15'),(183,2,NULL,3,120,'2023-11-12 16:40:00',NULL,NULL,'2023-11-12 16:41:25','2023-11-12 16:41:25'),(186,2,NULL,3,120,'2023-11-12 16:42:00',NULL,NULL,'2023-11-12 16:42:21','2023-11-12 16:43:15'),(187,2,NULL,3,121,'2023-11-12 16:42:00',NULL,NULL,'2023-11-12 16:42:21','2023-11-12 16:42:21'),(188,2,NULL,3,120,'2023-11-12 16:42:00',NULL,NULL,'2023-11-12 16:42:50','2023-11-12 16:42:50'),(189,2,NULL,3,120,'2023-11-12 16:42:00',NULL,NULL,'2023-11-12 16:42:50','2023-11-12 16:42:50'),(191,2,NULL,3,120,'2023-11-12 16:42:00',NULL,NULL,'2023-11-12 16:43:15','2023-11-12 16:43:15'),(192,2,NULL,3,120,'2023-11-12 16:43:00',NULL,NULL,'2023-11-12 16:43:29','2023-11-12 16:43:29'),(193,2,NULL,3,120,'2023-11-12 16:43:00',NULL,NULL,'2023-11-12 16:43:29','2023-11-12 16:43:29'),(194,2,NULL,3,120,'2023-11-12 16:52:00',NULL,NULL,'2023-11-12 16:52:34','2023-11-12 16:52:34'),(195,2,NULL,3,120,'2023-11-12 16:52:00',NULL,NULL,'2023-11-12 16:52:34','2023-11-12 16:52:34'),(196,2,NULL,3,120,'2023-11-12 16:52:00',NULL,NULL,'2023-11-12 16:52:45','2023-11-12 16:52:45'),(197,2,NULL,3,120,'2023-11-12 16:52:00',NULL,NULL,'2023-11-12 16:52:45','2023-11-12 16:52:45'),(198,2,NULL,3,120,'2023-11-12 16:53:00',NULL,NULL,'2023-11-12 16:53:24','2023-11-12 16:53:24'),(199,2,NULL,3,120,'2023-11-12 16:53:00',NULL,NULL,'2023-11-12 16:53:24','2023-11-12 16:53:24'),(200,4,NULL,4,1,'2023-11-13 10:31:55',NULL,NULL,'2023-11-13 10:31:55','2023-11-13 10:31:55'),(201,3,NULL,2,121,'2023-11-09 08:46:00',NULL,NULL,'2023-11-15 19:00:00','2023-11-15 19:00:00'),(202,3,NULL,2,121,'2023-11-09 08:46:00',NULL,NULL,'2023-11-15 19:00:09','2023-11-15 19:00:09'),(203,3,NULL,2,121,'2023-11-15 19:03:00',NULL,NULL,'2023-11-15 19:03:14','2023-11-15 19:03:14'),(204,3,NULL,2,121,'2023-11-15 19:03:00',NULL,NULL,'2023-11-15 19:03:14','2023-11-15 19:03:14'),(205,1,NULL,1,121,'2023-11-15 19:09:00',NULL,NULL,'2023-11-15 19:09:48','2023-11-15 19:09:48'),(206,1,NULL,1,121,'2023-11-15 19:09:00',NULL,NULL,'2023-11-15 19:09:48','2023-11-15 19:09:48'),(207,1,NULL,1,121,'2023-11-15 19:09:00',NULL,NULL,'2023-11-15 19:15:46','2023-11-15 19:15:46'),(208,1,NULL,1,121,'2023-11-15 19:16:00',NULL,NULL,'2023-11-15 19:16:48','2023-11-15 19:16:48'),(209,1,NULL,1,121,'2023-11-15 19:16:00',NULL,NULL,'2023-11-15 19:16:48','2023-11-15 19:16:48'),(211,1,NULL,1,121,'2023-11-15 19:16:00',NULL,NULL,'2023-11-15 19:17:03','2023-11-15 19:17:03'),(212,1,NULL,1,121,'2023-11-15 19:16:00',NULL,NULL,'2023-11-15 19:19:47','2023-11-15 19:19:47'),(213,1,NULL,1,121,'2023-11-15 19:16:00',NULL,NULL,'2023-11-15 19:19:53','2023-11-15 19:19:53'),(214,1,NULL,1,121,'2023-11-15 19:09:00',NULL,NULL,'2023-11-15 19:21:55','2023-11-15 19:21:55'),(215,1,NULL,1,121,'2023-11-15 19:09:00',NULL,NULL,'2023-11-15 19:26:21','2023-11-15 19:26:21'),(216,1,NULL,1,121,'2023-11-15 19:16:00',NULL,NULL,'2023-11-15 19:26:26','2023-11-15 19:26:26'),(217,1,NULL,1,121,'2023-11-15 19:16:00',NULL,NULL,'2023-11-15 19:28:48','2023-11-15 19:28:48'),(218,1,NULL,1,121,'2023-11-15 19:09:00',NULL,NULL,'2023-11-15 19:28:53','2023-11-15 19:28:53'),(219,1,NULL,1,121,'2023-11-15 19:09:00',NULL,NULL,'2023-11-15 19:28:58','2023-11-15 19:28:58'),(220,1,NULL,1,121,'2023-11-15 19:31:00',NULL,NULL,'2023-11-15 19:31:11','2023-11-15 19:31:11'),(221,1,NULL,1,121,'2023-11-15 19:31:00',NULL,NULL,'2023-11-15 19:31:11','2023-11-15 19:31:11'),(222,1,NULL,1,121,'2023-11-15 19:31:00',NULL,NULL,'2023-11-15 19:34:51','2023-11-15 19:34:51'),(223,1,NULL,1,121,'2023-11-15 19:09:00',NULL,NULL,'2023-11-15 19:34:56','2023-11-15 19:34:56'),(224,1,NULL,1,121,'2023-11-15 19:09:00',NULL,NULL,'2023-11-15 19:35:04','2023-11-15 19:35:04');
/*!40000 ALTER TABLE `entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entrytypes`
--

DROP TABLE IF EXISTS `entrytypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entrytypes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sectionId` int NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `hasTitleField` tinyint(1) NOT NULL DEFAULT '1',
  `titleTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text,
  `titleFormat` varchar(255) DEFAULT NULL,
  `slugTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `slugTranslationKeyFormat` text,
  `showStatusField` tinyint(1) DEFAULT '1',
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_qcylxmwwuslokqrbcaonctjxkjfncemtvevs` (`name`,`sectionId`),
  KEY `idx_kfgzfluyjsmyvjviyewiorvvgemtkkevgufa` (`handle`,`sectionId`),
  KEY `idx_yqayqyaxlrizmwmabocmwkonkaiplvcopjuq` (`sectionId`),
  KEY `idx_cjupebruxbxilllpcqwssibtxytftqvnjqiz` (`fieldLayoutId`),
  KEY `idx_zufmheiynwiznloglagnfavyvpwpkeuygvfs` (`dateDeleted`),
  CONSTRAINT `fk_mmnnfdntddvnmoqznanwtastkcfwgdopamiu` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_vtudorxefptsevpzunhjehatpsevdhvivwfq` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entrytypes`
--

LOCK TABLES `entrytypes` WRITE;
/*!40000 ALTER TABLE `entrytypes` DISABLE KEYS */;
INSERT INTO `entrytypes` VALUES (1,1,1,'Default','default',1,'site',NULL,NULL,'site',NULL,1,1,'2023-11-04 14:04:28','2023-11-04 14:04:28',NULL,'17e706db-ccd3-4eab-9d3a-e8e5fed9d10a'),(2,3,2,'Default','default',1,'site',NULL,NULL,'site',NULL,1,1,'2023-11-04 14:04:28','2023-11-04 14:04:28',NULL,'6e395cf4-c9ab-4960-8c68-62b6bbcf4714'),(3,2,3,'Default','default',1,'site',NULL,NULL,'site',NULL,1,1,'2023-11-04 14:04:28','2023-11-04 14:04:28',NULL,'df793da0-9723-422b-a370-2e9c303381d0'),(4,4,6,'Default','default',1,'site',NULL,NULL,'site',NULL,1,1,'2023-11-04 15:32:15','2023-11-04 15:32:15',NULL,'a7b7e1ba-7fb3-4258-8a31-c45adeaf82b8');
/*!40000 ALTER TABLE `entrytypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fieldgroups`
--

DROP TABLE IF EXISTS `fieldgroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fieldgroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_ltnkeouzjksyvzzcwjwxfwbrgkiyextmgdoe` (`name`),
  KEY `idx_ctactxcqunthstuuxoypxxlwibetpuwpmrmi` (`dateDeleted`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fieldgroups`
--

LOCK TABLES `fieldgroups` WRITE;
/*!40000 ALTER TABLE `fieldgroups` DISABLE KEYS */;
INSERT INTO `fieldgroups` VALUES (1,'Common','2023-11-04 14:04:27','2023-11-04 14:04:27',NULL,'70c63edf-2fc7-463d-bef9-779cc51b7d25'),(2,'Users','2023-11-04 14:04:27','2023-11-04 14:04:27',NULL,'6107f7f5-b967-4eff-900d-72acac322b28'),(3,'Venues','2023-11-04 14:04:27','2023-11-04 14:04:27',NULL,'cfe8b169-e903-42f6-92ac-f4af56aa1ab8'),(4,'Statistics','2023-11-04 14:04:27','2023-11-04 14:04:27',NULL,'d4460fc8-b976-4652-92d2-7d820d7502ef');
/*!40000 ALTER TABLE `fieldgroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fieldlayoutfields`
--

DROP TABLE IF EXISTS `fieldlayoutfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fieldlayoutfields` (
  `id` int NOT NULL AUTO_INCREMENT,
  `layoutId` int NOT NULL,
  `tabId` int NOT NULL,
  `fieldId` int NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT '0',
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_kvqefuzrlgusauvlsuicotwdegfvahbtsrej` (`layoutId`,`fieldId`),
  KEY `idx_xnbtvbcbkhcojslqouxfwbdycsaeacobofia` (`sortOrder`),
  KEY `idx_hjrriwyqvwkclspmqiafcupaegcsodjljirr` (`tabId`),
  KEY `idx_xitfxfiawwsdslqevfylvwfnjucsoiberngb` (`fieldId`),
  CONSTRAINT `fk_dntbrgaostwxdechcwdqwdlevubnuzimsqjb` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_dqvgdgxpvxjrjwhtxrphgvqwoaalqzogguej` FOREIGN KEY (`tabId`) REFERENCES `fieldlayouttabs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_nwdtkllhjfnzremqvtfemuuraptsxarshvba` FOREIGN KEY (`layoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fieldlayoutfields`
--

LOCK TABLES `fieldlayoutfields` WRITE;
/*!40000 ALTER TABLE `fieldlayoutfields` DISABLE KEYS */;
INSERT INTO `fieldlayoutfields` VALUES (22,5,10,7,0,0,'2023-11-04 14:04:28','2023-11-04 14:04:28','ec72d4ad-6fb3-4948-946d-5625d616e3e8'),(43,1,18,8,0,1,'2023-11-04 15:33:45','2023-11-04 15:33:45','a90e7207-7c52-4b4a-a85c-61dfe5d49d10'),(48,3,20,8,0,1,'2023-11-04 15:36:05','2023-11-04 15:36:05','313134ff-7fd4-44d0-947f-2bd4efbc4dfe'),(49,3,20,11,0,2,'2023-11-04 15:36:05','2023-11-04 15:36:05','7695606e-955b-49ab-8ca1-6226b5fdf4f9'),(50,3,20,10,0,3,'2023-11-04 15:36:05','2023-11-04 15:36:05','7ab006df-8ce0-4e5e-9fd4-183a85a5a1ff'),(51,3,20,4,0,4,'2023-11-04 15:36:05','2023-11-04 15:36:05','59055b51-114b-44ff-bcc1-56370e5d633c'),(52,3,20,3,0,5,'2023-11-04 15:36:05','2023-11-04 15:36:05','b284d634-446a-4a50-bd76-1dec293f14a6'),(53,2,21,1,0,1,'2023-11-11 09:05:31','2023-11-11 09:05:31','461ac455-c34d-4b51-9f86-f30b3b4d98f8'),(54,2,21,5,0,2,'2023-11-11 09:05:31','2023-11-11 09:05:31','120bd987-9abb-47a9-9933-4abe93739791'),(55,2,21,12,0,3,'2023-11-11 09:05:31','2023-11-11 09:05:31','bdeae567-1e99-4405-a4e4-a4b41115f8bf'),(56,2,21,13,0,4,'2023-11-11 09:05:31','2023-11-11 09:05:31','95111cd3-b321-4946-b356-b714811d9130');
/*!40000 ALTER TABLE `fieldlayoutfields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fieldlayouts`
--

DROP TABLE IF EXISTS `fieldlayouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fieldlayouts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_vqttwmtahmomcysgewibavvpwyjnooatygeh` (`dateDeleted`),
  KEY `idx_abpjikhzatrrkhqvgapsqugxxdwxtijcmyqz` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fieldlayouts`
--

LOCK TABLES `fieldlayouts` WRITE;
/*!40000 ALTER TABLE `fieldlayouts` DISABLE KEYS */;
INSERT INTO `fieldlayouts` VALUES (1,'craft\\elements\\Entry','2023-11-04 14:04:28','2023-11-04 14:04:28',NULL,'aa2f56ec-be2f-4366-b912-a48ddfd78b14'),(2,'craft\\elements\\Entry','2023-11-04 14:04:28','2023-11-04 14:04:28',NULL,'1a5270c8-f8f6-4f71-959e-d7a32533b197'),(3,'craft\\elements\\Entry','2023-11-04 14:04:28','2023-11-04 14:04:28',NULL,'4148225d-9e14-42d3-b0d7-bc884c5588ad'),(4,'craft\\elements\\Address','2023-11-04 14:04:28','2023-11-04 14:04:28',NULL,'3b96b45d-f21f-43cb-a9b5-35a61552e038'),(5,'craft\\elements\\User','2023-11-04 14:04:28','2023-11-04 14:04:28',NULL,'2357198e-505a-4226-9d93-dc306b8194dd'),(6,'craft\\elements\\Entry','2023-11-04 15:32:15','2023-11-04 15:32:15',NULL,'f34af012-d7be-42c8-99fe-b20987d7b77d');
/*!40000 ALTER TABLE `fieldlayouts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fieldlayouttabs`
--

DROP TABLE IF EXISTS `fieldlayouttabs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fieldlayouttabs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `layoutId` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `settings` text,
  `elements` text,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_tijqfcmvijyfkbudmjpsyikvivzazoqlnmgc` (`sortOrder`),
  KEY `idx_nepcevnzzbdjqbzskrtoagdijesscpvycaeo` (`layoutId`),
  CONSTRAINT `fk_fgbzcpfrkpfsiymclkfmlwltghzyobbqqwub` FOREIGN KEY (`layoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fieldlayouttabs`
--

LOCK TABLES `fieldlayouttabs` WRITE;
/*!40000 ALTER TABLE `fieldlayouttabs` DISABLE KEYS */;
INSERT INTO `fieldlayouttabs` VALUES (8,4,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\addresses\\\\LabelField\",\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"62cd21f2-258b-4488-be3d-45679e9076ee\",\"userCondition\":null,\"elementCondition\":null},{\"type\":\"craft\\\\fieldlayoutelements\\\\addresses\\\\CountryCodeField\",\"attribute\":\"countryCode\",\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"22410437-9f4a-4a2d-a22b-0129789e3978\",\"userCondition\":null,\"elementCondition\":null},{\"type\":\"craft\\\\fieldlayoutelements\\\\addresses\\\\AddressField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"uid\":\"32797a07-d096-4b13-84be-efe291a1907f\",\"userCondition\":null,\"elementCondition\":null}]',1,'2023-11-04 14:04:28','2023-11-04 14:04:28','b5b529ef-30f3-4a5f-9b20-404a54f7d152'),(10,5,'Details','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"a033941f-3eeb-4aff-aacc-d944b30c1d14\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"349ff4ce-c3d6-401e-a73d-26ef36146dba\"}]',1,'2023-11-04 14:04:28','2023-11-04 14:04:28','16c37192-5bde-450b-8f80-00bb7e266800'),(17,6,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\",\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"3212ee3b-9702-43bb-b2c9-20825de5c4cd\",\"userCondition\":null,\"elementCondition\":null}]',1,'2023-11-04 15:32:15','2023-11-04 15:32:15','51f08e6f-f44f-4293-bc27-451451544caa'),(18,1,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\",\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"76d94e3f-53f5-40d2-a603-50d6bb44b943\",\"userCondition\":null,\"elementCondition\":null},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"3a89feaa-1397-41b9-8a03-9e6c3492c331\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"6af92e13-3817-4619-a65c-3522d4d1fc67\"}]',1,'2023-11-04 15:33:45','2023-11-04 15:33:45','17356f99-2ef6-4a3f-88ab-b1cb7d345a80'),(20,3,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\",\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"fb387136-40af-43f1-a568-fd1c55739db4\",\"userCondition\":null,\"elementCondition\":null},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"8829e190-ee8b-4b81-8cfe-7af420e60bf1\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"6af92e13-3817-4619-a65c-3522d4d1fc67\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"ac2eb4f8-a226-4d03-8cdf-f6b491b09170\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"d55f6463-5f76-4782-9af7-78a88483b0f0\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"1d295689-0fd3-4fcd-8d1c-590f349ae258\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"cc8877ab-7d30-4e23-b01f-3a8318288fc0\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"4f8ad358-8b71-4b44-ba41-7dab38f6deb3\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"f83d583c-7b6a-4dc7-8d00-7bdd51363137\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"e12f3be3-1f13-4b19-8f67-2b7a49724be9\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"f9060c98-f56d-4cca-b4d5-de78d810e775\"}]',1,'2023-11-04 15:36:05','2023-11-04 15:36:05','85c9d681-0307-450c-b273-15a2fc771276'),(21,2,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\",\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"64eb4453-9b20-475c-949e-2d7a5e5562a7\",\"userCondition\":null,\"elementCondition\":null},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"64617af7-43bf-4c01-82fc-f285df54ecbd\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"73ccaa0c-844d-46d0-8b58-e33c1baaa8f2\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"8ac14d5b-89ce-446a-bd21-1ab2bd3a9aeb\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"312b4f06-f575-487d-8777-e646ddb19ba6\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"9613bd6c-ed15-456c-a016-2c73a74aa965\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"0084065a-21dc-4833-9064-d97f4e1c9bca\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"2a6466e8-6d24-49b9-b418-e7cd3c5ad96a\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"cc7c385a-fa47-48b0-8edb-006e60e4b8f1\"}]',1,'2023-11-11 09:05:31','2023-11-11 09:05:31','2daef3ad-2dcf-4b09-a6af-4d8904001084');
/*!40000 ALTER TABLE `fieldlayouttabs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fields`
--

DROP TABLE IF EXISTS `fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fields` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(64) NOT NULL,
  `context` varchar(255) NOT NULL DEFAULT 'global',
  `columnSuffix` char(8) DEFAULT NULL,
  `instructions` text,
  `searchable` tinyint(1) NOT NULL DEFAULT '1',
  `translationMethod` varchar(255) NOT NULL DEFAULT 'none',
  `translationKeyFormat` text,
  `type` varchar(255) NOT NULL,
  `settings` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_aszwmqcyooknupkapqldkaidaulsgeqypgme` (`handle`,`context`),
  KEY `idx_rhnqkosonmtyqsimizeusnnirqxjmqesjeyr` (`groupId`),
  KEY `idx_bahhonhvrxxrhbjzvjrzgwgwerxlpgbkaqwv` (`context`),
  CONSTRAINT `fk_faofxrddxmlrhqropbciljdmkuiqpyiilaey` FOREIGN KEY (`groupId`) REFERENCES `fieldgroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fields`
--

LOCK TABLES `fields` WRITE;
/*!40000 ALTER TABLE `fields` DISABLE KEYS */;
INSERT INTO `fields` VALUES (1,3,'Venue Currency Type','venueCurrencyType','global','eowtagfq',NULL,0,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":false,\"columnType\":null,\"initialRows\":4,\"multiline\":false,\"placeholder\":null,\"uiMode\":\"normal\"}','2023-11-04 14:04:27','2023-11-04 14:04:27','73ccaa0c-844d-46d0-8b58-e33c1baaa8f2'),(3,4,'Visit Start','visitStart','global','zzxlubly',NULL,0,'none',NULL,'craft\\fields\\Date','{\"max\":null,\"min\":null,\"minuteIncrement\":30,\"showDate\":true,\"showTime\":true,\"showTimeZone\":false}','2023-11-04 14:04:28','2023-11-04 14:04:28','f9060c98-f56d-4cca-b4d5-de78d810e775'),(4,4,'Visit Language','visitLanguage','global','akixlfui',NULL,0,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":false,\"columnType\":null,\"initialRows\":4,\"multiline\":false,\"placeholder\":null,\"uiMode\":\"normal\"}','2023-11-04 14:04:28','2023-11-04 14:04:28','f83d583c-7b6a-4dc7-8d00-7bdd51363137'),(5,3,'Venue Ticket Price','venueTicketPrice','global','odumgdut',NULL,0,'none',NULL,'craft\\fields\\Number','{\"decimals\":2,\"defaultValue\":null,\"max\":null,\"min\":0,\"prefix\":null,\"previewCurrency\":null,\"previewFormat\":\"decimal\",\"size\":null,\"suffix\":null}','2023-11-04 14:04:28','2023-11-04 14:04:28','312b4f06-f575-487d-8777-e646ddb19ba6'),(7,2,'Company Name','companyName','global','tcownruz',NULL,0,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":false,\"columnType\":null,\"initialRows\":4,\"multiline\":false,\"placeholder\":null,\"uiMode\":\"normal\"}','2023-11-04 14:04:28','2023-11-04 14:04:28','349ff4ce-c3d6-401e-a73d-26ef36146dba'),(8,4,'Venue','venue','global','knhntkbg',NULL,0,'site',NULL,'craft\\fields\\Entries','{\"allowSelfRelations\":false,\"branchLimit\":null,\"localizeRelations\":false,\"maintainHierarchy\":false,\"maxRelations\":1,\"minRelations\":null,\"selectionCondition\":{\"elementType\":\"craft\\\\elements\\\\Entry\",\"fieldContext\":\"global\",\"class\":\"craft\\\\elements\\\\conditions\\\\entries\\\\EntryCondition\"},\"selectionLabel\":null,\"showSiteMenu\":true,\"sources\":[\"section:fa1a9449-1cdb-4185-8017-6d6baea8371b\"],\"targetSiteId\":null,\"validateRelatedElements\":false,\"viewMode\":null}','2023-11-04 14:04:28','2023-11-04 14:04:28','6af92e13-3817-4619-a65c-3522d4d1fc67'),(9,2,'Company Logo','companyLogo','global',NULL,NULL,0,'site',NULL,'craft\\fields\\Assets','{\"allowSelfRelations\":false,\"allowSubfolders\":false,\"allowUploads\":true,\"allowedKinds\":null,\"branchLimit\":null,\"defaultUploadLocationSource\":null,\"defaultUploadLocationSubpath\":null,\"localizeRelations\":false,\"maintainHierarchy\":false,\"maxRelations\":null,\"minRelations\":null,\"previewMode\":\"full\",\"restrictFiles\":false,\"restrictLocation\":false,\"restrictedDefaultUploadSubpath\":null,\"restrictedLocationSource\":null,\"restrictedLocationSubpath\":null,\"selectionCondition\":{\"elementType\":\"craft\\\\elements\\\\Asset\",\"fieldContext\":\"global\",\"class\":\"craft\\\\elements\\\\conditions\\\\assets\\\\AssetCondition\"},\"selectionLabel\":null,\"showSiteMenu\":false,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"sources\":\"*\",\"targetSiteId\":null,\"validateRelatedElements\":false,\"viewMode\":\"list\"}','2023-11-04 14:04:28','2023-11-04 14:04:28','b748cdca-ffaa-490f-98b0-5fa1c1e70095'),(10,4,'Movie Name','movie','global','zmwphfkw',NULL,0,'site',NULL,'craft\\fields\\Entries','{\"allowSelfRelations\":false,\"branchLimit\":null,\"localizeRelations\":false,\"maintainHierarchy\":false,\"maxRelations\":1,\"minRelations\":1,\"selectionCondition\":{\"elementType\":\"craft\\\\elements\\\\Entry\",\"fieldContext\":\"global\",\"class\":\"craft\\\\elements\\\\conditions\\\\entries\\\\EntryCondition\"},\"selectionLabel\":null,\"showSiteMenu\":true,\"sources\":[\"section:b3e8c798-1f09-4ca2-ac30-695d0273d094\"],\"targetSiteId\":null,\"validateRelatedElements\":false,\"viewMode\":null}','2023-11-04 14:04:28','2023-11-07 22:39:43','cc8877ab-7d30-4e23-b01f-3a8318288fc0'),(11,4,'Headset','headset','global',NULL,NULL,0,'site',NULL,'craft\\fields\\Entries','{\"allowSelfRelations\":false,\"branchLimit\":null,\"localizeRelations\":false,\"maintainHierarchy\":false,\"maxRelations\":1,\"minRelations\":1,\"selectionCondition\":{\"elementType\":\"craft\\\\elements\\\\Entry\",\"fieldContext\":\"global\",\"class\":\"craft\\\\elements\\\\conditions\\\\entries\\\\EntryCondition\"},\"selectionLabel\":null,\"showSiteMenu\":false,\"sources\":[\"section:38875b9f-df2c-41e6-a1a2-e9d4ed370735\"],\"targetSiteId\":null,\"validateRelatedElements\":false,\"viewMode\":null}','2023-11-04 15:35:46','2023-11-04 15:35:46','d55f6463-5f76-4782-9af7-78a88483b0f0'),(12,3,'Venue Opening Time','venueOpeningTime','global','xsmoaddn',NULL,0,'none',NULL,'craft\\fields\\Time','{\"max\":null,\"min\":null,\"minuteIncrement\":30}','2023-11-11 09:04:26','2023-11-11 09:04:26','0084065a-21dc-4833-9064-d97f4e1c9bca'),(13,3,'Venue Closing Time','venueClosingTime','global','hjwvgxqr',NULL,0,'none',NULL,'craft\\fields\\Time','{\"max\":null,\"min\":null,\"minuteIncrement\":30}','2023-11-11 09:04:40','2023-11-11 09:04:40','cc7c385a-fa47-48b0-8edb-006e60e4b8f1');
/*!40000 ALTER TABLE `fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `globalsets`
--

DROP TABLE IF EXISTS `globalsets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `globalsets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_rqiurtkelvxpdwwpcynhwrcbckitodesqprr` (`name`),
  KEY `idx_srxiczsxtglkqdoxjlykjydnpkfraeymacuk` (`handle`),
  KEY `idx_qmusjkqemccsdtuvdyvvnbphmzrsqxyrqyfd` (`fieldLayoutId`),
  KEY `idx_elkqftiuawhdbkzhnuncvqwnqrjnfjqitrju` (`sortOrder`),
  CONSTRAINT `fk_llckqristexdabkpxnnmxgqvovjgbsapsuxt` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ntihgulkxbngnztpqckfxdbhfjkeivjimsco` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `globalsets`
--

LOCK TABLES `globalsets` WRITE;
/*!40000 ALTER TABLE `globalsets` DISABLE KEYS */;
/*!40000 ALTER TABLE `globalsets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gqlschemas`
--

DROP TABLE IF EXISTS `gqlschemas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gqlschemas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `scope` text,
  `isPublic` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gqlschemas`
--

LOCK TABLES `gqlschemas` WRITE;
/*!40000 ALTER TABLE `gqlschemas` DISABLE KEYS */;
INSERT INTO `gqlschemas` VALUES (1,'Stats Schema','[\"sites.f957802c-8f19-44d3-a30a-668d452862ac:read\",\"sections.cb843ec5-3aaa-44ea-94cf-f99f4023642f:read\",\"entrytypes.df793da0-9723-422b-a370-2e9c303381d0:read\",\"usergroups.32c28836-80b3-4da9-a427-6d42b223613b:read\",\"sections.cb843ec5-3aaa-44ea-94cf-f99f4023642f:edit\",\"entrytypes.df793da0-9723-422b-a370-2e9c303381d0:edit\",\"entrytypes.df793da0-9723-422b-a370-2e9c303381d0:create\",\"entrytypes.df793da0-9723-422b-a370-2e9c303381d0:save\",\"entrytypes.df793da0-9723-422b-a370-2e9c303381d0:delete\"]',0,'2023-11-04 14:04:28','2023-11-12 16:51:00','4e940878-c1ee-4493-ba07-9714a5292f0b'),(2,'Public Schema','[\"sites.f957802c-8f19-44d3-a30a-668d452862ac:read\",\"sections.cb843ec5-3aaa-44ea-94cf-f99f4023642f:read\",\"entrytypes.df793da0-9723-422b-a370-2e9c303381d0:read\",\"usergroups.everyone:read\",\"sections.cb843ec5-3aaa-44ea-94cf-f99f4023642f:edit\",\"entrytypes.df793da0-9723-422b-a370-2e9c303381d0:edit\",\"entrytypes.df793da0-9723-422b-a370-2e9c303381d0:create\",\"entrytypes.df793da0-9723-422b-a370-2e9c303381d0:save\"]',1,'2023-11-04 14:04:28','2023-11-04 14:04:28','cca433bd-c86d-402b-9734-50cc40b8760d');
/*!40000 ALTER TABLE `gqlschemas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gqltokens`
--

DROP TABLE IF EXISTS `gqltokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gqltokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `accessToken` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `expiryDate` datetime DEFAULT NULL,
  `lastUsed` datetime DEFAULT NULL,
  `schemaId` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_slwersspgohntbnflkkbjqpdnyhlbkdehntv` (`accessToken`),
  UNIQUE KEY `idx_bfkzxzgvpsyvvbkrmmxweahnctomkuzhdbcl` (`name`),
  KEY `fk_uzhqdbomcjqmzcaddzqlhvkjubrijgqogvrk` (`schemaId`),
  CONSTRAINT `fk_uzhqdbomcjqmzcaddzqlhvkjubrijgqogvrk` FOREIGN KEY (`schemaId`) REFERENCES `gqlschemas` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gqltokens`
--

LOCK TABLES `gqltokens` WRITE;
/*!40000 ALTER TABLE `gqltokens` DISABLE KEYS */;
INSERT INTO `gqltokens` VALUES (1,'Declans Token','bUX_-31uQYr0i6AAVv1vFE6ycN_Xi4uI',1,NULL,'2023-11-12 16:53:24',1,'2023-11-10 09:32:44','2023-11-12 16:53:24','57bf52d1-b153-43ef-841a-22924691c1c6');
/*!40000 ALTER TABLE `gqltokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `imagetransformindex`
--

DROP TABLE IF EXISTS `imagetransformindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `imagetransformindex` (
  `id` int NOT NULL AUTO_INCREMENT,
  `assetId` int NOT NULL,
  `transformer` varchar(255) DEFAULT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `transformString` varchar(255) NOT NULL,
  `fileExists` tinyint(1) NOT NULL DEFAULT '0',
  `inProgress` tinyint(1) NOT NULL DEFAULT '0',
  `error` tinyint(1) NOT NULL DEFAULT '0',
  `dateIndexed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_qbvrogfysorxhtglvozoaaxsvpibkfzzxmqd` (`assetId`,`transformString`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `imagetransformindex`
--

LOCK TABLES `imagetransformindex` WRITE;
/*!40000 ALTER TABLE `imagetransformindex` DISABLE KEYS */;
/*!40000 ALTER TABLE `imagetransformindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `imagetransforms`
--

DROP TABLE IF EXISTS `imagetransforms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `imagetransforms` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `mode` enum('stretch','fit','crop','letterbox') NOT NULL DEFAULT 'crop',
  `position` enum('top-left','top-center','top-right','center-left','center-center','center-right','bottom-left','bottom-center','bottom-right') NOT NULL DEFAULT 'center-center',
  `width` int unsigned DEFAULT NULL,
  `height` int unsigned DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `quality` int DEFAULT NULL,
  `interlace` enum('none','line','plane','partition') NOT NULL DEFAULT 'none',
  `fill` varchar(11) DEFAULT NULL,
  `upscale` tinyint(1) NOT NULL DEFAULT '1',
  `parameterChangeTime` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_xphvteuxsdbyammptrpmlewzanrahgjdwuvd` (`name`),
  KEY `idx_rurhuxuyguwuoiguekttfxzbosnkwtfkfgrh` (`handle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `imagetransforms`
--

LOCK TABLES `imagetransforms` WRITE;
/*!40000 ALTER TABLE `imagetransforms` DISABLE KEYS */;
/*!40000 ALTER TABLE `imagetransforms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `info`
--

DROP TABLE IF EXISTS `info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `info` (
  `id` int NOT NULL AUTO_INCREMENT,
  `version` varchar(50) NOT NULL,
  `schemaVersion` varchar(15) NOT NULL,
  `maintenance` tinyint(1) NOT NULL DEFAULT '0',
  `configVersion` char(12) NOT NULL DEFAULT '000000000000',
  `fieldVersion` char(12) NOT NULL DEFAULT '000000000000',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `info`
--

LOCK TABLES `info` WRITE;
/*!40000 ALTER TABLE `info` DISABLE KEYS */;
INSERT INTO `info` VALUES (1,'4.5.6.1','4.5.3.0',0,'nwlellcdzgvj','3@roslqqjlcp','2023-11-04 14:04:27','2023-11-12 16:51:00','3dfc3fb5-b256-4258-9304-e2d648bd8104');
/*!40000 ALTER TABLE `info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `matrixblocks`
--

DROP TABLE IF EXISTS `matrixblocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `matrixblocks` (
  `id` int NOT NULL,
  `primaryOwnerId` int NOT NULL,
  `fieldId` int NOT NULL,
  `typeId` int NOT NULL,
  `deletedWithOwner` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_zsptnhwaowhzdmewgcwumhahokfqrhpbrbyp` (`primaryOwnerId`),
  KEY `idx_pqfxbqncfbjxxkfyjrbzifjgmvtzqyzqcugs` (`fieldId`),
  KEY `idx_rmljtxgkgsjbmkhtuwcndajfcupsmuzcsrsr` (`typeId`),
  CONSTRAINT `fk_buhimyehxrznafjqctuikaafyjijidhtfema` FOREIGN KEY (`primaryOwnerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_eyvwrerwqyjslximnhcydbsvdfgrqtcjisej` FOREIGN KEY (`typeId`) REFERENCES `matrixblocktypes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_uwltupfzmxbrxwmumxxfarhuunnripyuuled` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_yqwnogrkkvxzexczjdbdyafsjlxgpmfduxrr` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `matrixblocks`
--

LOCK TABLES `matrixblocks` WRITE;
/*!40000 ALTER TABLE `matrixblocks` DISABLE KEYS */;
/*!40000 ALTER TABLE `matrixblocks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `matrixblocks_owners`
--

DROP TABLE IF EXISTS `matrixblocks_owners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `matrixblocks_owners` (
  `blockId` int NOT NULL,
  `ownerId` int NOT NULL,
  `sortOrder` smallint unsigned NOT NULL,
  PRIMARY KEY (`blockId`,`ownerId`),
  KEY `fk_hswpoladeafuqooailsbzswbwbigrfbzbmwi` (`ownerId`),
  CONSTRAINT `fk_hswpoladeafuqooailsbzswbwbigrfbzbmwi` FOREIGN KEY (`ownerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ujgzlhknamxglkonuygjbquyeejxscjmkega` FOREIGN KEY (`blockId`) REFERENCES `matrixblocks` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `matrixblocks_owners`
--

LOCK TABLES `matrixblocks_owners` WRITE;
/*!40000 ALTER TABLE `matrixblocks_owners` DISABLE KEYS */;
/*!40000 ALTER TABLE `matrixblocks_owners` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `matrixblocktypes`
--

DROP TABLE IF EXISTS `matrixblocktypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `matrixblocktypes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldId` int NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_rlmiqpwgxvmagxuasbujupcvbqvisvlfwgby` (`name`,`fieldId`),
  KEY `idx_lsloxmsrhwbzhnxrosvyyjegyrnhmcnhmvgd` (`handle`,`fieldId`),
  KEY `idx_wdllhghgbqrdrutpuopsbgjhjvigqizkqlsd` (`fieldId`),
  KEY `idx_blwsprjnnsvbstiaecnmjwffwamkgiqecncy` (`fieldLayoutId`),
  CONSTRAINT `fk_bshlfnnyrxqvqmwixtogonruugkvwjgrrbeb` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_oxazhamujtlbkeuifcvpokhqzotxfsbxrpba` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `matrixblocktypes`
--

LOCK TABLES `matrixblocktypes` WRITE;
/*!40000 ALTER TABLE `matrixblocktypes` DISABLE KEYS */;
/*!40000 ALTER TABLE `matrixblocktypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `track` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applyTime` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_bvebqjouxttenpxdlwjsfjvtzcigqymdzgqa` (`track`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'craft','Install','2023-11-04 14:04:31','2023-11-04 14:04:31','2023-11-04 14:04:31','5be73f44-c3a9-4b5d-99cb-6f080c25cc0a'),(2,'craft','m210121_145800_asset_indexing_changes','2023-11-04 14:04:31','2023-11-04 14:04:31','2023-11-04 14:04:31','c7085746-190f-45a4-a4a4-dda715a80025'),(3,'craft','m210624_222934_drop_deprecated_tables','2023-11-04 14:04:31','2023-11-04 14:04:31','2023-11-04 14:04:31','8071139b-6532-4129-a401-552626c0a092'),(4,'craft','m210724_180756_rename_source_cols','2023-11-04 14:04:31','2023-11-04 14:04:31','2023-11-04 14:04:31','194d674b-c632-4fbc-b2ed-8f26e9cda3b1'),(5,'craft','m210809_124211_remove_superfluous_uids','2023-11-04 14:04:31','2023-11-04 14:04:31','2023-11-04 14:04:31','2d09b086-6333-4796-99b4-f108f1cae53e'),(6,'craft','m210817_014201_universal_users','2023-11-04 14:04:31','2023-11-04 14:04:31','2023-11-04 14:04:31','a56fca60-e4ff-4d8e-aa13-525b321654f2'),(7,'craft','m210904_132612_store_element_source_settings_in_project_config','2023-11-04 14:04:31','2023-11-04 14:04:31','2023-11-04 14:04:31','fee28c5d-1e20-470a-a095-3884c53a9bba'),(8,'craft','m211115_135500_image_transformers','2023-11-04 14:04:31','2023-11-04 14:04:31','2023-11-04 14:04:31','74400615-8ce4-45b1-9dd7-ab2fb8f28f8b'),(9,'craft','m211201_131000_filesystems','2023-11-04 14:04:31','2023-11-04 14:04:31','2023-11-04 14:04:31','12577f6a-bfc8-4af9-a4a3-f934a836cbdf'),(10,'craft','m220103_043103_tab_conditions','2023-11-04 14:04:31','2023-11-04 14:04:31','2023-11-04 14:04:31','796b6e61-5781-44ea-a759-e8e26792009d'),(11,'craft','m220104_003433_asset_alt_text','2023-11-04 14:04:31','2023-11-04 14:04:31','2023-11-04 14:04:31','97e97ad0-0b03-4ad5-9a83-00175c14cc7a'),(12,'craft','m220123_213619_update_permissions','2023-11-04 14:04:31','2023-11-04 14:04:31','2023-11-04 14:04:31','3358da31-d36c-4037-a68f-221c1089344b'),(13,'craft','m220126_003432_addresses','2023-11-04 14:04:31','2023-11-04 14:04:31','2023-11-04 14:04:31','dd4d17ab-42de-46d9-9c15-9b0cee8b3064'),(14,'craft','m220209_095604_add_indexes','2023-11-04 14:04:31','2023-11-04 14:04:31','2023-11-04 14:04:31','41a66202-0220-4d93-a95c-9edd38976782'),(15,'craft','m220213_015220_matrixblocks_owners_table','2023-11-04 14:04:31','2023-11-04 14:04:31','2023-11-04 14:04:31','8d53fed7-188a-422a-b23f-143419113ec3'),(16,'craft','m220214_000000_truncate_sessions','2023-11-04 14:04:31','2023-11-04 14:04:31','2023-11-04 14:04:31','0b0279cb-1f73-4b38-81e5-78777b3f6049'),(17,'craft','m220222_122159_full_names','2023-11-04 14:04:31','2023-11-04 14:04:31','2023-11-04 14:04:31','79a4150c-de6b-453e-b2ce-8a56a36062f1'),(18,'craft','m220223_180559_nullable_address_owner','2023-11-04 14:04:31','2023-11-04 14:04:31','2023-11-04 14:04:31','fa4897bb-8932-43ae-8bb7-5994e7cf84d9'),(19,'craft','m220225_165000_transform_filesystems','2023-11-04 14:04:31','2023-11-04 14:04:31','2023-11-04 14:04:31','64eb2921-a307-4086-af19-b626c9b0fdd2'),(20,'craft','m220309_152006_rename_field_layout_elements','2023-11-04 14:04:31','2023-11-04 14:04:31','2023-11-04 14:04:31','e3496367-9fbe-4b67-9a6b-2d384a657ca4'),(21,'craft','m220314_211928_field_layout_element_uids','2023-11-04 14:04:31','2023-11-04 14:04:31','2023-11-04 14:04:31','e4a42a93-9422-42d4-b32d-53d3abe53ba0'),(22,'craft','m220316_123800_transform_fs_subpath','2023-11-04 14:04:31','2023-11-04 14:04:31','2023-11-04 14:04:31','8f2bf267-992b-45d4-9488-e960df060517'),(23,'craft','m220317_174250_release_all_jobs','2023-11-04 14:04:31','2023-11-04 14:04:31','2023-11-04 14:04:31','3711da2a-f5fc-4ce8-922c-c9dbcc7503d0'),(24,'craft','m220330_150000_add_site_gql_schema_components','2023-11-04 14:04:31','2023-11-04 14:04:31','2023-11-04 14:04:31','fa0db36e-141f-4c9b-9d94-415eb6835579'),(25,'craft','m220413_024536_site_enabled_string','2023-11-04 14:04:31','2023-11-04 14:04:31','2023-11-04 14:04:31','052eaa68-1056-49e3-9910-718b14b2d36e'),(26,'craft','m221027_160703_add_image_transform_fill','2023-11-04 14:04:31','2023-11-04 14:04:31','2023-11-04 14:04:31','3df7f305-0214-4dee-bb29-cc8fd09ef55e'),(27,'craft','m221028_130548_add_canonical_id_index','2023-11-04 14:04:31','2023-11-04 14:04:31','2023-11-04 14:04:31','9a0b3d00-ea74-4e90-b699-764ecca0777c'),(28,'craft','m221118_003031_drop_element_fks','2023-11-04 14:04:31','2023-11-04 14:04:31','2023-11-04 14:04:31','58688493-15ea-4885-97e9-586681d0e0f8'),(29,'craft','m230131_120713_asset_indexing_session_new_options','2023-11-04 14:04:31','2023-11-04 14:04:31','2023-11-04 14:04:31','0bff57e7-1dcb-4058-909d-21ec35da875a'),(30,'craft','m230226_013114_drop_plugin_license_columns','2023-11-04 14:04:31','2023-11-04 14:04:31','2023-11-04 14:04:31','020d1eb9-3181-4b95-a0c7-174f0cf34d55'),(31,'craft','m230531_123004_add_entry_type_show_status_field','2023-11-04 14:04:31','2023-11-04 14:04:31','2023-11-04 14:04:31','5caa06e6-2024-4675-b3b7-5caafad45754'),(32,'craft','m230607_102049_add_entrytype_slug_translation_columns','2023-11-04 14:04:31','2023-11-04 14:04:31','2023-11-04 14:04:31','9110b14f-fbea-4d78-afaf-581663d561f0'),(33,'craft','m230710_162700_element_activity','2023-11-04 14:04:31','2023-11-04 14:04:31','2023-11-04 14:04:31','54e93b9e-380e-4650-a9cd-d6402e8fa6ff'),(34,'craft','m230820_162023_fix_cache_id_type','2023-11-04 14:04:31','2023-11-04 14:04:31','2023-11-04 14:04:31','10297f3e-8b8f-459c-b3f1-e2cdd7a92ebe'),(35,'craft','m230826_094050_fix_session_id_type','2023-11-04 14:04:31','2023-11-04 14:04:31','2023-11-04 14:04:31','3f0afd3a-2a28-4c1f-8bdd-58b22a2b8f01');
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `plugins`
--

DROP TABLE IF EXISTS `plugins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `plugins` (
  `id` int NOT NULL AUTO_INCREMENT,
  `handle` varchar(255) NOT NULL,
  `version` varchar(255) NOT NULL,
  `schemaVersion` varchar(255) NOT NULL,
  `installDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ofcribfimejjowiioarfikyrmtntxdhpolxn` (`handle`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plugins`
--

LOCK TABLES `plugins` WRITE;
/*!40000 ALTER TABLE `plugins` DISABLE KEYS */;
INSERT INTO `plugins` VALUES (1,'_venue','dev-main','1.0.0','2023-11-04 14:04:27','2023-11-04 14:04:27','2023-11-04 14:04:27','8ac148b3-d6e7-4953-9998-3915fba332bd'),(2,'_em-stats','dev-main','1.0.0','2023-11-07 18:14:43','2023-11-07 18:14:43','2023-11-07 18:14:43','c0aadade-b347-4302-bb18-d51a942b7f3a');
/*!40000 ALTER TABLE `plugins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projectconfig`
--

DROP TABLE IF EXISTS `projectconfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `projectconfig` (
  `path` varchar(255) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`path`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projectconfig`
--

LOCK TABLES `projectconfig` WRITE;
/*!40000 ALTER TABLE `projectconfig` DISABLE KEYS */;
INSERT INTO `projectconfig` VALUES ('addresses.fieldLayouts.3b96b45d-f21f-43cb-a9b5-35a61552e038.tabs.0.elementCondition','null'),('addresses.fieldLayouts.3b96b45d-f21f-43cb-a9b5-35a61552e038.tabs.0.elements.0.autocapitalize','true'),('addresses.fieldLayouts.3b96b45d-f21f-43cb-a9b5-35a61552e038.tabs.0.elements.0.autocomplete','false'),('addresses.fieldLayouts.3b96b45d-f21f-43cb-a9b5-35a61552e038.tabs.0.elements.0.autocorrect','true'),('addresses.fieldLayouts.3b96b45d-f21f-43cb-a9b5-35a61552e038.tabs.0.elements.0.class','null'),('addresses.fieldLayouts.3b96b45d-f21f-43cb-a9b5-35a61552e038.tabs.0.elements.0.disabled','false'),('addresses.fieldLayouts.3b96b45d-f21f-43cb-a9b5-35a61552e038.tabs.0.elements.0.elementCondition','null'),('addresses.fieldLayouts.3b96b45d-f21f-43cb-a9b5-35a61552e038.tabs.0.elements.0.id','null'),('addresses.fieldLayouts.3b96b45d-f21f-43cb-a9b5-35a61552e038.tabs.0.elements.0.instructions','null'),('addresses.fieldLayouts.3b96b45d-f21f-43cb-a9b5-35a61552e038.tabs.0.elements.0.label','null'),('addresses.fieldLayouts.3b96b45d-f21f-43cb-a9b5-35a61552e038.tabs.0.elements.0.max','null'),('addresses.fieldLayouts.3b96b45d-f21f-43cb-a9b5-35a61552e038.tabs.0.elements.0.min','null'),('addresses.fieldLayouts.3b96b45d-f21f-43cb-a9b5-35a61552e038.tabs.0.elements.0.name','null'),('addresses.fieldLayouts.3b96b45d-f21f-43cb-a9b5-35a61552e038.tabs.0.elements.0.orientation','null'),('addresses.fieldLayouts.3b96b45d-f21f-43cb-a9b5-35a61552e038.tabs.0.elements.0.placeholder','null'),('addresses.fieldLayouts.3b96b45d-f21f-43cb-a9b5-35a61552e038.tabs.0.elements.0.readonly','false'),('addresses.fieldLayouts.3b96b45d-f21f-43cb-a9b5-35a61552e038.tabs.0.elements.0.requirable','false'),('addresses.fieldLayouts.3b96b45d-f21f-43cb-a9b5-35a61552e038.tabs.0.elements.0.size','null'),('addresses.fieldLayouts.3b96b45d-f21f-43cb-a9b5-35a61552e038.tabs.0.elements.0.step','null'),('addresses.fieldLayouts.3b96b45d-f21f-43cb-a9b5-35a61552e038.tabs.0.elements.0.tip','null'),('addresses.fieldLayouts.3b96b45d-f21f-43cb-a9b5-35a61552e038.tabs.0.elements.0.title','null'),('addresses.fieldLayouts.3b96b45d-f21f-43cb-a9b5-35a61552e038.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\addresses\\\\LabelField\"'),('addresses.fieldLayouts.3b96b45d-f21f-43cb-a9b5-35a61552e038.tabs.0.elements.0.uid','\"62cd21f2-258b-4488-be3d-45679e9076ee\"'),('addresses.fieldLayouts.3b96b45d-f21f-43cb-a9b5-35a61552e038.tabs.0.elements.0.userCondition','null'),('addresses.fieldLayouts.3b96b45d-f21f-43cb-a9b5-35a61552e038.tabs.0.elements.0.warning','null'),('addresses.fieldLayouts.3b96b45d-f21f-43cb-a9b5-35a61552e038.tabs.0.elements.0.width','100'),('addresses.fieldLayouts.3b96b45d-f21f-43cb-a9b5-35a61552e038.tabs.0.elements.1.attribute','\"countryCode\"'),('addresses.fieldLayouts.3b96b45d-f21f-43cb-a9b5-35a61552e038.tabs.0.elements.1.elementCondition','null'),('addresses.fieldLayouts.3b96b45d-f21f-43cb-a9b5-35a61552e038.tabs.0.elements.1.id','null'),('addresses.fieldLayouts.3b96b45d-f21f-43cb-a9b5-35a61552e038.tabs.0.elements.1.instructions','null'),('addresses.fieldLayouts.3b96b45d-f21f-43cb-a9b5-35a61552e038.tabs.0.elements.1.label','null'),('addresses.fieldLayouts.3b96b45d-f21f-43cb-a9b5-35a61552e038.tabs.0.elements.1.orientation','null'),('addresses.fieldLayouts.3b96b45d-f21f-43cb-a9b5-35a61552e038.tabs.0.elements.1.requirable','false'),('addresses.fieldLayouts.3b96b45d-f21f-43cb-a9b5-35a61552e038.tabs.0.elements.1.tip','null'),('addresses.fieldLayouts.3b96b45d-f21f-43cb-a9b5-35a61552e038.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\addresses\\\\CountryCodeField\"'),('addresses.fieldLayouts.3b96b45d-f21f-43cb-a9b5-35a61552e038.tabs.0.elements.1.uid','\"22410437-9f4a-4a2d-a22b-0129789e3978\"'),('addresses.fieldLayouts.3b96b45d-f21f-43cb-a9b5-35a61552e038.tabs.0.elements.1.userCondition','null'),('addresses.fieldLayouts.3b96b45d-f21f-43cb-a9b5-35a61552e038.tabs.0.elements.1.warning','null'),('addresses.fieldLayouts.3b96b45d-f21f-43cb-a9b5-35a61552e038.tabs.0.elements.1.width','100'),('addresses.fieldLayouts.3b96b45d-f21f-43cb-a9b5-35a61552e038.tabs.0.elements.2.elementCondition','null'),('addresses.fieldLayouts.3b96b45d-f21f-43cb-a9b5-35a61552e038.tabs.0.elements.2.instructions','null'),('addresses.fieldLayouts.3b96b45d-f21f-43cb-a9b5-35a61552e038.tabs.0.elements.2.label','null'),('addresses.fieldLayouts.3b96b45d-f21f-43cb-a9b5-35a61552e038.tabs.0.elements.2.required','false'),('addresses.fieldLayouts.3b96b45d-f21f-43cb-a9b5-35a61552e038.tabs.0.elements.2.tip','null'),('addresses.fieldLayouts.3b96b45d-f21f-43cb-a9b5-35a61552e038.tabs.0.elements.2.type','\"craft\\\\fieldlayoutelements\\\\addresses\\\\AddressField\"'),('addresses.fieldLayouts.3b96b45d-f21f-43cb-a9b5-35a61552e038.tabs.0.elements.2.uid','\"32797a07-d096-4b13-84be-efe291a1907f\"'),('addresses.fieldLayouts.3b96b45d-f21f-43cb-a9b5-35a61552e038.tabs.0.elements.2.userCondition','null'),('addresses.fieldLayouts.3b96b45d-f21f-43cb-a9b5-35a61552e038.tabs.0.elements.2.warning','null'),('addresses.fieldLayouts.3b96b45d-f21f-43cb-a9b5-35a61552e038.tabs.0.name','\"Content\"'),('addresses.fieldLayouts.3b96b45d-f21f-43cb-a9b5-35a61552e038.tabs.0.uid','\"b5b529ef-30f3-4a5f-9b20-404a54f7d152\"'),('addresses.fieldLayouts.3b96b45d-f21f-43cb-a9b5-35a61552e038.tabs.0.userCondition','null'),('dateModified','1699807860'),('email.fromEmail','\"hello@emagine.ie\"'),('email.fromName','\"Emagine VR Analytics\"'),('email.transportType','\"craft\\\\mail\\\\transportadapters\\\\Sendmail\"'),('entryTypes.17e706db-ccd3-4eab-9d3a-e8e5fed9d10a.fieldLayouts.aa2f56ec-be2f-4366-b912-a48ddfd78b14.tabs.0.elementCondition','null'),('entryTypes.17e706db-ccd3-4eab-9d3a-e8e5fed9d10a.fieldLayouts.aa2f56ec-be2f-4366-b912-a48ddfd78b14.tabs.0.elements.0.autocapitalize','true'),('entryTypes.17e706db-ccd3-4eab-9d3a-e8e5fed9d10a.fieldLayouts.aa2f56ec-be2f-4366-b912-a48ddfd78b14.tabs.0.elements.0.autocomplete','false'),('entryTypes.17e706db-ccd3-4eab-9d3a-e8e5fed9d10a.fieldLayouts.aa2f56ec-be2f-4366-b912-a48ddfd78b14.tabs.0.elements.0.autocorrect','true'),('entryTypes.17e706db-ccd3-4eab-9d3a-e8e5fed9d10a.fieldLayouts.aa2f56ec-be2f-4366-b912-a48ddfd78b14.tabs.0.elements.0.class','null'),('entryTypes.17e706db-ccd3-4eab-9d3a-e8e5fed9d10a.fieldLayouts.aa2f56ec-be2f-4366-b912-a48ddfd78b14.tabs.0.elements.0.disabled','false'),('entryTypes.17e706db-ccd3-4eab-9d3a-e8e5fed9d10a.fieldLayouts.aa2f56ec-be2f-4366-b912-a48ddfd78b14.tabs.0.elements.0.elementCondition','null'),('entryTypes.17e706db-ccd3-4eab-9d3a-e8e5fed9d10a.fieldLayouts.aa2f56ec-be2f-4366-b912-a48ddfd78b14.tabs.0.elements.0.id','null'),('entryTypes.17e706db-ccd3-4eab-9d3a-e8e5fed9d10a.fieldLayouts.aa2f56ec-be2f-4366-b912-a48ddfd78b14.tabs.0.elements.0.instructions','null'),('entryTypes.17e706db-ccd3-4eab-9d3a-e8e5fed9d10a.fieldLayouts.aa2f56ec-be2f-4366-b912-a48ddfd78b14.tabs.0.elements.0.label','null'),('entryTypes.17e706db-ccd3-4eab-9d3a-e8e5fed9d10a.fieldLayouts.aa2f56ec-be2f-4366-b912-a48ddfd78b14.tabs.0.elements.0.max','null'),('entryTypes.17e706db-ccd3-4eab-9d3a-e8e5fed9d10a.fieldLayouts.aa2f56ec-be2f-4366-b912-a48ddfd78b14.tabs.0.elements.0.min','null'),('entryTypes.17e706db-ccd3-4eab-9d3a-e8e5fed9d10a.fieldLayouts.aa2f56ec-be2f-4366-b912-a48ddfd78b14.tabs.0.elements.0.name','null'),('entryTypes.17e706db-ccd3-4eab-9d3a-e8e5fed9d10a.fieldLayouts.aa2f56ec-be2f-4366-b912-a48ddfd78b14.tabs.0.elements.0.orientation','null'),('entryTypes.17e706db-ccd3-4eab-9d3a-e8e5fed9d10a.fieldLayouts.aa2f56ec-be2f-4366-b912-a48ddfd78b14.tabs.0.elements.0.placeholder','null'),('entryTypes.17e706db-ccd3-4eab-9d3a-e8e5fed9d10a.fieldLayouts.aa2f56ec-be2f-4366-b912-a48ddfd78b14.tabs.0.elements.0.readonly','false'),('entryTypes.17e706db-ccd3-4eab-9d3a-e8e5fed9d10a.fieldLayouts.aa2f56ec-be2f-4366-b912-a48ddfd78b14.tabs.0.elements.0.requirable','false'),('entryTypes.17e706db-ccd3-4eab-9d3a-e8e5fed9d10a.fieldLayouts.aa2f56ec-be2f-4366-b912-a48ddfd78b14.tabs.0.elements.0.size','null'),('entryTypes.17e706db-ccd3-4eab-9d3a-e8e5fed9d10a.fieldLayouts.aa2f56ec-be2f-4366-b912-a48ddfd78b14.tabs.0.elements.0.step','null'),('entryTypes.17e706db-ccd3-4eab-9d3a-e8e5fed9d10a.fieldLayouts.aa2f56ec-be2f-4366-b912-a48ddfd78b14.tabs.0.elements.0.tip','null'),('entryTypes.17e706db-ccd3-4eab-9d3a-e8e5fed9d10a.fieldLayouts.aa2f56ec-be2f-4366-b912-a48ddfd78b14.tabs.0.elements.0.title','null'),('entryTypes.17e706db-ccd3-4eab-9d3a-e8e5fed9d10a.fieldLayouts.aa2f56ec-be2f-4366-b912-a48ddfd78b14.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.17e706db-ccd3-4eab-9d3a-e8e5fed9d10a.fieldLayouts.aa2f56ec-be2f-4366-b912-a48ddfd78b14.tabs.0.elements.0.uid','\"76d94e3f-53f5-40d2-a603-50d6bb44b943\"'),('entryTypes.17e706db-ccd3-4eab-9d3a-e8e5fed9d10a.fieldLayouts.aa2f56ec-be2f-4366-b912-a48ddfd78b14.tabs.0.elements.0.userCondition','null'),('entryTypes.17e706db-ccd3-4eab-9d3a-e8e5fed9d10a.fieldLayouts.aa2f56ec-be2f-4366-b912-a48ddfd78b14.tabs.0.elements.0.warning','null'),('entryTypes.17e706db-ccd3-4eab-9d3a-e8e5fed9d10a.fieldLayouts.aa2f56ec-be2f-4366-b912-a48ddfd78b14.tabs.0.elements.0.width','100'),('entryTypes.17e706db-ccd3-4eab-9d3a-e8e5fed9d10a.fieldLayouts.aa2f56ec-be2f-4366-b912-a48ddfd78b14.tabs.0.elements.1.elementCondition','null'),('entryTypes.17e706db-ccd3-4eab-9d3a-e8e5fed9d10a.fieldLayouts.aa2f56ec-be2f-4366-b912-a48ddfd78b14.tabs.0.elements.1.fieldUid','\"6af92e13-3817-4619-a65c-3522d4d1fc67\"'),('entryTypes.17e706db-ccd3-4eab-9d3a-e8e5fed9d10a.fieldLayouts.aa2f56ec-be2f-4366-b912-a48ddfd78b14.tabs.0.elements.1.instructions','null'),('entryTypes.17e706db-ccd3-4eab-9d3a-e8e5fed9d10a.fieldLayouts.aa2f56ec-be2f-4366-b912-a48ddfd78b14.tabs.0.elements.1.label','null'),('entryTypes.17e706db-ccd3-4eab-9d3a-e8e5fed9d10a.fieldLayouts.aa2f56ec-be2f-4366-b912-a48ddfd78b14.tabs.0.elements.1.required','false'),('entryTypes.17e706db-ccd3-4eab-9d3a-e8e5fed9d10a.fieldLayouts.aa2f56ec-be2f-4366-b912-a48ddfd78b14.tabs.0.elements.1.tip','null'),('entryTypes.17e706db-ccd3-4eab-9d3a-e8e5fed9d10a.fieldLayouts.aa2f56ec-be2f-4366-b912-a48ddfd78b14.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.17e706db-ccd3-4eab-9d3a-e8e5fed9d10a.fieldLayouts.aa2f56ec-be2f-4366-b912-a48ddfd78b14.tabs.0.elements.1.uid','\"3a89feaa-1397-41b9-8a03-9e6c3492c331\"'),('entryTypes.17e706db-ccd3-4eab-9d3a-e8e5fed9d10a.fieldLayouts.aa2f56ec-be2f-4366-b912-a48ddfd78b14.tabs.0.elements.1.userCondition','null'),('entryTypes.17e706db-ccd3-4eab-9d3a-e8e5fed9d10a.fieldLayouts.aa2f56ec-be2f-4366-b912-a48ddfd78b14.tabs.0.elements.1.warning','null'),('entryTypes.17e706db-ccd3-4eab-9d3a-e8e5fed9d10a.fieldLayouts.aa2f56ec-be2f-4366-b912-a48ddfd78b14.tabs.0.elements.1.width','100'),('entryTypes.17e706db-ccd3-4eab-9d3a-e8e5fed9d10a.fieldLayouts.aa2f56ec-be2f-4366-b912-a48ddfd78b14.tabs.0.name','\"Content\"'),('entryTypes.17e706db-ccd3-4eab-9d3a-e8e5fed9d10a.fieldLayouts.aa2f56ec-be2f-4366-b912-a48ddfd78b14.tabs.0.uid','\"17356f99-2ef6-4a3f-88ab-b1cb7d345a80\"'),('entryTypes.17e706db-ccd3-4eab-9d3a-e8e5fed9d10a.fieldLayouts.aa2f56ec-be2f-4366-b912-a48ddfd78b14.tabs.0.userCondition','null'),('entryTypes.17e706db-ccd3-4eab-9d3a-e8e5fed9d10a.handle','\"default\"'),('entryTypes.17e706db-ccd3-4eab-9d3a-e8e5fed9d10a.hasTitleField','true'),('entryTypes.17e706db-ccd3-4eab-9d3a-e8e5fed9d10a.name','\"Default\"'),('entryTypes.17e706db-ccd3-4eab-9d3a-e8e5fed9d10a.section','\"38875b9f-df2c-41e6-a1a2-e9d4ed370735\"'),('entryTypes.17e706db-ccd3-4eab-9d3a-e8e5fed9d10a.showStatusField','true'),('entryTypes.17e706db-ccd3-4eab-9d3a-e8e5fed9d10a.slugTranslationKeyFormat','null'),('entryTypes.17e706db-ccd3-4eab-9d3a-e8e5fed9d10a.slugTranslationMethod','\"site\"'),('entryTypes.17e706db-ccd3-4eab-9d3a-e8e5fed9d10a.sortOrder','1'),('entryTypes.17e706db-ccd3-4eab-9d3a-e8e5fed9d10a.titleFormat','null'),('entryTypes.17e706db-ccd3-4eab-9d3a-e8e5fed9d10a.titleTranslationKeyFormat','null'),('entryTypes.17e706db-ccd3-4eab-9d3a-e8e5fed9d10a.titleTranslationMethod','\"site\"'),('entryTypes.6e395cf4-c9ab-4960-8c68-62b6bbcf4714.fieldLayouts.1a5270c8-f8f6-4f71-959e-d7a32533b197.tabs.0.elementCondition','null'),('entryTypes.6e395cf4-c9ab-4960-8c68-62b6bbcf4714.fieldLayouts.1a5270c8-f8f6-4f71-959e-d7a32533b197.tabs.0.elements.0.autocapitalize','true'),('entryTypes.6e395cf4-c9ab-4960-8c68-62b6bbcf4714.fieldLayouts.1a5270c8-f8f6-4f71-959e-d7a32533b197.tabs.0.elements.0.autocomplete','false'),('entryTypes.6e395cf4-c9ab-4960-8c68-62b6bbcf4714.fieldLayouts.1a5270c8-f8f6-4f71-959e-d7a32533b197.tabs.0.elements.0.autocorrect','true'),('entryTypes.6e395cf4-c9ab-4960-8c68-62b6bbcf4714.fieldLayouts.1a5270c8-f8f6-4f71-959e-d7a32533b197.tabs.0.elements.0.class','null'),('entryTypes.6e395cf4-c9ab-4960-8c68-62b6bbcf4714.fieldLayouts.1a5270c8-f8f6-4f71-959e-d7a32533b197.tabs.0.elements.0.disabled','false'),('entryTypes.6e395cf4-c9ab-4960-8c68-62b6bbcf4714.fieldLayouts.1a5270c8-f8f6-4f71-959e-d7a32533b197.tabs.0.elements.0.elementCondition','null'),('entryTypes.6e395cf4-c9ab-4960-8c68-62b6bbcf4714.fieldLayouts.1a5270c8-f8f6-4f71-959e-d7a32533b197.tabs.0.elements.0.id','null'),('entryTypes.6e395cf4-c9ab-4960-8c68-62b6bbcf4714.fieldLayouts.1a5270c8-f8f6-4f71-959e-d7a32533b197.tabs.0.elements.0.instructions','null'),('entryTypes.6e395cf4-c9ab-4960-8c68-62b6bbcf4714.fieldLayouts.1a5270c8-f8f6-4f71-959e-d7a32533b197.tabs.0.elements.0.label','null'),('entryTypes.6e395cf4-c9ab-4960-8c68-62b6bbcf4714.fieldLayouts.1a5270c8-f8f6-4f71-959e-d7a32533b197.tabs.0.elements.0.max','null'),('entryTypes.6e395cf4-c9ab-4960-8c68-62b6bbcf4714.fieldLayouts.1a5270c8-f8f6-4f71-959e-d7a32533b197.tabs.0.elements.0.min','null'),('entryTypes.6e395cf4-c9ab-4960-8c68-62b6bbcf4714.fieldLayouts.1a5270c8-f8f6-4f71-959e-d7a32533b197.tabs.0.elements.0.name','null'),('entryTypes.6e395cf4-c9ab-4960-8c68-62b6bbcf4714.fieldLayouts.1a5270c8-f8f6-4f71-959e-d7a32533b197.tabs.0.elements.0.orientation','null'),('entryTypes.6e395cf4-c9ab-4960-8c68-62b6bbcf4714.fieldLayouts.1a5270c8-f8f6-4f71-959e-d7a32533b197.tabs.0.elements.0.placeholder','null'),('entryTypes.6e395cf4-c9ab-4960-8c68-62b6bbcf4714.fieldLayouts.1a5270c8-f8f6-4f71-959e-d7a32533b197.tabs.0.elements.0.readonly','false'),('entryTypes.6e395cf4-c9ab-4960-8c68-62b6bbcf4714.fieldLayouts.1a5270c8-f8f6-4f71-959e-d7a32533b197.tabs.0.elements.0.requirable','false'),('entryTypes.6e395cf4-c9ab-4960-8c68-62b6bbcf4714.fieldLayouts.1a5270c8-f8f6-4f71-959e-d7a32533b197.tabs.0.elements.0.size','null'),('entryTypes.6e395cf4-c9ab-4960-8c68-62b6bbcf4714.fieldLayouts.1a5270c8-f8f6-4f71-959e-d7a32533b197.tabs.0.elements.0.step','null'),('entryTypes.6e395cf4-c9ab-4960-8c68-62b6bbcf4714.fieldLayouts.1a5270c8-f8f6-4f71-959e-d7a32533b197.tabs.0.elements.0.tip','null'),('entryTypes.6e395cf4-c9ab-4960-8c68-62b6bbcf4714.fieldLayouts.1a5270c8-f8f6-4f71-959e-d7a32533b197.tabs.0.elements.0.title','null'),('entryTypes.6e395cf4-c9ab-4960-8c68-62b6bbcf4714.fieldLayouts.1a5270c8-f8f6-4f71-959e-d7a32533b197.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.6e395cf4-c9ab-4960-8c68-62b6bbcf4714.fieldLayouts.1a5270c8-f8f6-4f71-959e-d7a32533b197.tabs.0.elements.0.uid','\"64eb4453-9b20-475c-949e-2d7a5e5562a7\"'),('entryTypes.6e395cf4-c9ab-4960-8c68-62b6bbcf4714.fieldLayouts.1a5270c8-f8f6-4f71-959e-d7a32533b197.tabs.0.elements.0.userCondition','null'),('entryTypes.6e395cf4-c9ab-4960-8c68-62b6bbcf4714.fieldLayouts.1a5270c8-f8f6-4f71-959e-d7a32533b197.tabs.0.elements.0.warning','null'),('entryTypes.6e395cf4-c9ab-4960-8c68-62b6bbcf4714.fieldLayouts.1a5270c8-f8f6-4f71-959e-d7a32533b197.tabs.0.elements.0.width','100'),('entryTypes.6e395cf4-c9ab-4960-8c68-62b6bbcf4714.fieldLayouts.1a5270c8-f8f6-4f71-959e-d7a32533b197.tabs.0.elements.1.elementCondition','null'),('entryTypes.6e395cf4-c9ab-4960-8c68-62b6bbcf4714.fieldLayouts.1a5270c8-f8f6-4f71-959e-d7a32533b197.tabs.0.elements.1.fieldUid','\"73ccaa0c-844d-46d0-8b58-e33c1baaa8f2\"'),('entryTypes.6e395cf4-c9ab-4960-8c68-62b6bbcf4714.fieldLayouts.1a5270c8-f8f6-4f71-959e-d7a32533b197.tabs.0.elements.1.instructions','null'),('entryTypes.6e395cf4-c9ab-4960-8c68-62b6bbcf4714.fieldLayouts.1a5270c8-f8f6-4f71-959e-d7a32533b197.tabs.0.elements.1.label','null'),('entryTypes.6e395cf4-c9ab-4960-8c68-62b6bbcf4714.fieldLayouts.1a5270c8-f8f6-4f71-959e-d7a32533b197.tabs.0.elements.1.required','false'),('entryTypes.6e395cf4-c9ab-4960-8c68-62b6bbcf4714.fieldLayouts.1a5270c8-f8f6-4f71-959e-d7a32533b197.tabs.0.elements.1.tip','null'),('entryTypes.6e395cf4-c9ab-4960-8c68-62b6bbcf4714.fieldLayouts.1a5270c8-f8f6-4f71-959e-d7a32533b197.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.6e395cf4-c9ab-4960-8c68-62b6bbcf4714.fieldLayouts.1a5270c8-f8f6-4f71-959e-d7a32533b197.tabs.0.elements.1.uid','\"64617af7-43bf-4c01-82fc-f285df54ecbd\"'),('entryTypes.6e395cf4-c9ab-4960-8c68-62b6bbcf4714.fieldLayouts.1a5270c8-f8f6-4f71-959e-d7a32533b197.tabs.0.elements.1.userCondition','null'),('entryTypes.6e395cf4-c9ab-4960-8c68-62b6bbcf4714.fieldLayouts.1a5270c8-f8f6-4f71-959e-d7a32533b197.tabs.0.elements.1.warning','null'),('entryTypes.6e395cf4-c9ab-4960-8c68-62b6bbcf4714.fieldLayouts.1a5270c8-f8f6-4f71-959e-d7a32533b197.tabs.0.elements.1.width','100'),('entryTypes.6e395cf4-c9ab-4960-8c68-62b6bbcf4714.fieldLayouts.1a5270c8-f8f6-4f71-959e-d7a32533b197.tabs.0.elements.2.elementCondition','null'),('entryTypes.6e395cf4-c9ab-4960-8c68-62b6bbcf4714.fieldLayouts.1a5270c8-f8f6-4f71-959e-d7a32533b197.tabs.0.elements.2.fieldUid','\"312b4f06-f575-487d-8777-e646ddb19ba6\"'),('entryTypes.6e395cf4-c9ab-4960-8c68-62b6bbcf4714.fieldLayouts.1a5270c8-f8f6-4f71-959e-d7a32533b197.tabs.0.elements.2.instructions','null'),('entryTypes.6e395cf4-c9ab-4960-8c68-62b6bbcf4714.fieldLayouts.1a5270c8-f8f6-4f71-959e-d7a32533b197.tabs.0.elements.2.label','null'),('entryTypes.6e395cf4-c9ab-4960-8c68-62b6bbcf4714.fieldLayouts.1a5270c8-f8f6-4f71-959e-d7a32533b197.tabs.0.elements.2.required','false'),('entryTypes.6e395cf4-c9ab-4960-8c68-62b6bbcf4714.fieldLayouts.1a5270c8-f8f6-4f71-959e-d7a32533b197.tabs.0.elements.2.tip','null'),('entryTypes.6e395cf4-c9ab-4960-8c68-62b6bbcf4714.fieldLayouts.1a5270c8-f8f6-4f71-959e-d7a32533b197.tabs.0.elements.2.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.6e395cf4-c9ab-4960-8c68-62b6bbcf4714.fieldLayouts.1a5270c8-f8f6-4f71-959e-d7a32533b197.tabs.0.elements.2.uid','\"8ac14d5b-89ce-446a-bd21-1ab2bd3a9aeb\"'),('entryTypes.6e395cf4-c9ab-4960-8c68-62b6bbcf4714.fieldLayouts.1a5270c8-f8f6-4f71-959e-d7a32533b197.tabs.0.elements.2.userCondition','null'),('entryTypes.6e395cf4-c9ab-4960-8c68-62b6bbcf4714.fieldLayouts.1a5270c8-f8f6-4f71-959e-d7a32533b197.tabs.0.elements.2.warning','null'),('entryTypes.6e395cf4-c9ab-4960-8c68-62b6bbcf4714.fieldLayouts.1a5270c8-f8f6-4f71-959e-d7a32533b197.tabs.0.elements.2.width','100'),('entryTypes.6e395cf4-c9ab-4960-8c68-62b6bbcf4714.fieldLayouts.1a5270c8-f8f6-4f71-959e-d7a32533b197.tabs.0.elements.3.elementCondition','null'),('entryTypes.6e395cf4-c9ab-4960-8c68-62b6bbcf4714.fieldLayouts.1a5270c8-f8f6-4f71-959e-d7a32533b197.tabs.0.elements.3.fieldUid','\"0084065a-21dc-4833-9064-d97f4e1c9bca\"'),('entryTypes.6e395cf4-c9ab-4960-8c68-62b6bbcf4714.fieldLayouts.1a5270c8-f8f6-4f71-959e-d7a32533b197.tabs.0.elements.3.instructions','null'),('entryTypes.6e395cf4-c9ab-4960-8c68-62b6bbcf4714.fieldLayouts.1a5270c8-f8f6-4f71-959e-d7a32533b197.tabs.0.elements.3.label','null'),('entryTypes.6e395cf4-c9ab-4960-8c68-62b6bbcf4714.fieldLayouts.1a5270c8-f8f6-4f71-959e-d7a32533b197.tabs.0.elements.3.required','false'),('entryTypes.6e395cf4-c9ab-4960-8c68-62b6bbcf4714.fieldLayouts.1a5270c8-f8f6-4f71-959e-d7a32533b197.tabs.0.elements.3.tip','null'),('entryTypes.6e395cf4-c9ab-4960-8c68-62b6bbcf4714.fieldLayouts.1a5270c8-f8f6-4f71-959e-d7a32533b197.tabs.0.elements.3.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.6e395cf4-c9ab-4960-8c68-62b6bbcf4714.fieldLayouts.1a5270c8-f8f6-4f71-959e-d7a32533b197.tabs.0.elements.3.uid','\"9613bd6c-ed15-456c-a016-2c73a74aa965\"'),('entryTypes.6e395cf4-c9ab-4960-8c68-62b6bbcf4714.fieldLayouts.1a5270c8-f8f6-4f71-959e-d7a32533b197.tabs.0.elements.3.userCondition','null'),('entryTypes.6e395cf4-c9ab-4960-8c68-62b6bbcf4714.fieldLayouts.1a5270c8-f8f6-4f71-959e-d7a32533b197.tabs.0.elements.3.warning','null'),('entryTypes.6e395cf4-c9ab-4960-8c68-62b6bbcf4714.fieldLayouts.1a5270c8-f8f6-4f71-959e-d7a32533b197.tabs.0.elements.3.width','100'),('entryTypes.6e395cf4-c9ab-4960-8c68-62b6bbcf4714.fieldLayouts.1a5270c8-f8f6-4f71-959e-d7a32533b197.tabs.0.elements.4.elementCondition','null'),('entryTypes.6e395cf4-c9ab-4960-8c68-62b6bbcf4714.fieldLayouts.1a5270c8-f8f6-4f71-959e-d7a32533b197.tabs.0.elements.4.fieldUid','\"cc7c385a-fa47-48b0-8edb-006e60e4b8f1\"'),('entryTypes.6e395cf4-c9ab-4960-8c68-62b6bbcf4714.fieldLayouts.1a5270c8-f8f6-4f71-959e-d7a32533b197.tabs.0.elements.4.instructions','null'),('entryTypes.6e395cf4-c9ab-4960-8c68-62b6bbcf4714.fieldLayouts.1a5270c8-f8f6-4f71-959e-d7a32533b197.tabs.0.elements.4.label','null'),('entryTypes.6e395cf4-c9ab-4960-8c68-62b6bbcf4714.fieldLayouts.1a5270c8-f8f6-4f71-959e-d7a32533b197.tabs.0.elements.4.required','false'),('entryTypes.6e395cf4-c9ab-4960-8c68-62b6bbcf4714.fieldLayouts.1a5270c8-f8f6-4f71-959e-d7a32533b197.tabs.0.elements.4.tip','null'),('entryTypes.6e395cf4-c9ab-4960-8c68-62b6bbcf4714.fieldLayouts.1a5270c8-f8f6-4f71-959e-d7a32533b197.tabs.0.elements.4.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.6e395cf4-c9ab-4960-8c68-62b6bbcf4714.fieldLayouts.1a5270c8-f8f6-4f71-959e-d7a32533b197.tabs.0.elements.4.uid','\"2a6466e8-6d24-49b9-b418-e7cd3c5ad96a\"'),('entryTypes.6e395cf4-c9ab-4960-8c68-62b6bbcf4714.fieldLayouts.1a5270c8-f8f6-4f71-959e-d7a32533b197.tabs.0.elements.4.userCondition','null'),('entryTypes.6e395cf4-c9ab-4960-8c68-62b6bbcf4714.fieldLayouts.1a5270c8-f8f6-4f71-959e-d7a32533b197.tabs.0.elements.4.warning','null'),('entryTypes.6e395cf4-c9ab-4960-8c68-62b6bbcf4714.fieldLayouts.1a5270c8-f8f6-4f71-959e-d7a32533b197.tabs.0.elements.4.width','100'),('entryTypes.6e395cf4-c9ab-4960-8c68-62b6bbcf4714.fieldLayouts.1a5270c8-f8f6-4f71-959e-d7a32533b197.tabs.0.name','\"Content\"'),('entryTypes.6e395cf4-c9ab-4960-8c68-62b6bbcf4714.fieldLayouts.1a5270c8-f8f6-4f71-959e-d7a32533b197.tabs.0.uid','\"2daef3ad-2dcf-4b09-a6af-4d8904001084\"'),('entryTypes.6e395cf4-c9ab-4960-8c68-62b6bbcf4714.fieldLayouts.1a5270c8-f8f6-4f71-959e-d7a32533b197.tabs.0.userCondition','null'),('entryTypes.6e395cf4-c9ab-4960-8c68-62b6bbcf4714.handle','\"default\"'),('entryTypes.6e395cf4-c9ab-4960-8c68-62b6bbcf4714.hasTitleField','true'),('entryTypes.6e395cf4-c9ab-4960-8c68-62b6bbcf4714.name','\"Default\"'),('entryTypes.6e395cf4-c9ab-4960-8c68-62b6bbcf4714.section','\"fa1a9449-1cdb-4185-8017-6d6baea8371b\"'),('entryTypes.6e395cf4-c9ab-4960-8c68-62b6bbcf4714.showStatusField','true'),('entryTypes.6e395cf4-c9ab-4960-8c68-62b6bbcf4714.slugTranslationKeyFormat','null'),('entryTypes.6e395cf4-c9ab-4960-8c68-62b6bbcf4714.slugTranslationMethod','\"site\"'),('entryTypes.6e395cf4-c9ab-4960-8c68-62b6bbcf4714.sortOrder','1'),('entryTypes.6e395cf4-c9ab-4960-8c68-62b6bbcf4714.titleFormat','null'),('entryTypes.6e395cf4-c9ab-4960-8c68-62b6bbcf4714.titleTranslationKeyFormat','null'),('entryTypes.6e395cf4-c9ab-4960-8c68-62b6bbcf4714.titleTranslationMethod','\"site\"'),('entryTypes.a7b7e1ba-7fb3-4258-8a31-c45adeaf82b8.fieldLayouts.f34af012-d7be-42c8-99fe-b20987d7b77d.tabs.0.elementCondition','null'),('entryTypes.a7b7e1ba-7fb3-4258-8a31-c45adeaf82b8.fieldLayouts.f34af012-d7be-42c8-99fe-b20987d7b77d.tabs.0.elements.0.autocapitalize','true'),('entryTypes.a7b7e1ba-7fb3-4258-8a31-c45adeaf82b8.fieldLayouts.f34af012-d7be-42c8-99fe-b20987d7b77d.tabs.0.elements.0.autocomplete','false'),('entryTypes.a7b7e1ba-7fb3-4258-8a31-c45adeaf82b8.fieldLayouts.f34af012-d7be-42c8-99fe-b20987d7b77d.tabs.0.elements.0.autocorrect','true'),('entryTypes.a7b7e1ba-7fb3-4258-8a31-c45adeaf82b8.fieldLayouts.f34af012-d7be-42c8-99fe-b20987d7b77d.tabs.0.elements.0.class','null'),('entryTypes.a7b7e1ba-7fb3-4258-8a31-c45adeaf82b8.fieldLayouts.f34af012-d7be-42c8-99fe-b20987d7b77d.tabs.0.elements.0.disabled','false'),('entryTypes.a7b7e1ba-7fb3-4258-8a31-c45adeaf82b8.fieldLayouts.f34af012-d7be-42c8-99fe-b20987d7b77d.tabs.0.elements.0.elementCondition','null'),('entryTypes.a7b7e1ba-7fb3-4258-8a31-c45adeaf82b8.fieldLayouts.f34af012-d7be-42c8-99fe-b20987d7b77d.tabs.0.elements.0.id','null'),('entryTypes.a7b7e1ba-7fb3-4258-8a31-c45adeaf82b8.fieldLayouts.f34af012-d7be-42c8-99fe-b20987d7b77d.tabs.0.elements.0.instructions','null'),('entryTypes.a7b7e1ba-7fb3-4258-8a31-c45adeaf82b8.fieldLayouts.f34af012-d7be-42c8-99fe-b20987d7b77d.tabs.0.elements.0.label','null'),('entryTypes.a7b7e1ba-7fb3-4258-8a31-c45adeaf82b8.fieldLayouts.f34af012-d7be-42c8-99fe-b20987d7b77d.tabs.0.elements.0.max','null'),('entryTypes.a7b7e1ba-7fb3-4258-8a31-c45adeaf82b8.fieldLayouts.f34af012-d7be-42c8-99fe-b20987d7b77d.tabs.0.elements.0.min','null'),('entryTypes.a7b7e1ba-7fb3-4258-8a31-c45adeaf82b8.fieldLayouts.f34af012-d7be-42c8-99fe-b20987d7b77d.tabs.0.elements.0.name','null'),('entryTypes.a7b7e1ba-7fb3-4258-8a31-c45adeaf82b8.fieldLayouts.f34af012-d7be-42c8-99fe-b20987d7b77d.tabs.0.elements.0.orientation','null'),('entryTypes.a7b7e1ba-7fb3-4258-8a31-c45adeaf82b8.fieldLayouts.f34af012-d7be-42c8-99fe-b20987d7b77d.tabs.0.elements.0.placeholder','null'),('entryTypes.a7b7e1ba-7fb3-4258-8a31-c45adeaf82b8.fieldLayouts.f34af012-d7be-42c8-99fe-b20987d7b77d.tabs.0.elements.0.readonly','false'),('entryTypes.a7b7e1ba-7fb3-4258-8a31-c45adeaf82b8.fieldLayouts.f34af012-d7be-42c8-99fe-b20987d7b77d.tabs.0.elements.0.requirable','false'),('entryTypes.a7b7e1ba-7fb3-4258-8a31-c45adeaf82b8.fieldLayouts.f34af012-d7be-42c8-99fe-b20987d7b77d.tabs.0.elements.0.size','null'),('entryTypes.a7b7e1ba-7fb3-4258-8a31-c45adeaf82b8.fieldLayouts.f34af012-d7be-42c8-99fe-b20987d7b77d.tabs.0.elements.0.step','null'),('entryTypes.a7b7e1ba-7fb3-4258-8a31-c45adeaf82b8.fieldLayouts.f34af012-d7be-42c8-99fe-b20987d7b77d.tabs.0.elements.0.tip','null'),('entryTypes.a7b7e1ba-7fb3-4258-8a31-c45adeaf82b8.fieldLayouts.f34af012-d7be-42c8-99fe-b20987d7b77d.tabs.0.elements.0.title','null'),('entryTypes.a7b7e1ba-7fb3-4258-8a31-c45adeaf82b8.fieldLayouts.f34af012-d7be-42c8-99fe-b20987d7b77d.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.a7b7e1ba-7fb3-4258-8a31-c45adeaf82b8.fieldLayouts.f34af012-d7be-42c8-99fe-b20987d7b77d.tabs.0.elements.0.uid','\"3212ee3b-9702-43bb-b2c9-20825de5c4cd\"'),('entryTypes.a7b7e1ba-7fb3-4258-8a31-c45adeaf82b8.fieldLayouts.f34af012-d7be-42c8-99fe-b20987d7b77d.tabs.0.elements.0.userCondition','null'),('entryTypes.a7b7e1ba-7fb3-4258-8a31-c45adeaf82b8.fieldLayouts.f34af012-d7be-42c8-99fe-b20987d7b77d.tabs.0.elements.0.warning','null'),('entryTypes.a7b7e1ba-7fb3-4258-8a31-c45adeaf82b8.fieldLayouts.f34af012-d7be-42c8-99fe-b20987d7b77d.tabs.0.elements.0.width','100'),('entryTypes.a7b7e1ba-7fb3-4258-8a31-c45adeaf82b8.fieldLayouts.f34af012-d7be-42c8-99fe-b20987d7b77d.tabs.0.name','\"Content\"'),('entryTypes.a7b7e1ba-7fb3-4258-8a31-c45adeaf82b8.fieldLayouts.f34af012-d7be-42c8-99fe-b20987d7b77d.tabs.0.uid','\"51f08e6f-f44f-4293-bc27-451451544caa\"'),('entryTypes.a7b7e1ba-7fb3-4258-8a31-c45adeaf82b8.fieldLayouts.f34af012-d7be-42c8-99fe-b20987d7b77d.tabs.0.userCondition','null'),('entryTypes.a7b7e1ba-7fb3-4258-8a31-c45adeaf82b8.handle','\"default\"'),('entryTypes.a7b7e1ba-7fb3-4258-8a31-c45adeaf82b8.hasTitleField','true'),('entryTypes.a7b7e1ba-7fb3-4258-8a31-c45adeaf82b8.name','\"Default\"'),('entryTypes.a7b7e1ba-7fb3-4258-8a31-c45adeaf82b8.section','\"b3e8c798-1f09-4ca2-ac30-695d0273d094\"'),('entryTypes.a7b7e1ba-7fb3-4258-8a31-c45adeaf82b8.showStatusField','true'),('entryTypes.a7b7e1ba-7fb3-4258-8a31-c45adeaf82b8.slugTranslationKeyFormat','null'),('entryTypes.a7b7e1ba-7fb3-4258-8a31-c45adeaf82b8.slugTranslationMethod','\"site\"'),('entryTypes.a7b7e1ba-7fb3-4258-8a31-c45adeaf82b8.sortOrder','1'),('entryTypes.a7b7e1ba-7fb3-4258-8a31-c45adeaf82b8.titleFormat','null'),('entryTypes.a7b7e1ba-7fb3-4258-8a31-c45adeaf82b8.titleTranslationKeyFormat','null'),('entryTypes.a7b7e1ba-7fb3-4258-8a31-c45adeaf82b8.titleTranslationMethod','\"site\"'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.fieldLayouts.4148225d-9e14-42d3-b0d7-bc884c5588ad.tabs.0.elementCondition','null'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.fieldLayouts.4148225d-9e14-42d3-b0d7-bc884c5588ad.tabs.0.elements.0.autocapitalize','true'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.fieldLayouts.4148225d-9e14-42d3-b0d7-bc884c5588ad.tabs.0.elements.0.autocomplete','false'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.fieldLayouts.4148225d-9e14-42d3-b0d7-bc884c5588ad.tabs.0.elements.0.autocorrect','true'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.fieldLayouts.4148225d-9e14-42d3-b0d7-bc884c5588ad.tabs.0.elements.0.class','null'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.fieldLayouts.4148225d-9e14-42d3-b0d7-bc884c5588ad.tabs.0.elements.0.disabled','false'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.fieldLayouts.4148225d-9e14-42d3-b0d7-bc884c5588ad.tabs.0.elements.0.elementCondition','null'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.fieldLayouts.4148225d-9e14-42d3-b0d7-bc884c5588ad.tabs.0.elements.0.id','null'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.fieldLayouts.4148225d-9e14-42d3-b0d7-bc884c5588ad.tabs.0.elements.0.instructions','null'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.fieldLayouts.4148225d-9e14-42d3-b0d7-bc884c5588ad.tabs.0.elements.0.label','null'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.fieldLayouts.4148225d-9e14-42d3-b0d7-bc884c5588ad.tabs.0.elements.0.max','null'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.fieldLayouts.4148225d-9e14-42d3-b0d7-bc884c5588ad.tabs.0.elements.0.min','null'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.fieldLayouts.4148225d-9e14-42d3-b0d7-bc884c5588ad.tabs.0.elements.0.name','null'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.fieldLayouts.4148225d-9e14-42d3-b0d7-bc884c5588ad.tabs.0.elements.0.orientation','null'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.fieldLayouts.4148225d-9e14-42d3-b0d7-bc884c5588ad.tabs.0.elements.0.placeholder','null'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.fieldLayouts.4148225d-9e14-42d3-b0d7-bc884c5588ad.tabs.0.elements.0.readonly','false'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.fieldLayouts.4148225d-9e14-42d3-b0d7-bc884c5588ad.tabs.0.elements.0.requirable','false'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.fieldLayouts.4148225d-9e14-42d3-b0d7-bc884c5588ad.tabs.0.elements.0.size','null'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.fieldLayouts.4148225d-9e14-42d3-b0d7-bc884c5588ad.tabs.0.elements.0.step','null'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.fieldLayouts.4148225d-9e14-42d3-b0d7-bc884c5588ad.tabs.0.elements.0.tip','null'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.fieldLayouts.4148225d-9e14-42d3-b0d7-bc884c5588ad.tabs.0.elements.0.title','null'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.fieldLayouts.4148225d-9e14-42d3-b0d7-bc884c5588ad.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.fieldLayouts.4148225d-9e14-42d3-b0d7-bc884c5588ad.tabs.0.elements.0.uid','\"fb387136-40af-43f1-a568-fd1c55739db4\"'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.fieldLayouts.4148225d-9e14-42d3-b0d7-bc884c5588ad.tabs.0.elements.0.userCondition','null'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.fieldLayouts.4148225d-9e14-42d3-b0d7-bc884c5588ad.tabs.0.elements.0.warning','null'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.fieldLayouts.4148225d-9e14-42d3-b0d7-bc884c5588ad.tabs.0.elements.0.width','100'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.fieldLayouts.4148225d-9e14-42d3-b0d7-bc884c5588ad.tabs.0.elements.1.elementCondition','null'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.fieldLayouts.4148225d-9e14-42d3-b0d7-bc884c5588ad.tabs.0.elements.1.fieldUid','\"6af92e13-3817-4619-a65c-3522d4d1fc67\"'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.fieldLayouts.4148225d-9e14-42d3-b0d7-bc884c5588ad.tabs.0.elements.1.instructions','null'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.fieldLayouts.4148225d-9e14-42d3-b0d7-bc884c5588ad.tabs.0.elements.1.label','null'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.fieldLayouts.4148225d-9e14-42d3-b0d7-bc884c5588ad.tabs.0.elements.1.required','false'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.fieldLayouts.4148225d-9e14-42d3-b0d7-bc884c5588ad.tabs.0.elements.1.tip','null'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.fieldLayouts.4148225d-9e14-42d3-b0d7-bc884c5588ad.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.fieldLayouts.4148225d-9e14-42d3-b0d7-bc884c5588ad.tabs.0.elements.1.uid','\"8829e190-ee8b-4b81-8cfe-7af420e60bf1\"'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.fieldLayouts.4148225d-9e14-42d3-b0d7-bc884c5588ad.tabs.0.elements.1.userCondition','null'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.fieldLayouts.4148225d-9e14-42d3-b0d7-bc884c5588ad.tabs.0.elements.1.warning','null'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.fieldLayouts.4148225d-9e14-42d3-b0d7-bc884c5588ad.tabs.0.elements.1.width','100'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.fieldLayouts.4148225d-9e14-42d3-b0d7-bc884c5588ad.tabs.0.elements.2.elementCondition','null'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.fieldLayouts.4148225d-9e14-42d3-b0d7-bc884c5588ad.tabs.0.elements.2.fieldUid','\"d55f6463-5f76-4782-9af7-78a88483b0f0\"'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.fieldLayouts.4148225d-9e14-42d3-b0d7-bc884c5588ad.tabs.0.elements.2.instructions','null'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.fieldLayouts.4148225d-9e14-42d3-b0d7-bc884c5588ad.tabs.0.elements.2.label','null'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.fieldLayouts.4148225d-9e14-42d3-b0d7-bc884c5588ad.tabs.0.elements.2.required','false'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.fieldLayouts.4148225d-9e14-42d3-b0d7-bc884c5588ad.tabs.0.elements.2.tip','null'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.fieldLayouts.4148225d-9e14-42d3-b0d7-bc884c5588ad.tabs.0.elements.2.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.fieldLayouts.4148225d-9e14-42d3-b0d7-bc884c5588ad.tabs.0.elements.2.uid','\"ac2eb4f8-a226-4d03-8cdf-f6b491b09170\"'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.fieldLayouts.4148225d-9e14-42d3-b0d7-bc884c5588ad.tabs.0.elements.2.userCondition','null'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.fieldLayouts.4148225d-9e14-42d3-b0d7-bc884c5588ad.tabs.0.elements.2.warning','null'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.fieldLayouts.4148225d-9e14-42d3-b0d7-bc884c5588ad.tabs.0.elements.2.width','100'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.fieldLayouts.4148225d-9e14-42d3-b0d7-bc884c5588ad.tabs.0.elements.3.elementCondition','null'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.fieldLayouts.4148225d-9e14-42d3-b0d7-bc884c5588ad.tabs.0.elements.3.fieldUid','\"cc8877ab-7d30-4e23-b01f-3a8318288fc0\"'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.fieldLayouts.4148225d-9e14-42d3-b0d7-bc884c5588ad.tabs.0.elements.3.instructions','null'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.fieldLayouts.4148225d-9e14-42d3-b0d7-bc884c5588ad.tabs.0.elements.3.label','null'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.fieldLayouts.4148225d-9e14-42d3-b0d7-bc884c5588ad.tabs.0.elements.3.required','false'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.fieldLayouts.4148225d-9e14-42d3-b0d7-bc884c5588ad.tabs.0.elements.3.tip','null'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.fieldLayouts.4148225d-9e14-42d3-b0d7-bc884c5588ad.tabs.0.elements.3.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.fieldLayouts.4148225d-9e14-42d3-b0d7-bc884c5588ad.tabs.0.elements.3.uid','\"1d295689-0fd3-4fcd-8d1c-590f349ae258\"'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.fieldLayouts.4148225d-9e14-42d3-b0d7-bc884c5588ad.tabs.0.elements.3.userCondition','null'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.fieldLayouts.4148225d-9e14-42d3-b0d7-bc884c5588ad.tabs.0.elements.3.warning','null'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.fieldLayouts.4148225d-9e14-42d3-b0d7-bc884c5588ad.tabs.0.elements.3.width','100'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.fieldLayouts.4148225d-9e14-42d3-b0d7-bc884c5588ad.tabs.0.elements.4.elementCondition','null'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.fieldLayouts.4148225d-9e14-42d3-b0d7-bc884c5588ad.tabs.0.elements.4.fieldUid','\"f83d583c-7b6a-4dc7-8d00-7bdd51363137\"'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.fieldLayouts.4148225d-9e14-42d3-b0d7-bc884c5588ad.tabs.0.elements.4.instructions','null'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.fieldLayouts.4148225d-9e14-42d3-b0d7-bc884c5588ad.tabs.0.elements.4.label','null'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.fieldLayouts.4148225d-9e14-42d3-b0d7-bc884c5588ad.tabs.0.elements.4.required','false'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.fieldLayouts.4148225d-9e14-42d3-b0d7-bc884c5588ad.tabs.0.elements.4.tip','null'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.fieldLayouts.4148225d-9e14-42d3-b0d7-bc884c5588ad.tabs.0.elements.4.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.fieldLayouts.4148225d-9e14-42d3-b0d7-bc884c5588ad.tabs.0.elements.4.uid','\"4f8ad358-8b71-4b44-ba41-7dab38f6deb3\"'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.fieldLayouts.4148225d-9e14-42d3-b0d7-bc884c5588ad.tabs.0.elements.4.userCondition','null'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.fieldLayouts.4148225d-9e14-42d3-b0d7-bc884c5588ad.tabs.0.elements.4.warning','null'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.fieldLayouts.4148225d-9e14-42d3-b0d7-bc884c5588ad.tabs.0.elements.4.width','100'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.fieldLayouts.4148225d-9e14-42d3-b0d7-bc884c5588ad.tabs.0.elements.5.elementCondition','null'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.fieldLayouts.4148225d-9e14-42d3-b0d7-bc884c5588ad.tabs.0.elements.5.fieldUid','\"f9060c98-f56d-4cca-b4d5-de78d810e775\"'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.fieldLayouts.4148225d-9e14-42d3-b0d7-bc884c5588ad.tabs.0.elements.5.instructions','null'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.fieldLayouts.4148225d-9e14-42d3-b0d7-bc884c5588ad.tabs.0.elements.5.label','null'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.fieldLayouts.4148225d-9e14-42d3-b0d7-bc884c5588ad.tabs.0.elements.5.required','false'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.fieldLayouts.4148225d-9e14-42d3-b0d7-bc884c5588ad.tabs.0.elements.5.tip','null'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.fieldLayouts.4148225d-9e14-42d3-b0d7-bc884c5588ad.tabs.0.elements.5.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.fieldLayouts.4148225d-9e14-42d3-b0d7-bc884c5588ad.tabs.0.elements.5.uid','\"e12f3be3-1f13-4b19-8f67-2b7a49724be9\"'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.fieldLayouts.4148225d-9e14-42d3-b0d7-bc884c5588ad.tabs.0.elements.5.userCondition','null'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.fieldLayouts.4148225d-9e14-42d3-b0d7-bc884c5588ad.tabs.0.elements.5.warning','null'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.fieldLayouts.4148225d-9e14-42d3-b0d7-bc884c5588ad.tabs.0.elements.5.width','100'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.fieldLayouts.4148225d-9e14-42d3-b0d7-bc884c5588ad.tabs.0.name','\"Content\"'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.fieldLayouts.4148225d-9e14-42d3-b0d7-bc884c5588ad.tabs.0.uid','\"85c9d681-0307-450c-b273-15a2fc771276\"'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.fieldLayouts.4148225d-9e14-42d3-b0d7-bc884c5588ad.tabs.0.userCondition','null'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.handle','\"default\"'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.hasTitleField','true'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.name','\"Default\"'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.section','\"cb843ec5-3aaa-44ea-94cf-f99f4023642f\"'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.showStatusField','true'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.slugTranslationKeyFormat','null'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.slugTranslationMethod','\"site\"'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.sortOrder','1'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.titleFormat','null'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.titleTranslationKeyFormat','null'),('entryTypes.df793da0-9723-422b-a370-2e9c303381d0.titleTranslationMethod','\"site\"'),('fieldGroups.6107f7f5-b967-4eff-900d-72acac322b28.name','\"Users\"'),('fieldGroups.70c63edf-2fc7-463d-bef9-779cc51b7d25.name','\"Common\"'),('fieldGroups.cfe8b169-e903-42f6-92ac-f4af56aa1ab8.name','\"Venues\"'),('fieldGroups.d4460fc8-b976-4652-92d2-7d820d7502ef.name','\"Statistics\"'),('fields.0084065a-21dc-4833-9064-d97f4e1c9bca.columnSuffix','\"xsmoaddn\"'),('fields.0084065a-21dc-4833-9064-d97f4e1c9bca.contentColumnType','\"time\"'),('fields.0084065a-21dc-4833-9064-d97f4e1c9bca.fieldGroup','\"cfe8b169-e903-42f6-92ac-f4af56aa1ab8\"'),('fields.0084065a-21dc-4833-9064-d97f4e1c9bca.handle','\"venueOpeningTime\"'),('fields.0084065a-21dc-4833-9064-d97f4e1c9bca.instructions','null'),('fields.0084065a-21dc-4833-9064-d97f4e1c9bca.name','\"Venue Opening Time\"'),('fields.0084065a-21dc-4833-9064-d97f4e1c9bca.searchable','false'),('fields.0084065a-21dc-4833-9064-d97f4e1c9bca.settings.max','null'),('fields.0084065a-21dc-4833-9064-d97f4e1c9bca.settings.min','null'),('fields.0084065a-21dc-4833-9064-d97f4e1c9bca.settings.minuteIncrement','30'),('fields.0084065a-21dc-4833-9064-d97f4e1c9bca.translationKeyFormat','null'),('fields.0084065a-21dc-4833-9064-d97f4e1c9bca.translationMethod','\"none\"'),('fields.0084065a-21dc-4833-9064-d97f4e1c9bca.type','\"craft\\\\fields\\\\Time\"'),('fields.312b4f06-f575-487d-8777-e646ddb19ba6.columnSuffix','\"odumgdut\"'),('fields.312b4f06-f575-487d-8777-e646ddb19ba6.contentColumnType','\"decimal(12,2)\"'),('fields.312b4f06-f575-487d-8777-e646ddb19ba6.fieldGroup','\"cfe8b169-e903-42f6-92ac-f4af56aa1ab8\"'),('fields.312b4f06-f575-487d-8777-e646ddb19ba6.handle','\"venueTicketPrice\"'),('fields.312b4f06-f575-487d-8777-e646ddb19ba6.instructions','null'),('fields.312b4f06-f575-487d-8777-e646ddb19ba6.name','\"Venue Ticket Price\"'),('fields.312b4f06-f575-487d-8777-e646ddb19ba6.searchable','false'),('fields.312b4f06-f575-487d-8777-e646ddb19ba6.settings.decimals','2'),('fields.312b4f06-f575-487d-8777-e646ddb19ba6.settings.defaultValue','null'),('fields.312b4f06-f575-487d-8777-e646ddb19ba6.settings.max','null'),('fields.312b4f06-f575-487d-8777-e646ddb19ba6.settings.min','0'),('fields.312b4f06-f575-487d-8777-e646ddb19ba6.settings.prefix','null'),('fields.312b4f06-f575-487d-8777-e646ddb19ba6.settings.previewCurrency','null'),('fields.312b4f06-f575-487d-8777-e646ddb19ba6.settings.previewFormat','\"decimal\"'),('fields.312b4f06-f575-487d-8777-e646ddb19ba6.settings.size','null'),('fields.312b4f06-f575-487d-8777-e646ddb19ba6.settings.suffix','null'),('fields.312b4f06-f575-487d-8777-e646ddb19ba6.translationKeyFormat','null'),('fields.312b4f06-f575-487d-8777-e646ddb19ba6.translationMethod','\"none\"'),('fields.312b4f06-f575-487d-8777-e646ddb19ba6.type','\"craft\\\\fields\\\\Number\"'),('fields.349ff4ce-c3d6-401e-a73d-26ef36146dba.columnSuffix','\"tcownruz\"'),('fields.349ff4ce-c3d6-401e-a73d-26ef36146dba.contentColumnType','\"text\"'),('fields.349ff4ce-c3d6-401e-a73d-26ef36146dba.fieldGroup','\"6107f7f5-b967-4eff-900d-72acac322b28\"'),('fields.349ff4ce-c3d6-401e-a73d-26ef36146dba.handle','\"companyName\"'),('fields.349ff4ce-c3d6-401e-a73d-26ef36146dba.instructions','null'),('fields.349ff4ce-c3d6-401e-a73d-26ef36146dba.name','\"Company Name\"'),('fields.349ff4ce-c3d6-401e-a73d-26ef36146dba.searchable','false'),('fields.349ff4ce-c3d6-401e-a73d-26ef36146dba.settings.byteLimit','null'),('fields.349ff4ce-c3d6-401e-a73d-26ef36146dba.settings.charLimit','null'),('fields.349ff4ce-c3d6-401e-a73d-26ef36146dba.settings.code','false'),('fields.349ff4ce-c3d6-401e-a73d-26ef36146dba.settings.columnType','null'),('fields.349ff4ce-c3d6-401e-a73d-26ef36146dba.settings.initialRows','4'),('fields.349ff4ce-c3d6-401e-a73d-26ef36146dba.settings.multiline','false'),('fields.349ff4ce-c3d6-401e-a73d-26ef36146dba.settings.placeholder','null'),('fields.349ff4ce-c3d6-401e-a73d-26ef36146dba.settings.uiMode','\"normal\"'),('fields.349ff4ce-c3d6-401e-a73d-26ef36146dba.translationKeyFormat','null'),('fields.349ff4ce-c3d6-401e-a73d-26ef36146dba.translationMethod','\"none\"'),('fields.349ff4ce-c3d6-401e-a73d-26ef36146dba.type','\"craft\\\\fields\\\\PlainText\"'),('fields.6af92e13-3817-4619-a65c-3522d4d1fc67.columnSuffix','\"knhntkbg\"'),('fields.6af92e13-3817-4619-a65c-3522d4d1fc67.contentColumnType','\"string\"'),('fields.6af92e13-3817-4619-a65c-3522d4d1fc67.fieldGroup','\"d4460fc8-b976-4652-92d2-7d820d7502ef\"'),('fields.6af92e13-3817-4619-a65c-3522d4d1fc67.handle','\"venue\"'),('fields.6af92e13-3817-4619-a65c-3522d4d1fc67.instructions','null'),('fields.6af92e13-3817-4619-a65c-3522d4d1fc67.name','\"Venue\"'),('fields.6af92e13-3817-4619-a65c-3522d4d1fc67.searchable','false'),('fields.6af92e13-3817-4619-a65c-3522d4d1fc67.settings.allowSelfRelations','false'),('fields.6af92e13-3817-4619-a65c-3522d4d1fc67.settings.branchLimit','null'),('fields.6af92e13-3817-4619-a65c-3522d4d1fc67.settings.localizeRelations','false'),('fields.6af92e13-3817-4619-a65c-3522d4d1fc67.settings.maintainHierarchy','false'),('fields.6af92e13-3817-4619-a65c-3522d4d1fc67.settings.maxRelations','1'),('fields.6af92e13-3817-4619-a65c-3522d4d1fc67.settings.minRelations','null'),('fields.6af92e13-3817-4619-a65c-3522d4d1fc67.settings.selectionCondition.__assoc__.0.0','\"elementType\"'),('fields.6af92e13-3817-4619-a65c-3522d4d1fc67.settings.selectionCondition.__assoc__.0.1','\"craft\\\\elements\\\\Entry\"'),('fields.6af92e13-3817-4619-a65c-3522d4d1fc67.settings.selectionCondition.__assoc__.1.0','\"fieldContext\"'),('fields.6af92e13-3817-4619-a65c-3522d4d1fc67.settings.selectionCondition.__assoc__.1.1','\"global\"'),('fields.6af92e13-3817-4619-a65c-3522d4d1fc67.settings.selectionCondition.__assoc__.2.0','\"class\"'),('fields.6af92e13-3817-4619-a65c-3522d4d1fc67.settings.selectionCondition.__assoc__.2.1','\"craft\\\\elements\\\\conditions\\\\entries\\\\EntryCondition\"'),('fields.6af92e13-3817-4619-a65c-3522d4d1fc67.settings.selectionLabel','null'),('fields.6af92e13-3817-4619-a65c-3522d4d1fc67.settings.showSiteMenu','true'),('fields.6af92e13-3817-4619-a65c-3522d4d1fc67.settings.sources.0','\"section:fa1a9449-1cdb-4185-8017-6d6baea8371b\"'),('fields.6af92e13-3817-4619-a65c-3522d4d1fc67.settings.targetSiteId','null'),('fields.6af92e13-3817-4619-a65c-3522d4d1fc67.settings.validateRelatedElements','false'),('fields.6af92e13-3817-4619-a65c-3522d4d1fc67.settings.viewMode','null'),('fields.6af92e13-3817-4619-a65c-3522d4d1fc67.translationKeyFormat','null'),('fields.6af92e13-3817-4619-a65c-3522d4d1fc67.translationMethod','\"site\"'),('fields.6af92e13-3817-4619-a65c-3522d4d1fc67.type','\"craft\\\\fields\\\\Entries\"'),('fields.73ccaa0c-844d-46d0-8b58-e33c1baaa8f2.columnSuffix','\"eowtagfq\"'),('fields.73ccaa0c-844d-46d0-8b58-e33c1baaa8f2.contentColumnType','\"text\"'),('fields.73ccaa0c-844d-46d0-8b58-e33c1baaa8f2.fieldGroup','\"cfe8b169-e903-42f6-92ac-f4af56aa1ab8\"'),('fields.73ccaa0c-844d-46d0-8b58-e33c1baaa8f2.handle','\"venueCurrencyType\"'),('fields.73ccaa0c-844d-46d0-8b58-e33c1baaa8f2.instructions','null'),('fields.73ccaa0c-844d-46d0-8b58-e33c1baaa8f2.name','\"Venue Currency Type\"'),('fields.73ccaa0c-844d-46d0-8b58-e33c1baaa8f2.searchable','false'),('fields.73ccaa0c-844d-46d0-8b58-e33c1baaa8f2.settings.byteLimit','null'),('fields.73ccaa0c-844d-46d0-8b58-e33c1baaa8f2.settings.charLimit','null'),('fields.73ccaa0c-844d-46d0-8b58-e33c1baaa8f2.settings.code','false'),('fields.73ccaa0c-844d-46d0-8b58-e33c1baaa8f2.settings.columnType','null'),('fields.73ccaa0c-844d-46d0-8b58-e33c1baaa8f2.settings.initialRows','4'),('fields.73ccaa0c-844d-46d0-8b58-e33c1baaa8f2.settings.multiline','false'),('fields.73ccaa0c-844d-46d0-8b58-e33c1baaa8f2.settings.placeholder','null'),('fields.73ccaa0c-844d-46d0-8b58-e33c1baaa8f2.settings.uiMode','\"normal\"'),('fields.73ccaa0c-844d-46d0-8b58-e33c1baaa8f2.translationKeyFormat','null'),('fields.73ccaa0c-844d-46d0-8b58-e33c1baaa8f2.translationMethod','\"none\"'),('fields.73ccaa0c-844d-46d0-8b58-e33c1baaa8f2.type','\"craft\\\\fields\\\\PlainText\"'),('fields.b748cdca-ffaa-490f-98b0-5fa1c1e70095.columnSuffix','null'),('fields.b748cdca-ffaa-490f-98b0-5fa1c1e70095.contentColumnType','\"string\"'),('fields.b748cdca-ffaa-490f-98b0-5fa1c1e70095.fieldGroup','\"6107f7f5-b967-4eff-900d-72acac322b28\"'),('fields.b748cdca-ffaa-490f-98b0-5fa1c1e70095.handle','\"companyLogo\"'),('fields.b748cdca-ffaa-490f-98b0-5fa1c1e70095.instructions','null'),('fields.b748cdca-ffaa-490f-98b0-5fa1c1e70095.name','\"Company Logo\"'),('fields.b748cdca-ffaa-490f-98b0-5fa1c1e70095.searchable','false'),('fields.b748cdca-ffaa-490f-98b0-5fa1c1e70095.settings.allowedKinds','null'),('fields.b748cdca-ffaa-490f-98b0-5fa1c1e70095.settings.allowSelfRelations','false'),('fields.b748cdca-ffaa-490f-98b0-5fa1c1e70095.settings.allowSubfolders','false'),('fields.b748cdca-ffaa-490f-98b0-5fa1c1e70095.settings.allowUploads','true'),('fields.b748cdca-ffaa-490f-98b0-5fa1c1e70095.settings.branchLimit','null'),('fields.b748cdca-ffaa-490f-98b0-5fa1c1e70095.settings.defaultUploadLocationSource','null'),('fields.b748cdca-ffaa-490f-98b0-5fa1c1e70095.settings.defaultUploadLocationSubpath','null'),('fields.b748cdca-ffaa-490f-98b0-5fa1c1e70095.settings.localizeRelations','false'),('fields.b748cdca-ffaa-490f-98b0-5fa1c1e70095.settings.maintainHierarchy','false'),('fields.b748cdca-ffaa-490f-98b0-5fa1c1e70095.settings.maxRelations','null'),('fields.b748cdca-ffaa-490f-98b0-5fa1c1e70095.settings.minRelations','null'),('fields.b748cdca-ffaa-490f-98b0-5fa1c1e70095.settings.previewMode','\"full\"'),('fields.b748cdca-ffaa-490f-98b0-5fa1c1e70095.settings.restrictedDefaultUploadSubpath','null'),('fields.b748cdca-ffaa-490f-98b0-5fa1c1e70095.settings.restrictedLocationSource','null'),('fields.b748cdca-ffaa-490f-98b0-5fa1c1e70095.settings.restrictedLocationSubpath','null'),('fields.b748cdca-ffaa-490f-98b0-5fa1c1e70095.settings.restrictFiles','false'),('fields.b748cdca-ffaa-490f-98b0-5fa1c1e70095.settings.restrictLocation','false'),('fields.b748cdca-ffaa-490f-98b0-5fa1c1e70095.settings.selectionCondition.__assoc__.0.0','\"elementType\"'),('fields.b748cdca-ffaa-490f-98b0-5fa1c1e70095.settings.selectionCondition.__assoc__.0.1','\"craft\\\\elements\\\\Asset\"'),('fields.b748cdca-ffaa-490f-98b0-5fa1c1e70095.settings.selectionCondition.__assoc__.1.0','\"fieldContext\"'),('fields.b748cdca-ffaa-490f-98b0-5fa1c1e70095.settings.selectionCondition.__assoc__.1.1','\"global\"'),('fields.b748cdca-ffaa-490f-98b0-5fa1c1e70095.settings.selectionCondition.__assoc__.2.0','\"class\"'),('fields.b748cdca-ffaa-490f-98b0-5fa1c1e70095.settings.selectionCondition.__assoc__.2.1','\"craft\\\\elements\\\\conditions\\\\assets\\\\AssetCondition\"'),('fields.b748cdca-ffaa-490f-98b0-5fa1c1e70095.settings.selectionLabel','null'),('fields.b748cdca-ffaa-490f-98b0-5fa1c1e70095.settings.showSiteMenu','false'),('fields.b748cdca-ffaa-490f-98b0-5fa1c1e70095.settings.showUnpermittedFiles','false'),('fields.b748cdca-ffaa-490f-98b0-5fa1c1e70095.settings.showUnpermittedVolumes','false'),('fields.b748cdca-ffaa-490f-98b0-5fa1c1e70095.settings.sources','\"*\"'),('fields.b748cdca-ffaa-490f-98b0-5fa1c1e70095.settings.targetSiteId','null'),('fields.b748cdca-ffaa-490f-98b0-5fa1c1e70095.settings.validateRelatedElements','false'),('fields.b748cdca-ffaa-490f-98b0-5fa1c1e70095.settings.viewMode','\"list\"'),('fields.b748cdca-ffaa-490f-98b0-5fa1c1e70095.translationKeyFormat','null'),('fields.b748cdca-ffaa-490f-98b0-5fa1c1e70095.translationMethod','\"site\"'),('fields.b748cdca-ffaa-490f-98b0-5fa1c1e70095.type','\"craft\\\\fields\\\\Assets\"'),('fields.cc7c385a-fa47-48b0-8edb-006e60e4b8f1.columnSuffix','\"hjwvgxqr\"'),('fields.cc7c385a-fa47-48b0-8edb-006e60e4b8f1.contentColumnType','\"time\"'),('fields.cc7c385a-fa47-48b0-8edb-006e60e4b8f1.fieldGroup','\"cfe8b169-e903-42f6-92ac-f4af56aa1ab8\"'),('fields.cc7c385a-fa47-48b0-8edb-006e60e4b8f1.handle','\"venueClosingTime\"'),('fields.cc7c385a-fa47-48b0-8edb-006e60e4b8f1.instructions','null'),('fields.cc7c385a-fa47-48b0-8edb-006e60e4b8f1.name','\"Venue Closing Time\"'),('fields.cc7c385a-fa47-48b0-8edb-006e60e4b8f1.searchable','false'),('fields.cc7c385a-fa47-48b0-8edb-006e60e4b8f1.settings.max','null'),('fields.cc7c385a-fa47-48b0-8edb-006e60e4b8f1.settings.min','null'),('fields.cc7c385a-fa47-48b0-8edb-006e60e4b8f1.settings.minuteIncrement','30'),('fields.cc7c385a-fa47-48b0-8edb-006e60e4b8f1.translationKeyFormat','null'),('fields.cc7c385a-fa47-48b0-8edb-006e60e4b8f1.translationMethod','\"none\"'),('fields.cc7c385a-fa47-48b0-8edb-006e60e4b8f1.type','\"craft\\\\fields\\\\Time\"'),('fields.cc8877ab-7d30-4e23-b01f-3a8318288fc0.columnSuffix','\"zmwphfkw\"'),('fields.cc8877ab-7d30-4e23-b01f-3a8318288fc0.contentColumnType','\"string\"'),('fields.cc8877ab-7d30-4e23-b01f-3a8318288fc0.fieldGroup','\"d4460fc8-b976-4652-92d2-7d820d7502ef\"'),('fields.cc8877ab-7d30-4e23-b01f-3a8318288fc0.handle','\"movie\"'),('fields.cc8877ab-7d30-4e23-b01f-3a8318288fc0.instructions','null'),('fields.cc8877ab-7d30-4e23-b01f-3a8318288fc0.name','\"Movie Name\"'),('fields.cc8877ab-7d30-4e23-b01f-3a8318288fc0.searchable','false'),('fields.cc8877ab-7d30-4e23-b01f-3a8318288fc0.settings.allowSelfRelations','false'),('fields.cc8877ab-7d30-4e23-b01f-3a8318288fc0.settings.branchLimit','null'),('fields.cc8877ab-7d30-4e23-b01f-3a8318288fc0.settings.localizeRelations','false'),('fields.cc8877ab-7d30-4e23-b01f-3a8318288fc0.settings.maintainHierarchy','false'),('fields.cc8877ab-7d30-4e23-b01f-3a8318288fc0.settings.maxRelations','1'),('fields.cc8877ab-7d30-4e23-b01f-3a8318288fc0.settings.minRelations','1'),('fields.cc8877ab-7d30-4e23-b01f-3a8318288fc0.settings.selectionCondition.__assoc__.0.0','\"elementType\"'),('fields.cc8877ab-7d30-4e23-b01f-3a8318288fc0.settings.selectionCondition.__assoc__.0.1','\"craft\\\\elements\\\\Entry\"'),('fields.cc8877ab-7d30-4e23-b01f-3a8318288fc0.settings.selectionCondition.__assoc__.1.0','\"fieldContext\"'),('fields.cc8877ab-7d30-4e23-b01f-3a8318288fc0.settings.selectionCondition.__assoc__.1.1','\"global\"'),('fields.cc8877ab-7d30-4e23-b01f-3a8318288fc0.settings.selectionCondition.__assoc__.2.0','\"class\"'),('fields.cc8877ab-7d30-4e23-b01f-3a8318288fc0.settings.selectionCondition.__assoc__.2.1','\"craft\\\\elements\\\\conditions\\\\entries\\\\EntryCondition\"'),('fields.cc8877ab-7d30-4e23-b01f-3a8318288fc0.settings.selectionLabel','null'),('fields.cc8877ab-7d30-4e23-b01f-3a8318288fc0.settings.showSiteMenu','true'),('fields.cc8877ab-7d30-4e23-b01f-3a8318288fc0.settings.sources.0','\"section:b3e8c798-1f09-4ca2-ac30-695d0273d094\"'),('fields.cc8877ab-7d30-4e23-b01f-3a8318288fc0.settings.targetSiteId','null'),('fields.cc8877ab-7d30-4e23-b01f-3a8318288fc0.settings.validateRelatedElements','false'),('fields.cc8877ab-7d30-4e23-b01f-3a8318288fc0.settings.viewMode','null'),('fields.cc8877ab-7d30-4e23-b01f-3a8318288fc0.translationKeyFormat','null'),('fields.cc8877ab-7d30-4e23-b01f-3a8318288fc0.translationMethod','\"site\"'),('fields.cc8877ab-7d30-4e23-b01f-3a8318288fc0.type','\"craft\\\\fields\\\\Entries\"'),('fields.d55f6463-5f76-4782-9af7-78a88483b0f0.columnSuffix','null'),('fields.d55f6463-5f76-4782-9af7-78a88483b0f0.contentColumnType','\"string\"'),('fields.d55f6463-5f76-4782-9af7-78a88483b0f0.fieldGroup','\"d4460fc8-b976-4652-92d2-7d820d7502ef\"'),('fields.d55f6463-5f76-4782-9af7-78a88483b0f0.handle','\"headset\"'),('fields.d55f6463-5f76-4782-9af7-78a88483b0f0.instructions','null'),('fields.d55f6463-5f76-4782-9af7-78a88483b0f0.name','\"Headset\"'),('fields.d55f6463-5f76-4782-9af7-78a88483b0f0.searchable','false'),('fields.d55f6463-5f76-4782-9af7-78a88483b0f0.settings.allowSelfRelations','false'),('fields.d55f6463-5f76-4782-9af7-78a88483b0f0.settings.branchLimit','null'),('fields.d55f6463-5f76-4782-9af7-78a88483b0f0.settings.localizeRelations','false'),('fields.d55f6463-5f76-4782-9af7-78a88483b0f0.settings.maintainHierarchy','false'),('fields.d55f6463-5f76-4782-9af7-78a88483b0f0.settings.maxRelations','1'),('fields.d55f6463-5f76-4782-9af7-78a88483b0f0.settings.minRelations','1'),('fields.d55f6463-5f76-4782-9af7-78a88483b0f0.settings.selectionCondition.__assoc__.0.0','\"elementType\"'),('fields.d55f6463-5f76-4782-9af7-78a88483b0f0.settings.selectionCondition.__assoc__.0.1','\"craft\\\\elements\\\\Entry\"'),('fields.d55f6463-5f76-4782-9af7-78a88483b0f0.settings.selectionCondition.__assoc__.1.0','\"fieldContext\"'),('fields.d55f6463-5f76-4782-9af7-78a88483b0f0.settings.selectionCondition.__assoc__.1.1','\"global\"'),('fields.d55f6463-5f76-4782-9af7-78a88483b0f0.settings.selectionCondition.__assoc__.2.0','\"class\"'),('fields.d55f6463-5f76-4782-9af7-78a88483b0f0.settings.selectionCondition.__assoc__.2.1','\"craft\\\\elements\\\\conditions\\\\entries\\\\EntryCondition\"'),('fields.d55f6463-5f76-4782-9af7-78a88483b0f0.settings.selectionLabel','null'),('fields.d55f6463-5f76-4782-9af7-78a88483b0f0.settings.showSiteMenu','false'),('fields.d55f6463-5f76-4782-9af7-78a88483b0f0.settings.sources.0','\"section:38875b9f-df2c-41e6-a1a2-e9d4ed370735\"'),('fields.d55f6463-5f76-4782-9af7-78a88483b0f0.settings.targetSiteId','null'),('fields.d55f6463-5f76-4782-9af7-78a88483b0f0.settings.validateRelatedElements','false'),('fields.d55f6463-5f76-4782-9af7-78a88483b0f0.settings.viewMode','null'),('fields.d55f6463-5f76-4782-9af7-78a88483b0f0.translationKeyFormat','null'),('fields.d55f6463-5f76-4782-9af7-78a88483b0f0.translationMethod','\"site\"'),('fields.d55f6463-5f76-4782-9af7-78a88483b0f0.type','\"craft\\\\fields\\\\Entries\"'),('fields.f83d583c-7b6a-4dc7-8d00-7bdd51363137.columnSuffix','\"akixlfui\"'),('fields.f83d583c-7b6a-4dc7-8d00-7bdd51363137.contentColumnType','\"text\"'),('fields.f83d583c-7b6a-4dc7-8d00-7bdd51363137.fieldGroup','\"d4460fc8-b976-4652-92d2-7d820d7502ef\"'),('fields.f83d583c-7b6a-4dc7-8d00-7bdd51363137.handle','\"visitLanguage\"'),('fields.f83d583c-7b6a-4dc7-8d00-7bdd51363137.instructions','null'),('fields.f83d583c-7b6a-4dc7-8d00-7bdd51363137.name','\"Visit Language\"'),('fields.f83d583c-7b6a-4dc7-8d00-7bdd51363137.searchable','false'),('fields.f83d583c-7b6a-4dc7-8d00-7bdd51363137.settings.byteLimit','null'),('fields.f83d583c-7b6a-4dc7-8d00-7bdd51363137.settings.charLimit','null'),('fields.f83d583c-7b6a-4dc7-8d00-7bdd51363137.settings.code','false'),('fields.f83d583c-7b6a-4dc7-8d00-7bdd51363137.settings.columnType','null'),('fields.f83d583c-7b6a-4dc7-8d00-7bdd51363137.settings.initialRows','4'),('fields.f83d583c-7b6a-4dc7-8d00-7bdd51363137.settings.multiline','false'),('fields.f83d583c-7b6a-4dc7-8d00-7bdd51363137.settings.placeholder','null'),('fields.f83d583c-7b6a-4dc7-8d00-7bdd51363137.settings.uiMode','\"normal\"'),('fields.f83d583c-7b6a-4dc7-8d00-7bdd51363137.translationKeyFormat','null'),('fields.f83d583c-7b6a-4dc7-8d00-7bdd51363137.translationMethod','\"none\"'),('fields.f83d583c-7b6a-4dc7-8d00-7bdd51363137.type','\"craft\\\\fields\\\\PlainText\"'),('fields.f9060c98-f56d-4cca-b4d5-de78d810e775.columnSuffix','\"zzxlubly\"'),('fields.f9060c98-f56d-4cca-b4d5-de78d810e775.contentColumnType','\"datetime\"'),('fields.f9060c98-f56d-4cca-b4d5-de78d810e775.fieldGroup','\"d4460fc8-b976-4652-92d2-7d820d7502ef\"'),('fields.f9060c98-f56d-4cca-b4d5-de78d810e775.handle','\"visitStart\"'),('fields.f9060c98-f56d-4cca-b4d5-de78d810e775.instructions','null'),('fields.f9060c98-f56d-4cca-b4d5-de78d810e775.name','\"Visit Start\"'),('fields.f9060c98-f56d-4cca-b4d5-de78d810e775.searchable','false'),('fields.f9060c98-f56d-4cca-b4d5-de78d810e775.settings.max','null'),('fields.f9060c98-f56d-4cca-b4d5-de78d810e775.settings.min','null'),('fields.f9060c98-f56d-4cca-b4d5-de78d810e775.settings.minuteIncrement','30'),('fields.f9060c98-f56d-4cca-b4d5-de78d810e775.settings.showDate','true'),('fields.f9060c98-f56d-4cca-b4d5-de78d810e775.settings.showTime','true'),('fields.f9060c98-f56d-4cca-b4d5-de78d810e775.settings.showTimeZone','false'),('fields.f9060c98-f56d-4cca-b4d5-de78d810e775.translationKeyFormat','null'),('fields.f9060c98-f56d-4cca-b4d5-de78d810e775.translationMethod','\"none\"'),('fields.f9060c98-f56d-4cca-b4d5-de78d810e775.type','\"craft\\\\fields\\\\Date\"'),('graphql.publicToken.enabled','false'),('graphql.publicToken.expiryDate','null'),('graphql.schemas.4e940878-c1ee-4493-ba07-9714a5292f0b.isPublic','false'),('graphql.schemas.4e940878-c1ee-4493-ba07-9714a5292f0b.name','\"Stats Schema\"'),('graphql.schemas.4e940878-c1ee-4493-ba07-9714a5292f0b.scope.0','\"sites.f957802c-8f19-44d3-a30a-668d452862ac:read\"'),('graphql.schemas.4e940878-c1ee-4493-ba07-9714a5292f0b.scope.1','\"sections.cb843ec5-3aaa-44ea-94cf-f99f4023642f:read\"'),('graphql.schemas.4e940878-c1ee-4493-ba07-9714a5292f0b.scope.2','\"entrytypes.df793da0-9723-422b-a370-2e9c303381d0:read\"'),('graphql.schemas.4e940878-c1ee-4493-ba07-9714a5292f0b.scope.3','\"usergroups.32c28836-80b3-4da9-a427-6d42b223613b:read\"'),('graphql.schemas.4e940878-c1ee-4493-ba07-9714a5292f0b.scope.4','\"sections.cb843ec5-3aaa-44ea-94cf-f99f4023642f:edit\"'),('graphql.schemas.4e940878-c1ee-4493-ba07-9714a5292f0b.scope.5','\"entrytypes.df793da0-9723-422b-a370-2e9c303381d0:edit\"'),('graphql.schemas.4e940878-c1ee-4493-ba07-9714a5292f0b.scope.6','\"entrytypes.df793da0-9723-422b-a370-2e9c303381d0:create\"'),('graphql.schemas.4e940878-c1ee-4493-ba07-9714a5292f0b.scope.7','\"entrytypes.df793da0-9723-422b-a370-2e9c303381d0:save\"'),('graphql.schemas.4e940878-c1ee-4493-ba07-9714a5292f0b.scope.8','\"entrytypes.df793da0-9723-422b-a370-2e9c303381d0:delete\"'),('graphql.schemas.cca433bd-c86d-402b-9734-50cc40b8760d.isPublic','true'),('graphql.schemas.cca433bd-c86d-402b-9734-50cc40b8760d.name','\"Public Schema\"'),('graphql.schemas.cca433bd-c86d-402b-9734-50cc40b8760d.scope.0','\"sites.f957802c-8f19-44d3-a30a-668d452862ac:read\"'),('graphql.schemas.cca433bd-c86d-402b-9734-50cc40b8760d.scope.1','\"sections.cb843ec5-3aaa-44ea-94cf-f99f4023642f:read\"'),('graphql.schemas.cca433bd-c86d-402b-9734-50cc40b8760d.scope.2','\"entrytypes.df793da0-9723-422b-a370-2e9c303381d0:read\"'),('graphql.schemas.cca433bd-c86d-402b-9734-50cc40b8760d.scope.3','\"usergroups.everyone:read\"'),('graphql.schemas.cca433bd-c86d-402b-9734-50cc40b8760d.scope.4','\"sections.cb843ec5-3aaa-44ea-94cf-f99f4023642f:edit\"'),('graphql.schemas.cca433bd-c86d-402b-9734-50cc40b8760d.scope.5','\"entrytypes.df793da0-9723-422b-a370-2e9c303381d0:edit\"'),('graphql.schemas.cca433bd-c86d-402b-9734-50cc40b8760d.scope.6','\"entrytypes.df793da0-9723-422b-a370-2e9c303381d0:create\"'),('graphql.schemas.cca433bd-c86d-402b-9734-50cc40b8760d.scope.7','\"entrytypes.df793da0-9723-422b-a370-2e9c303381d0:save\"'),('meta.__names__.0084065a-21dc-4833-9064-d97f4e1c9bca','\"Venue Opening Time\"'),('meta.__names__.17e706db-ccd3-4eab-9d3a-e8e5fed9d10a','\"Default\"'),('meta.__names__.312b4f06-f575-487d-8777-e646ddb19ba6','\"Venue Ticket Price\"'),('meta.__names__.3226293d-1172-4808-9dfa-adbbb8120257','\"Emagine VR Analytics\"'),('meta.__names__.32c28836-80b3-4da9-a427-6d42b223613b','\"Clients\"'),('meta.__names__.349ff4ce-c3d6-401e-a73d-26ef36146dba','\"Company Name\"'),('meta.__names__.38875b9f-df2c-41e6-a1a2-e9d4ed370735','\"Headsets\"'),('meta.__names__.4e940878-c1ee-4493-ba07-9714a5292f0b','\"Stats Schema\"'),('meta.__names__.6107f7f5-b967-4eff-900d-72acac322b28','\"Users\"'),('meta.__names__.6af92e13-3817-4619-a65c-3522d4d1fc67','\"Venue\"'),('meta.__names__.6e395cf4-c9ab-4960-8c68-62b6bbcf4714','\"Default\"'),('meta.__names__.70c63edf-2fc7-463d-bef9-779cc51b7d25','\"Common\"'),('meta.__names__.73ccaa0c-844d-46d0-8b58-e33c1baaa8f2','\"Venue Currency Type\"'),('meta.__names__.a5255343-5341-4742-9fd7-dc1f26af404a','\"Admin\"'),('meta.__names__.a7b7e1ba-7fb3-4258-8a31-c45adeaf82b8','\"Default\"'),('meta.__names__.b3e8c798-1f09-4ca2-ac30-695d0273d094','\"Movies\"'),('meta.__names__.b748cdca-ffaa-490f-98b0-5fa1c1e70095','\"Company Logo\"'),('meta.__names__.cb843ec5-3aaa-44ea-94cf-f99f4023642f','\"Statistics\"'),('meta.__names__.cc7c385a-fa47-48b0-8edb-006e60e4b8f1','\"Venue Closing Time\"'),('meta.__names__.cc8877ab-7d30-4e23-b01f-3a8318288fc0','\"Movie Name\"'),('meta.__names__.cca433bd-c86d-402b-9734-50cc40b8760d','\"Public Schema\"'),('meta.__names__.cfe8b169-e903-42f6-92ac-f4af56aa1ab8','\"Venues\"'),('meta.__names__.d4460fc8-b976-4652-92d2-7d820d7502ef','\"Statistics\"'),('meta.__names__.d55f6463-5f76-4782-9af7-78a88483b0f0','\"Headset\"'),('meta.__names__.df793da0-9723-422b-a370-2e9c303381d0','\"Default\"'),('meta.__names__.f83d583c-7b6a-4dc7-8d00-7bdd51363137','\"Visit Language\"'),('meta.__names__.f9060c98-f56d-4cca-b4d5-de78d810e775','\"Visit Start\"'),('meta.__names__.f957802c-8f19-44d3-a30a-668d452862ac','\"Emagine VR Analytics\"'),('meta.__names__.fa1a9449-1cdb-4185-8017-6d6baea8371b','\"Venues\"'),('plugins._em-stats.edition','\"standard\"'),('plugins._em-stats.enabled','true'),('plugins._em-stats.schemaVersion','\"1.0.0\"'),('plugins._em-stats.settings.languageMap.__assoc__.0.0','\"en\"'),('plugins._em-stats.settings.languageMap.__assoc__.0.1.__assoc__.0.0','\"name\"'),('plugins._em-stats.settings.languageMap.__assoc__.0.1.__assoc__.0.1','\"English\"'),('plugins._em-stats.settings.languageMap.__assoc__.0.1.__assoc__.1.0','\"color\"'),('plugins._em-stats.settings.languageMap.__assoc__.0.1.__assoc__.1.1','\"bg-amber-500\"'),('plugins._em-stats.settings.languageMap.__assoc__.0.1.__assoc__.2.0','\"hex\"'),('plugins._em-stats.settings.languageMap.__assoc__.0.1.__assoc__.2.1','\"#f59e0b\"'),('plugins._venue.edition','\"standard\"'),('plugins._venue.enabled','false'),('plugins._venue.schemaVersion','\"1.0.0\"'),('sections.38875b9f-df2c-41e6-a1a2-e9d4ed370735.defaultPlacement','\"end\"'),('sections.38875b9f-df2c-41e6-a1a2-e9d4ed370735.enableVersioning','true'),('sections.38875b9f-df2c-41e6-a1a2-e9d4ed370735.handle','\"headsets\"'),('sections.38875b9f-df2c-41e6-a1a2-e9d4ed370735.name','\"Headsets\"'),('sections.38875b9f-df2c-41e6-a1a2-e9d4ed370735.previewTargets.0.__assoc__.0.0','\"label\"'),('sections.38875b9f-df2c-41e6-a1a2-e9d4ed370735.previewTargets.0.__assoc__.0.1','\"Primary entry page\"'),('sections.38875b9f-df2c-41e6-a1a2-e9d4ed370735.previewTargets.0.__assoc__.1.0','\"urlFormat\"'),('sections.38875b9f-df2c-41e6-a1a2-e9d4ed370735.previewTargets.0.__assoc__.1.1','\"{url}\"'),('sections.38875b9f-df2c-41e6-a1a2-e9d4ed370735.previewTargets.0.__assoc__.2.0','\"refresh\"'),('sections.38875b9f-df2c-41e6-a1a2-e9d4ed370735.previewTargets.0.__assoc__.2.1','\"1\"'),('sections.38875b9f-df2c-41e6-a1a2-e9d4ed370735.propagationMethod','\"all\"'),('sections.38875b9f-df2c-41e6-a1a2-e9d4ed370735.siteSettings.f957802c-8f19-44d3-a30a-668d452862ac.enabledByDefault','true'),('sections.38875b9f-df2c-41e6-a1a2-e9d4ed370735.siteSettings.f957802c-8f19-44d3-a30a-668d452862ac.hasUrls','true'),('sections.38875b9f-df2c-41e6-a1a2-e9d4ed370735.siteSettings.f957802c-8f19-44d3-a30a-668d452862ac.template','\"headsets/_entry\"'),('sections.38875b9f-df2c-41e6-a1a2-e9d4ed370735.siteSettings.f957802c-8f19-44d3-a30a-668d452862ac.uriFormat','\"headsets/{slug}\"'),('sections.38875b9f-df2c-41e6-a1a2-e9d4ed370735.type','\"channel\"'),('sections.b3e8c798-1f09-4ca2-ac30-695d0273d094.defaultPlacement','\"end\"'),('sections.b3e8c798-1f09-4ca2-ac30-695d0273d094.enableVersioning','true'),('sections.b3e8c798-1f09-4ca2-ac30-695d0273d094.handle','\"movies\"'),('sections.b3e8c798-1f09-4ca2-ac30-695d0273d094.name','\"Movies\"'),('sections.b3e8c798-1f09-4ca2-ac30-695d0273d094.previewTargets.0.__assoc__.0.0','\"label\"'),('sections.b3e8c798-1f09-4ca2-ac30-695d0273d094.previewTargets.0.__assoc__.0.1','\"Primary entry page\"'),('sections.b3e8c798-1f09-4ca2-ac30-695d0273d094.previewTargets.0.__assoc__.1.0','\"urlFormat\"'),('sections.b3e8c798-1f09-4ca2-ac30-695d0273d094.previewTargets.0.__assoc__.1.1','\"{url}\"'),('sections.b3e8c798-1f09-4ca2-ac30-695d0273d094.previewTargets.0.__assoc__.2.0','\"refresh\"'),('sections.b3e8c798-1f09-4ca2-ac30-695d0273d094.previewTargets.0.__assoc__.2.1','\"1\"'),('sections.b3e8c798-1f09-4ca2-ac30-695d0273d094.propagationMethod','\"all\"'),('sections.b3e8c798-1f09-4ca2-ac30-695d0273d094.siteSettings.f957802c-8f19-44d3-a30a-668d452862ac.enabledByDefault','true'),('sections.b3e8c798-1f09-4ca2-ac30-695d0273d094.siteSettings.f957802c-8f19-44d3-a30a-668d452862ac.hasUrls','true'),('sections.b3e8c798-1f09-4ca2-ac30-695d0273d094.siteSettings.f957802c-8f19-44d3-a30a-668d452862ac.template','\"movies/_entry\"'),('sections.b3e8c798-1f09-4ca2-ac30-695d0273d094.siteSettings.f957802c-8f19-44d3-a30a-668d452862ac.uriFormat','\"movies/{slug}\"'),('sections.b3e8c798-1f09-4ca2-ac30-695d0273d094.type','\"channel\"'),('sections.cb843ec5-3aaa-44ea-94cf-f99f4023642f.defaultPlacement','\"end\"'),('sections.cb843ec5-3aaa-44ea-94cf-f99f4023642f.enableVersioning','true'),('sections.cb843ec5-3aaa-44ea-94cf-f99f4023642f.handle','\"statistics\"'),('sections.cb843ec5-3aaa-44ea-94cf-f99f4023642f.name','\"Statistics\"'),('sections.cb843ec5-3aaa-44ea-94cf-f99f4023642f.previewTargets.0.__assoc__.0.0','\"label\"'),('sections.cb843ec5-3aaa-44ea-94cf-f99f4023642f.previewTargets.0.__assoc__.0.1','\"Primary entry page\"'),('sections.cb843ec5-3aaa-44ea-94cf-f99f4023642f.previewTargets.0.__assoc__.1.0','\"urlFormat\"'),('sections.cb843ec5-3aaa-44ea-94cf-f99f4023642f.previewTargets.0.__assoc__.1.1','\"{url}\"'),('sections.cb843ec5-3aaa-44ea-94cf-f99f4023642f.previewTargets.0.__assoc__.2.0','\"refresh\"'),('sections.cb843ec5-3aaa-44ea-94cf-f99f4023642f.previewTargets.0.__assoc__.2.1','\"1\"'),('sections.cb843ec5-3aaa-44ea-94cf-f99f4023642f.propagationMethod','\"all\"'),('sections.cb843ec5-3aaa-44ea-94cf-f99f4023642f.siteSettings.f957802c-8f19-44d3-a30a-668d452862ac.enabledByDefault','true'),('sections.cb843ec5-3aaa-44ea-94cf-f99f4023642f.siteSettings.f957802c-8f19-44d3-a30a-668d452862ac.hasUrls','true'),('sections.cb843ec5-3aaa-44ea-94cf-f99f4023642f.siteSettings.f957802c-8f19-44d3-a30a-668d452862ac.template','\"statistics/_entry\"'),('sections.cb843ec5-3aaa-44ea-94cf-f99f4023642f.siteSettings.f957802c-8f19-44d3-a30a-668d452862ac.uriFormat','\"statistics/{slug}\"'),('sections.cb843ec5-3aaa-44ea-94cf-f99f4023642f.type','\"channel\"'),('sections.fa1a9449-1cdb-4185-8017-6d6baea8371b.defaultPlacement','\"end\"'),('sections.fa1a9449-1cdb-4185-8017-6d6baea8371b.enableVersioning','true'),('sections.fa1a9449-1cdb-4185-8017-6d6baea8371b.handle','\"venues\"'),('sections.fa1a9449-1cdb-4185-8017-6d6baea8371b.name','\"Venues\"'),('sections.fa1a9449-1cdb-4185-8017-6d6baea8371b.previewTargets.0.__assoc__.0.0','\"label\"'),('sections.fa1a9449-1cdb-4185-8017-6d6baea8371b.previewTargets.0.__assoc__.0.1','\"Primary entry page\"'),('sections.fa1a9449-1cdb-4185-8017-6d6baea8371b.previewTargets.0.__assoc__.1.0','\"urlFormat\"'),('sections.fa1a9449-1cdb-4185-8017-6d6baea8371b.previewTargets.0.__assoc__.1.1','\"{url}\"'),('sections.fa1a9449-1cdb-4185-8017-6d6baea8371b.previewTargets.0.__assoc__.2.0','\"refresh\"'),('sections.fa1a9449-1cdb-4185-8017-6d6baea8371b.previewTargets.0.__assoc__.2.1','\"1\"'),('sections.fa1a9449-1cdb-4185-8017-6d6baea8371b.propagationMethod','\"all\"'),('sections.fa1a9449-1cdb-4185-8017-6d6baea8371b.siteSettings.f957802c-8f19-44d3-a30a-668d452862ac.enabledByDefault','true'),('sections.fa1a9449-1cdb-4185-8017-6d6baea8371b.siteSettings.f957802c-8f19-44d3-a30a-668d452862ac.hasUrls','true'),('sections.fa1a9449-1cdb-4185-8017-6d6baea8371b.siteSettings.f957802c-8f19-44d3-a30a-668d452862ac.template','\"venues/_entry\"'),('sections.fa1a9449-1cdb-4185-8017-6d6baea8371b.siteSettings.f957802c-8f19-44d3-a30a-668d452862ac.uriFormat','\"venues/{slug}\"'),('sections.fa1a9449-1cdb-4185-8017-6d6baea8371b.type','\"channel\"'),('siteGroups.3226293d-1172-4808-9dfa-adbbb8120257.name','\"Emagine VR Analytics\"'),('sites.f957802c-8f19-44d3-a30a-668d452862ac.baseUrl','\"$PRIMARY_SITE_URL\"'),('sites.f957802c-8f19-44d3-a30a-668d452862ac.enabled','true'),('sites.f957802c-8f19-44d3-a30a-668d452862ac.handle','\"default\"'),('sites.f957802c-8f19-44d3-a30a-668d452862ac.hasUrls','true'),('sites.f957802c-8f19-44d3-a30a-668d452862ac.language','\"en-US\"'),('sites.f957802c-8f19-44d3-a30a-668d452862ac.name','\"Emagine VR Analytics\"'),('sites.f957802c-8f19-44d3-a30a-668d452862ac.primary','true'),('sites.f957802c-8f19-44d3-a30a-668d452862ac.siteGroup','\"3226293d-1172-4808-9dfa-adbbb8120257\"'),('sites.f957802c-8f19-44d3-a30a-668d452862ac.sortOrder','1'),('system.edition','\"pro\"'),('system.live','true'),('system.name','\"Emagine VR Analytics\"'),('system.retryDuration','null'),('system.schemaVersion','\"4.5.3.0\"'),('system.timeZone','\"Europe/Dublin\"'),('users.allowPublicRegistration','false'),('users.defaultGroup','null'),('users.fieldLayouts.2357198e-505a-4226-9d93-dc306b8194dd.tabs.0.elementCondition','null'),('users.fieldLayouts.2357198e-505a-4226-9d93-dc306b8194dd.tabs.0.elements.0.elementCondition','null'),('users.fieldLayouts.2357198e-505a-4226-9d93-dc306b8194dd.tabs.0.elements.0.fieldUid','\"349ff4ce-c3d6-401e-a73d-26ef36146dba\"'),('users.fieldLayouts.2357198e-505a-4226-9d93-dc306b8194dd.tabs.0.elements.0.instructions','null'),('users.fieldLayouts.2357198e-505a-4226-9d93-dc306b8194dd.tabs.0.elements.0.label','null'),('users.fieldLayouts.2357198e-505a-4226-9d93-dc306b8194dd.tabs.0.elements.0.required','false'),('users.fieldLayouts.2357198e-505a-4226-9d93-dc306b8194dd.tabs.0.elements.0.tip','null'),('users.fieldLayouts.2357198e-505a-4226-9d93-dc306b8194dd.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('users.fieldLayouts.2357198e-505a-4226-9d93-dc306b8194dd.tabs.0.elements.0.uid','\"a033941f-3eeb-4aff-aacc-d944b30c1d14\"'),('users.fieldLayouts.2357198e-505a-4226-9d93-dc306b8194dd.tabs.0.elements.0.userCondition','null'),('users.fieldLayouts.2357198e-505a-4226-9d93-dc306b8194dd.tabs.0.elements.0.warning','null'),('users.fieldLayouts.2357198e-505a-4226-9d93-dc306b8194dd.tabs.0.elements.0.width','100'),('users.fieldLayouts.2357198e-505a-4226-9d93-dc306b8194dd.tabs.0.name','\"Details\"'),('users.fieldLayouts.2357198e-505a-4226-9d93-dc306b8194dd.tabs.0.uid','\"16c37192-5bde-450b-8f80-00bb7e266800\"'),('users.fieldLayouts.2357198e-505a-4226-9d93-dc306b8194dd.tabs.0.userCondition','null'),('users.groups.32c28836-80b3-4da9-a427-6d42b223613b.description','\"Clients to the analytics system\"'),('users.groups.32c28836-80b3-4da9-a427-6d42b223613b.handle','\"Clients\"'),('users.groups.32c28836-80b3-4da9-a427-6d42b223613b.name','\"Clients\"'),('users.groups.32c28836-80b3-4da9-a427-6d42b223613b.permissions.0','\"createentries:38875b9f-df2c-41e6-a1a2-e9d4ed370735\"'),('users.groups.32c28836-80b3-4da9-a427-6d42b223613b.permissions.1','\"createentries:cb843ec5-3aaa-44ea-94cf-f99f4023642f\"'),('users.groups.32c28836-80b3-4da9-a427-6d42b223613b.permissions.2','\"createentries:fa1a9449-1cdb-4185-8017-6d6baea8371b\"'),('users.groups.32c28836-80b3-4da9-a427-6d42b223613b.permissions.3','\"deleteentries:38875b9f-df2c-41e6-a1a2-e9d4ed370735\"'),('users.groups.32c28836-80b3-4da9-a427-6d42b223613b.permissions.4','\"saveentries:38875b9f-df2c-41e6-a1a2-e9d4ed370735\"'),('users.groups.32c28836-80b3-4da9-a427-6d42b223613b.permissions.5','\"saveentries:cb843ec5-3aaa-44ea-94cf-f99f4023642f\"'),('users.groups.32c28836-80b3-4da9-a427-6d42b223613b.permissions.6','\"saveentries:fa1a9449-1cdb-4185-8017-6d6baea8371b\"'),('users.groups.32c28836-80b3-4da9-a427-6d42b223613b.permissions.7','\"viewentries:38875b9f-df2c-41e6-a1a2-e9d4ed370735\"'),('users.groups.32c28836-80b3-4da9-a427-6d42b223613b.permissions.8','\"viewentries:cb843ec5-3aaa-44ea-94cf-f99f4023642f\"'),('users.groups.32c28836-80b3-4da9-a427-6d42b223613b.permissions.9','\"viewentries:fa1a9449-1cdb-4185-8017-6d6baea8371b\"'),('users.groups.a5255343-5341-4742-9fd7-dc1f26af404a.description','\"\"'),('users.groups.a5255343-5341-4742-9fd7-dc1f26af404a.handle','\"admin\"'),('users.groups.a5255343-5341-4742-9fd7-dc1f26af404a.name','\"Admin\"'),('users.groups.a5255343-5341-4742-9fd7-dc1f26af404a.permissions.0','\"accesscp\"'),('users.groups.a5255343-5341-4742-9fd7-dc1f26af404a.permissions.1','\"accesscpwhensystemisoff\"'),('users.groups.a5255343-5341-4742-9fd7-dc1f26af404a.permissions.10','\"deleteentries:38875b9f-df2c-41e6-a1a2-e9d4ed370735\"'),('users.groups.a5255343-5341-4742-9fd7-dc1f26af404a.permissions.11','\"deleteentries:cb843ec5-3aaa-44ea-94cf-f99f4023642f\"'),('users.groups.a5255343-5341-4742-9fd7-dc1f26af404a.permissions.12','\"deleteentries:fa1a9449-1cdb-4185-8017-6d6baea8371b\"'),('users.groups.a5255343-5341-4742-9fd7-dc1f26af404a.permissions.13','\"deletepeerentries:38875b9f-df2c-41e6-a1a2-e9d4ed370735\"'),('users.groups.a5255343-5341-4742-9fd7-dc1f26af404a.permissions.14','\"deletepeerentries:cb843ec5-3aaa-44ea-94cf-f99f4023642f\"'),('users.groups.a5255343-5341-4742-9fd7-dc1f26af404a.permissions.15','\"deletepeerentries:fa1a9449-1cdb-4185-8017-6d6baea8371b\"'),('users.groups.a5255343-5341-4742-9fd7-dc1f26af404a.permissions.16','\"deletepeerentrydrafts:38875b9f-df2c-41e6-a1a2-e9d4ed370735\"'),('users.groups.a5255343-5341-4742-9fd7-dc1f26af404a.permissions.17','\"deletepeerentrydrafts:cb843ec5-3aaa-44ea-94cf-f99f4023642f\"'),('users.groups.a5255343-5341-4742-9fd7-dc1f26af404a.permissions.18','\"deletepeerentrydrafts:fa1a9449-1cdb-4185-8017-6d6baea8371b\"'),('users.groups.a5255343-5341-4742-9fd7-dc1f26af404a.permissions.19','\"deleteusers\"'),('users.groups.a5255343-5341-4742-9fd7-dc1f26af404a.permissions.2','\"accesssitewhensystemisoff\"'),('users.groups.a5255343-5341-4742-9fd7-dc1f26af404a.permissions.20','\"editusers\"'),('users.groups.a5255343-5341-4742-9fd7-dc1f26af404a.permissions.21','\"impersonateusers\"'),('users.groups.a5255343-5341-4742-9fd7-dc1f26af404a.permissions.22','\"moderateusers\"'),('users.groups.a5255343-5341-4742-9fd7-dc1f26af404a.permissions.23','\"performupdates\"'),('users.groups.a5255343-5341-4742-9fd7-dc1f26af404a.permissions.24','\"registerusers\"'),('users.groups.a5255343-5341-4742-9fd7-dc1f26af404a.permissions.25','\"saveentries:38875b9f-df2c-41e6-a1a2-e9d4ed370735\"'),('users.groups.a5255343-5341-4742-9fd7-dc1f26af404a.permissions.26','\"saveentries:cb843ec5-3aaa-44ea-94cf-f99f4023642f\"'),('users.groups.a5255343-5341-4742-9fd7-dc1f26af404a.permissions.27','\"saveentries:fa1a9449-1cdb-4185-8017-6d6baea8371b\"'),('users.groups.a5255343-5341-4742-9fd7-dc1f26af404a.permissions.28','\"savepeerentries:38875b9f-df2c-41e6-a1a2-e9d4ed370735\"'),('users.groups.a5255343-5341-4742-9fd7-dc1f26af404a.permissions.29','\"savepeerentries:cb843ec5-3aaa-44ea-94cf-f99f4023642f\"'),('users.groups.a5255343-5341-4742-9fd7-dc1f26af404a.permissions.3','\"administrateusers\"'),('users.groups.a5255343-5341-4742-9fd7-dc1f26af404a.permissions.30','\"savepeerentries:fa1a9449-1cdb-4185-8017-6d6baea8371b\"'),('users.groups.a5255343-5341-4742-9fd7-dc1f26af404a.permissions.31','\"savepeerentrydrafts:38875b9f-df2c-41e6-a1a2-e9d4ed370735\"'),('users.groups.a5255343-5341-4742-9fd7-dc1f26af404a.permissions.32','\"savepeerentrydrafts:cb843ec5-3aaa-44ea-94cf-f99f4023642f\"'),('users.groups.a5255343-5341-4742-9fd7-dc1f26af404a.permissions.33','\"savepeerentrydrafts:fa1a9449-1cdb-4185-8017-6d6baea8371b\"'),('users.groups.a5255343-5341-4742-9fd7-dc1f26af404a.permissions.34','\"utility:clear-caches\"'),('users.groups.a5255343-5341-4742-9fd7-dc1f26af404a.permissions.35','\"utility:db-backup\"'),('users.groups.a5255343-5341-4742-9fd7-dc1f26af404a.permissions.36','\"utility:deprecation-errors\"'),('users.groups.a5255343-5341-4742-9fd7-dc1f26af404a.permissions.37','\"utility:find-replace\"'),('users.groups.a5255343-5341-4742-9fd7-dc1f26af404a.permissions.38','\"utility:migrations\"'),('users.groups.a5255343-5341-4742-9fd7-dc1f26af404a.permissions.39','\"utility:php-info\"'),('users.groups.a5255343-5341-4742-9fd7-dc1f26af404a.permissions.4','\"assignusergroup:32c28836-80b3-4da9-a427-6d42b223613b\"'),('users.groups.a5255343-5341-4742-9fd7-dc1f26af404a.permissions.40','\"utility:queue-manager\"'),('users.groups.a5255343-5341-4742-9fd7-dc1f26af404a.permissions.41','\"utility:system-messages\"'),('users.groups.a5255343-5341-4742-9fd7-dc1f26af404a.permissions.42','\"utility:system-report\"'),('users.groups.a5255343-5341-4742-9fd7-dc1f26af404a.permissions.43','\"utility:updates\"'),('users.groups.a5255343-5341-4742-9fd7-dc1f26af404a.permissions.44','\"viewentries:38875b9f-df2c-41e6-a1a2-e9d4ed370735\"'),('users.groups.a5255343-5341-4742-9fd7-dc1f26af404a.permissions.45','\"viewentries:cb843ec5-3aaa-44ea-94cf-f99f4023642f\"'),('users.groups.a5255343-5341-4742-9fd7-dc1f26af404a.permissions.46','\"viewentries:fa1a9449-1cdb-4185-8017-6d6baea8371b\"'),('users.groups.a5255343-5341-4742-9fd7-dc1f26af404a.permissions.47','\"viewpeerentries:38875b9f-df2c-41e6-a1a2-e9d4ed370735\"'),('users.groups.a5255343-5341-4742-9fd7-dc1f26af404a.permissions.48','\"viewpeerentries:cb843ec5-3aaa-44ea-94cf-f99f4023642f\"'),('users.groups.a5255343-5341-4742-9fd7-dc1f26af404a.permissions.49','\"viewpeerentries:fa1a9449-1cdb-4185-8017-6d6baea8371b\"'),('users.groups.a5255343-5341-4742-9fd7-dc1f26af404a.permissions.5','\"assignusergroup:a5255343-5341-4742-9fd7-dc1f26af404a\"'),('users.groups.a5255343-5341-4742-9fd7-dc1f26af404a.permissions.50','\"viewpeerentrydrafts:38875b9f-df2c-41e6-a1a2-e9d4ed370735\"'),('users.groups.a5255343-5341-4742-9fd7-dc1f26af404a.permissions.51','\"viewpeerentrydrafts:cb843ec5-3aaa-44ea-94cf-f99f4023642f\"'),('users.groups.a5255343-5341-4742-9fd7-dc1f26af404a.permissions.52','\"viewpeerentrydrafts:fa1a9449-1cdb-4185-8017-6d6baea8371b\"'),('users.groups.a5255343-5341-4742-9fd7-dc1f26af404a.permissions.6','\"assignuserpermissions\"'),('users.groups.a5255343-5341-4742-9fd7-dc1f26af404a.permissions.7','\"createentries:38875b9f-df2c-41e6-a1a2-e9d4ed370735\"'),('users.groups.a5255343-5341-4742-9fd7-dc1f26af404a.permissions.8','\"createentries:cb843ec5-3aaa-44ea-94cf-f99f4023642f\"'),('users.groups.a5255343-5341-4742-9fd7-dc1f26af404a.permissions.9','\"createentries:fa1a9449-1cdb-4185-8017-6d6baea8371b\"'),('users.photoSubpath','null'),('users.photoVolumeUid','null'),('users.requireEmailVerification','true');
/*!40000 ALTER TABLE `projectconfig` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `queue`
--

DROP TABLE IF EXISTS `queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `queue` (
  `id` int NOT NULL AUTO_INCREMENT,
  `channel` varchar(255) NOT NULL DEFAULT 'queue',
  `job` longblob NOT NULL,
  `description` text,
  `timePushed` int NOT NULL,
  `ttr` int NOT NULL,
  `delay` int NOT NULL DEFAULT '0',
  `priority` int unsigned NOT NULL DEFAULT '1024',
  `dateReserved` datetime DEFAULT NULL,
  `timeUpdated` int DEFAULT NULL,
  `progress` smallint NOT NULL DEFAULT '0',
  `progressLabel` varchar(255) DEFAULT NULL,
  `attempt` int DEFAULT NULL,
  `fail` tinyint(1) DEFAULT '0',
  `dateFailed` datetime DEFAULT NULL,
  `error` text,
  PRIMARY KEY (`id`),
  KEY `idx_oletueznaeckolskrnpkzdrbfmbulluvagyj` (`channel`,`fail`,`timeUpdated`,`timePushed`),
  KEY `idx_cxvzhybqxphtogrzmehryeskwjlpxzdeyohn` (`channel`,`fail`,`timeUpdated`,`delay`)
) ENGINE=InnoDB AUTO_INCREMENT=587 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `queue`
--

LOCK TABLES `queue` WRITE;
/*!40000 ALTER TABLE `queue` DISABLE KEYS */;
/*!40000 ALTER TABLE `queue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `relations`
--

DROP TABLE IF EXISTS `relations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `relations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldId` int NOT NULL,
  `sourceId` int NOT NULL,
  `sourceSiteId` int DEFAULT NULL,
  `targetId` int NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ymyzoocqijbklcdcimoiylnjeekvksvxctbx` (`fieldId`,`sourceId`,`sourceSiteId`,`targetId`),
  KEY `idx_auzbwobgdkibyxjeprdydrdkysdfokmgpeff` (`sourceId`),
  KEY `idx_aftqfeazmlzyiptjxyuuzxygjizselxjzzoe` (`targetId`),
  KEY `idx_ecwbcwemoqqsuruhcxfvkcvxcbfsxqvbstms` (`sourceSiteId`),
  CONSTRAINT `fk_eonbcnswraswullhpgsspxurezllezkcbueq` FOREIGN KEY (`sourceId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_hfhkbzhbuedgverkobupwpslytxxbodbwyff` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_vbpzdzpoysbqucslgvcnambrlgtnbtkujrbt` FOREIGN KEY (`sourceSiteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=516 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `relations`
--

LOCK TABLES `relations` WRITE;
/*!40000 ALTER TABLE `relations` DISABLE KEYS */;
INSERT INTO `relations` VALUES (1,8,9,NULL,6,1,'2023-11-04 15:31:11','2023-11-04 15:31:11','95cfdc82-4a1f-407a-ab99-853d5e13234f'),(2,8,10,NULL,6,1,'2023-11-04 15:31:26','2023-11-04 15:31:26','ac1e273d-af54-49b5-b03e-976c28ba4f53'),(3,8,11,NULL,6,1,'2023-11-04 15:31:34','2023-11-04 15:31:34','973c2a9c-097e-44f8-acc4-3a261014e8d3'),(4,8,12,NULL,6,1,'2023-11-04 15:31:59','2023-11-04 15:31:59','a41aa1c4-bb43-429f-8631-033833a6c884'),(5,8,13,NULL,4,1,'2023-11-04 15:33:59','2023-11-04 15:33:59','2e507d7b-6adc-44c2-b20b-7f62fbed3d0d'),(6,8,14,NULL,4,1,'2023-11-04 15:34:00','2023-11-04 15:34:00','8c96f1d4-d81a-46d4-ad9f-c4e7424b835c'),(7,8,15,NULL,6,1,'2023-11-04 15:34:08','2023-11-04 15:34:08','25172fdf-ae79-4a0e-ae59-feee1cb0780e'),(8,8,16,NULL,6,1,'2023-11-04 15:34:09','2023-11-04 15:34:09','027baf2a-2bc4-4215-bcf0-602ec7540c29'),(11,8,2,NULL,4,1,'2023-11-04 15:34:40','2023-11-04 15:34:40','d1fc34e3-1182-46de-93c1-039bbdc51f5c'),(12,10,2,NULL,18,1,'2023-11-04 15:34:40','2023-11-04 15:34:40','8b34523f-23b4-469e-80fd-e2c975e0b984'),(13,8,20,NULL,4,1,'2023-11-04 15:34:40','2023-11-04 15:34:40','ed96b3fc-6ca5-4cf4-82cc-01f114e9c85c'),(14,10,20,NULL,18,1,'2023-11-04 15:34:40','2023-11-04 15:34:40','966e31cf-6a4b-41e2-8b59-892716e0594a'),(18,11,2,NULL,13,1,'2023-11-04 15:36:17','2023-11-04 15:36:17','b355cc3c-bf63-4bae-a9f5-5b47f065147e'),(19,8,22,NULL,4,1,'2023-11-04 15:36:17','2023-11-04 15:36:17','745edc13-0b59-4cfb-bad9-fca9da2e92dc'),(20,11,22,NULL,13,1,'2023-11-04 15:36:17','2023-11-04 15:36:17','3b19720e-8aa1-437b-b271-cef9012517e6'),(21,10,22,NULL,18,1,'2023-11-04 15:36:17','2023-11-04 15:36:17','4480c064-f95c-43a0-81c2-6c1cd1084773'),(25,11,9,NULL,15,1,'2023-11-04 15:36:50','2023-11-04 15:36:50','90b3893b-46e9-41fa-90b1-32316ae03e9c'),(26,10,9,NULL,24,1,'2023-11-04 15:36:50','2023-11-04 15:36:50','a58f701a-2512-4d68-91fc-1160e4aecfd7'),(27,8,26,NULL,6,1,'2023-11-04 15:36:50','2023-11-04 15:36:50','a7eded00-0671-49ef-9952-91fe4c58c0c8'),(28,11,26,NULL,15,1,'2023-11-04 15:36:50','2023-11-04 15:36:50','6cdb1b53-e410-48a4-a913-9ee7c698f0de'),(29,10,26,NULL,24,1,'2023-11-04 15:36:50','2023-11-04 15:36:50','99dc4ff0-4181-47ab-b7aa-9bf9f250d402'),(33,11,11,NULL,15,1,'2023-11-04 15:37:01','2023-11-04 15:37:01','b4b414d8-8181-4efe-89eb-e33440b23e6b'),(34,10,11,NULL,24,1,'2023-11-04 15:37:01','2023-11-04 15:37:01','7fe84852-6b0e-47bc-8018-75c6b7f59c8a'),(35,8,28,NULL,6,1,'2023-11-04 15:37:01','2023-11-04 15:37:01','b0036c46-4978-42ec-9e73-92c075585369'),(36,11,28,NULL,15,1,'2023-11-04 15:37:01','2023-11-04 15:37:01','a645eb98-9714-4323-ae0f-b6db0aa8d2dd'),(37,10,28,NULL,24,1,'2023-11-04 15:37:01','2023-11-04 15:37:01','5619bca4-cd4c-471f-af50-857068d4d343'),(41,8,30,NULL,6,1,'2023-11-04 15:37:25','2023-11-04 15:37:25','28cbe6bd-7211-49ef-ab5b-975896337c52'),(42,11,30,NULL,15,1,'2023-11-04 15:37:25','2023-11-04 15:37:25','5aef9edc-17c2-4b78-ad56-40a13ebebca9'),(43,10,30,NULL,24,1,'2023-11-04 15:37:25','2023-11-04 15:37:25','898fab3b-4eb3-4123-b800-f5ddce94a503'),(44,8,31,NULL,6,1,'2023-11-04 15:37:46','2023-11-04 15:37:46','4a813f50-5a66-4c30-b068-c2ef0632bc67'),(45,11,31,NULL,15,1,'2023-11-04 15:37:48','2023-11-04 15:37:48','469c8782-4f56-44fe-b0d9-70d909887242'),(46,10,31,NULL,24,1,'2023-11-04 15:37:51','2023-11-04 15:37:51','7d32156f-1627-4523-b744-22b76e439ead'),(47,8,32,NULL,6,1,'2023-11-04 15:38:04','2023-11-04 15:38:04','d6e3a408-8526-4c09-86b5-f41575d54e51'),(48,11,32,NULL,15,1,'2023-11-04 15:38:04','2023-11-04 15:38:04','5a0e0b9d-bd91-4c32-9877-b34633bd5f82'),(49,10,32,NULL,24,1,'2023-11-04 15:38:04','2023-11-04 15:38:04','84929206-f0e9-48ec-a418-fd55c9080313'),(50,8,33,NULL,4,1,'2023-11-04 15:38:26','2023-11-04 15:38:26','856ab2b8-abab-4adc-92a4-515be0f95912'),(51,11,33,NULL,13,1,'2023-11-04 15:38:28','2023-11-04 15:38:28','bbf1c824-dca1-4e47-a20b-b904ec115949'),(52,10,33,NULL,18,1,'2023-11-04 15:38:32','2023-11-04 15:38:32','c964f26a-a0e6-4002-bdb6-e9522c4abae6'),(53,8,34,NULL,4,1,'2023-11-04 15:38:38','2023-11-04 15:38:38','82cc596f-1fa2-493d-8d4f-f57b57144c85'),(54,11,34,NULL,13,1,'2023-11-04 15:38:38','2023-11-04 15:38:38','95190156-c59e-4caf-8e46-4268a6bef358'),(55,10,34,NULL,18,1,'2023-11-04 15:38:38','2023-11-04 15:38:38','c1bb3329-43f3-453b-ad57-37df01468b0b'),(59,8,36,NULL,4,1,'2023-11-04 15:38:45','2023-11-04 15:38:45','e263fbd3-d02d-4a07-b7cf-650e43c679f5'),(60,11,36,NULL,13,1,'2023-11-04 15:38:45','2023-11-04 15:38:45','3a3b01f8-ed64-4f17-8c13-55bd6f95d1b6'),(61,10,36,NULL,18,1,'2023-11-04 15:38:45','2023-11-04 15:38:45','13c2bf4c-a2f7-4933-aec5-264361f8daf2'),(62,8,37,NULL,4,1,'2023-11-04 15:38:54','2023-11-04 15:38:54','3f71dd9d-acb8-4710-a9bd-1648c57ce655'),(63,8,38,NULL,4,1,'2023-11-04 15:39:05','2023-11-04 15:39:05','4d5520d5-817d-4493-bd14-a72639f48220'),(64,8,39,NULL,4,1,'2023-11-04 15:39:06','2023-11-04 15:39:06','3acecebb-dfc3-42ab-8b2d-0cdc305ee99b'),(65,11,37,NULL,38,1,'2023-11-04 15:39:07','2023-11-04 15:39:07','d688e106-bb61-4ac5-84ca-a1b33040499b'),(66,10,37,NULL,18,1,'2023-11-04 15:39:11','2023-11-04 15:39:11','4553cab8-48c3-4d1c-8217-4a64fcc42221'),(67,8,40,NULL,4,1,'2023-11-04 15:39:19','2023-11-04 15:39:19','7404cb44-1401-4e33-b943-b528de583bf4'),(68,11,40,NULL,38,1,'2023-11-04 15:39:19','2023-11-04 15:39:19','de44b951-89c6-4a81-8d48-d26f3a969cae'),(69,10,40,NULL,18,1,'2023-11-04 15:39:19','2023-11-04 15:39:19','0251319a-2dd4-45eb-8408-22539a8c53f4'),(70,8,41,NULL,4,1,'2023-11-04 15:39:26','2023-11-04 15:39:26','f232dc76-b7b2-4c75-8907-0c364fbb450e'),(71,11,41,NULL,38,1,'2023-11-04 15:39:29','2023-11-04 15:39:29','3fe8acb5-7b81-4ca2-a193-b12fda7d4d20'),(72,10,41,NULL,18,1,'2023-11-04 15:39:31','2023-11-04 15:39:31','aa37e004-5839-46d9-b683-3a467fc7135a'),(73,8,42,NULL,4,1,'2023-11-04 15:39:48','2023-11-04 15:39:48','865c3487-e7a0-4742-8e13-b762db292066'),(74,11,42,NULL,38,1,'2023-11-04 15:39:48','2023-11-04 15:39:48','fd5da688-032e-4335-b417-95a8f517ea85'),(75,10,42,NULL,18,1,'2023-11-04 15:39:48','2023-11-04 15:39:48','960cfe0f-2f95-4ca7-82f9-4fc3d98bbf01'),(76,8,43,NULL,4,1,'2023-11-04 15:40:11','2023-11-04 15:40:11','3b2d0d41-799f-4f7f-b738-f42524ccc14c'),(77,11,43,NULL,38,1,'2023-11-04 15:40:11','2023-11-04 15:40:11','8fa87fef-9ae8-4a27-b5a5-557be6cb2323'),(78,10,43,NULL,18,1,'2023-11-04 15:40:11','2023-11-04 15:40:11','60c887bf-269e-4964-b4a1-fb6d12fb6691'),(79,8,44,NULL,4,1,'2023-11-04 15:40:12','2023-11-04 15:40:12','46df4a4b-673a-4e9e-ad35-dd8f84733852'),(80,11,44,NULL,38,1,'2023-11-04 15:40:12','2023-11-04 15:40:12','66d80e90-d4f5-4d88-87d1-45137584b094'),(81,10,44,NULL,18,1,'2023-11-04 15:40:12','2023-11-04 15:40:12','1cd07b55-7d5a-4ff5-a78e-0ab65d01f72c'),(82,8,45,NULL,4,1,'2023-11-04 15:40:12','2023-11-04 15:40:12','d6924399-bf86-48fa-9292-daf2e8882d51'),(83,11,45,NULL,38,1,'2023-11-04 15:40:12','2023-11-04 15:40:12','38266502-7263-4f53-9bb4-95a60f9a3d7f'),(84,10,45,NULL,18,1,'2023-11-04 15:40:12','2023-11-04 15:40:12','b515ae8a-c180-4e04-a59b-75f8f474d0f3'),(85,8,46,NULL,4,1,'2023-11-04 15:40:12','2023-11-04 15:40:12','63109515-814e-423d-baec-3e55067b9719'),(86,11,46,NULL,38,1,'2023-11-04 15:40:12','2023-11-04 15:40:12','5db4fea4-45aa-4ddd-a699-ebad2eb69c39'),(87,10,46,NULL,18,1,'2023-11-04 15:40:12','2023-11-04 15:40:12','534729a9-0042-42bc-9c6f-a86fc08819ba'),(88,8,47,NULL,4,1,'2023-11-04 15:40:50','2023-11-04 15:40:50','31071d78-2f3a-40c7-82b3-b453a5063dfc'),(89,11,47,NULL,38,1,'2023-11-04 15:40:50','2023-11-04 15:40:50','2d6b06a8-dffa-40d4-ba7b-ab76c7cc839b'),(90,10,47,NULL,18,1,'2023-11-04 15:40:50','2023-11-04 15:40:50','e6134b1c-bcf6-4903-9cea-0ed854658b68'),(91,8,48,NULL,4,1,'2023-11-04 15:40:50','2023-11-04 15:40:50','a0863a0e-3c3e-4d5f-95c2-a8ee9b9fd670'),(92,11,48,NULL,38,1,'2023-11-04 15:40:50','2023-11-04 15:40:50','ae49ab56-4f56-44db-b3fc-813058cad3af'),(93,10,48,NULL,18,1,'2023-11-04 15:40:50','2023-11-04 15:40:50','11861fc4-cbf3-420c-853c-eb918619cdfa'),(94,8,49,NULL,4,1,'2023-11-04 15:40:50','2023-11-04 15:40:50','49345a46-07ab-42db-8792-9d052dcaaebc'),(95,11,49,NULL,38,1,'2023-11-04 15:40:50','2023-11-04 15:40:50','d2a1ed1c-f40e-42e6-bbe2-1ac7e03fbc11'),(96,10,49,NULL,18,1,'2023-11-04 15:40:50','2023-11-04 15:40:50','7c5f91f8-28da-4bca-931c-26c18abd5d12'),(97,8,50,NULL,4,1,'2023-11-04 15:40:50','2023-11-04 15:40:50','0a74c3e1-660d-4fd6-9cbc-d22b7115e48f'),(98,11,50,NULL,38,1,'2023-11-04 15:40:50','2023-11-04 15:40:50','39782f2e-742f-4ebd-898d-37e2900d667d'),(99,10,50,NULL,18,1,'2023-11-04 15:40:50','2023-11-04 15:40:50','5888af17-8a77-4a80-b0a4-9eae1c20ede4'),(100,8,51,NULL,6,1,'2023-11-04 15:41:15','2023-11-04 15:41:15','87ebe4c5-905c-4fe1-b490-049ac2492f80'),(101,11,51,NULL,15,1,'2023-11-04 15:41:17','2023-11-04 15:41:17','c0417b0d-cbc0-4a56-bae9-828c79824158'),(102,10,51,NULL,24,1,'2023-11-04 15:41:20','2023-11-04 15:41:20','5242979e-551c-4f0a-8134-faa09bbf07f5'),(103,8,52,NULL,6,1,'2023-11-04 15:41:31','2023-11-04 15:41:31','81dd8214-c7a2-48c8-9dbb-23bdf33b51c6'),(104,11,52,NULL,15,1,'2023-11-04 15:41:31','2023-11-04 15:41:31','37577b03-e669-49b1-a4fb-6f15df6c9d2a'),(105,10,52,NULL,24,1,'2023-11-04 15:41:31','2023-11-04 15:41:31','31dcb74c-b532-4f40-ad7f-f0174f5f2195'),(106,8,53,NULL,6,1,'2023-11-04 15:41:43','2023-11-04 15:41:43','3edf3694-c41e-4455-b444-258d605ad04c'),(107,11,53,NULL,15,1,'2023-11-04 15:41:43','2023-11-04 15:41:43','fc01c016-2bbf-47b5-8e0d-d79f8f80999b'),(108,10,53,NULL,24,1,'2023-11-04 15:41:43','2023-11-04 15:41:43','7cdeeb6e-53b2-4b66-a3ff-701f129d5c16'),(109,8,54,NULL,6,1,'2023-11-04 15:41:43','2023-11-04 15:41:43','b13a7acf-3034-4a2c-94c8-b4e2f81b005b'),(110,11,54,NULL,15,1,'2023-11-04 15:41:43','2023-11-04 15:41:43','5415bc1d-8193-4048-bfd3-26052a30f122'),(111,10,54,NULL,24,1,'2023-11-04 15:41:43','2023-11-04 15:41:43','d88bcde3-903b-4223-9d97-fccc48fd68cc'),(112,8,55,NULL,6,1,'2023-11-04 15:41:47','2023-11-04 15:41:47','dc5384af-da85-4196-8868-584860ac14c5'),(113,11,55,NULL,15,1,'2023-11-04 15:41:47','2023-11-04 15:41:47','b24987fc-4a22-4fa3-a245-ba310cfd36f4'),(114,10,55,NULL,24,1,'2023-11-04 15:41:47','2023-11-04 15:41:47','34cb1d98-8afb-4c30-8c33-913be5865238'),(115,8,56,NULL,6,1,'2023-11-04 15:41:47','2023-11-04 15:41:47','1fe13c17-944c-4c6b-bb26-02e54eb4834c'),(116,11,56,NULL,15,1,'2023-11-04 15:41:47','2023-11-04 15:41:47','1bf10951-0503-4d95-9046-c9e8491291e4'),(117,10,56,NULL,24,1,'2023-11-04 15:41:47','2023-11-04 15:41:47','ee7ab9c8-654b-41b3-abe8-ca6f26747958'),(118,8,57,NULL,6,1,'2023-11-04 15:41:47','2023-11-04 15:41:47','c9577840-066a-4b7c-85ba-0178f68113cb'),(119,11,57,NULL,15,1,'2023-11-04 15:41:47','2023-11-04 15:41:47','cff50482-96d7-49c4-8f34-a7dcced7ae8f'),(120,10,57,NULL,24,1,'2023-11-04 15:41:47','2023-11-04 15:41:47','73d8175d-1415-4302-9868-1648c11c8065'),(121,8,58,NULL,6,1,'2023-11-04 15:41:47','2023-11-04 15:41:47','5f4229b9-0981-4947-b744-a25580658b92'),(122,11,58,NULL,15,1,'2023-11-04 15:41:47','2023-11-04 15:41:47','f137fc23-e00c-4def-8b27-9fe63ceba6ec'),(123,10,58,NULL,24,1,'2023-11-04 15:41:47','2023-11-04 15:41:47','d83cb794-3c2c-4db7-be6c-ded2a4a5c9a7'),(124,8,59,NULL,6,1,'2023-11-04 15:41:51','2023-11-04 15:41:51','f5ab8e61-e7a7-42e0-88a2-5e95daea6a1e'),(125,11,59,NULL,15,1,'2023-11-04 15:41:52','2023-11-04 15:41:52','f5f2aa39-1952-4a9e-a8a3-285ebae6fe9e'),(126,10,59,NULL,24,1,'2023-11-04 15:41:52','2023-11-04 15:41:52','56c4dda9-b7ea-42cb-a873-6226a7ca8469'),(127,8,60,NULL,6,1,'2023-11-04 15:41:52','2023-11-04 15:41:52','a296c99b-b56e-4c8f-88d8-0129a47a0f01'),(128,11,60,NULL,15,1,'2023-11-04 15:41:52','2023-11-04 15:41:52','cacadaa3-bb14-4434-a892-7ab04128643f'),(129,10,60,NULL,24,1,'2023-11-04 15:41:52','2023-11-04 15:41:52','542f2127-6408-449f-81c2-d1d2a98f3048'),(130,8,61,NULL,6,1,'2023-11-04 15:41:52','2023-11-04 15:41:52','d37d4331-02a5-42d7-b1e6-918cdcf61f6c'),(131,11,61,NULL,15,1,'2023-11-04 15:41:52','2023-11-04 15:41:52','93b43a27-92f1-4fd2-a952-845439f5f09d'),(132,10,61,NULL,24,1,'2023-11-04 15:41:52','2023-11-04 15:41:52','f82c7dea-192e-4ea4-b1c0-32dc85e02970'),(133,8,62,NULL,6,1,'2023-11-04 15:41:52','2023-11-04 15:41:52','ad921738-619f-4e6d-a171-08ad99377776'),(134,11,62,NULL,15,1,'2023-11-04 15:41:52','2023-11-04 15:41:52','fb335664-c62e-4242-b45b-302e9b473c4b'),(135,10,62,NULL,24,1,'2023-11-04 15:41:52','2023-11-04 15:41:52','deceb30d-886d-4ce4-a76c-15e9e68db8b3'),(136,8,63,NULL,6,1,'2023-11-04 15:41:52','2023-11-04 15:41:52','83805b29-714d-4e87-88b4-65ae96172161'),(137,11,63,NULL,15,1,'2023-11-04 15:41:52','2023-11-04 15:41:52','613e0e9c-8ddd-47a5-8e75-34ff4187a452'),(138,10,63,NULL,24,1,'2023-11-04 15:41:52','2023-11-04 15:41:52','1bafc408-b666-413d-b530-c15ce4445fb2'),(139,8,64,NULL,6,1,'2023-11-04 15:41:52','2023-11-04 15:41:52','ee20549a-3ce8-4faf-8648-f6fb50e6cfbd'),(140,11,64,NULL,15,1,'2023-11-04 15:41:52','2023-11-04 15:41:52','8072deac-4561-4ab7-a5f2-6a24e311aede'),(141,10,64,NULL,24,1,'2023-11-04 15:41:52','2023-11-04 15:41:52','b2af561d-0fd3-49b4-be30-586b063e3660'),(142,8,65,NULL,6,1,'2023-11-04 15:41:52','2023-11-04 15:41:52','4ebf2854-d508-43f0-a815-3e3caa13ff4c'),(143,11,65,NULL,15,1,'2023-11-04 15:41:52','2023-11-04 15:41:52','414fb32c-5c06-440d-b2ae-2df785f2165c'),(144,10,65,NULL,24,1,'2023-11-04 15:41:52','2023-11-04 15:41:52','7b53f96f-e26c-43d8-874f-e0fa5c6d0951'),(145,8,66,NULL,6,1,'2023-11-04 15:41:52','2023-11-04 15:41:52','40944fc6-5536-4e22-afc5-14a5368e6d6e'),(146,11,66,NULL,15,1,'2023-11-04 15:41:52','2023-11-04 15:41:52','f4bf6b5e-f70a-4333-8c6e-7d47e0a8c208'),(147,10,66,NULL,24,1,'2023-11-04 15:41:52','2023-11-04 15:41:52','e2cc07e0-637a-4267-a321-a71a543b29c5'),(148,10,67,NULL,24,1,'2023-11-04 15:42:17','2023-11-04 15:42:17','3c68a8c6-b4e2-448a-9a0e-4ce05fc77ae2'),(149,11,67,NULL,15,1,'2023-11-04 15:42:19','2023-11-04 15:42:19','5c94f5fc-5700-42f8-b3df-5dbc8b930f3d'),(150,8,67,NULL,6,1,'2023-11-04 15:42:22','2023-11-04 15:42:22','bc1a5341-5bc1-4c4f-9dd8-23172313417c'),(151,8,68,NULL,6,1,'2023-11-04 15:42:35','2023-11-04 15:42:35','cd0042f4-402e-4011-bfe5-85ef55572324'),(152,11,68,NULL,15,1,'2023-11-04 15:42:35','2023-11-04 15:42:35','6bdbf7f3-975b-429b-bae2-8376b129b917'),(153,10,68,NULL,24,1,'2023-11-04 15:42:35','2023-11-04 15:42:35','35c2b8d2-32d2-4bca-961f-259f2264bece'),(154,8,69,NULL,6,1,'2023-11-04 15:42:40','2023-11-04 15:42:40','945d046d-b616-47d6-add4-ff8231fe4e33'),(155,11,69,NULL,15,1,'2023-11-04 15:42:40','2023-11-04 15:42:40','78f022b9-f218-400e-a758-080907718bf7'),(156,10,69,NULL,24,1,'2023-11-04 15:42:40','2023-11-04 15:42:40','e52f7ae8-6769-49c3-9a37-aec10945e7d4'),(157,8,70,NULL,6,1,'2023-11-04 15:42:40','2023-11-04 15:42:40','8b8777e6-9e99-4a37-ad15-54fb39105ed5'),(158,11,70,NULL,15,1,'2023-11-04 15:42:40','2023-11-04 15:42:40','d23435cb-4633-40f9-820f-a69543c9ca31'),(159,10,70,NULL,24,1,'2023-11-04 15:42:40','2023-11-04 15:42:40','942028ad-ea07-497d-9870-e2bca7e9e26e'),(163,8,72,NULL,6,1,'2023-11-04 15:42:51','2023-11-04 15:42:51','2d239d9c-641d-48c1-b325-736b9eedf6eb'),(164,11,72,NULL,15,1,'2023-11-04 15:42:51','2023-11-04 15:42:51','0f75e6b2-a023-4e2d-8830-a2b917cb1142'),(165,10,72,NULL,24,1,'2023-11-04 15:42:51','2023-11-04 15:42:51','f2556f51-a103-4c2d-b9d6-5edcd1fe392e'),(166,8,73,NULL,6,1,'2023-11-04 15:42:56','2023-11-04 15:42:56','ab34758e-df08-4345-9bf6-2e171fd2a155'),(167,11,73,NULL,15,1,'2023-11-04 15:42:56','2023-11-04 15:42:56','ab72b3ec-8f87-4038-833b-7c27be0b2d2e'),(168,10,73,NULL,24,1,'2023-11-04 15:42:56','2023-11-04 15:42:56','19603bd6-0905-40e0-91ab-7bfebd5b9d2e'),(169,8,74,NULL,6,1,'2023-11-04 15:42:56','2023-11-04 15:42:56','3b1e9412-720f-4800-afb6-63b196c952d0'),(170,11,74,NULL,15,1,'2023-11-04 15:42:56','2023-11-04 15:42:56','3c439d64-47e8-4d8a-8604-86734e29ee42'),(171,10,74,NULL,24,1,'2023-11-04 15:42:56','2023-11-04 15:42:56','d7f0dfe6-5972-4712-8673-b91aba249dd6'),(172,8,75,NULL,6,1,'2023-11-04 15:42:59','2023-11-04 15:42:59','3b152da1-0763-4a28-8514-9b40c87baef8'),(173,11,75,NULL,15,1,'2023-11-04 15:42:59','2023-11-04 15:42:59','9c76dd9a-d4f8-4d18-8e2f-6a6020169ba4'),(174,10,75,NULL,24,1,'2023-11-04 15:42:59','2023-11-04 15:42:59','cbe58ad6-a90d-4637-aea9-70ab5b89a8d5'),(175,8,76,NULL,6,1,'2023-11-04 15:42:59','2023-11-04 15:42:59','97239d58-e458-41a2-897e-7f3719518d39'),(176,11,76,NULL,15,1,'2023-11-04 15:42:59','2023-11-04 15:42:59','c914d261-0a32-4d50-9797-9c999d4ce399'),(177,10,76,NULL,24,1,'2023-11-04 15:42:59','2023-11-04 15:42:59','833b7fb2-be9a-4f9a-9b09-be64d137cd2f'),(178,8,77,NULL,6,1,'2023-11-04 15:42:59','2023-11-04 15:42:59','db697bf9-6645-4e30-b036-ce1427897f98'),(179,11,77,NULL,15,1,'2023-11-04 15:42:59','2023-11-04 15:42:59','896c6ac0-5a5b-4241-9754-56e2a5c526d6'),(180,10,77,NULL,24,1,'2023-11-04 15:42:59','2023-11-04 15:42:59','fc824bbc-f013-4d5a-8119-779afe4ea692'),(181,8,78,NULL,6,1,'2023-11-04 15:42:59','2023-11-04 15:42:59','51c9b1ef-1270-41af-a19e-c28d4320e159'),(182,11,78,NULL,15,1,'2023-11-04 15:42:59','2023-11-04 15:42:59','59a6ab27-71dc-4e1e-bcf8-6d24f3655d06'),(183,10,78,NULL,24,1,'2023-11-04 15:42:59','2023-11-04 15:42:59','5baa8c1c-997c-4231-ad96-4dd378d7cbae'),(187,8,80,NULL,6,1,'2023-11-04 15:43:14','2023-11-04 15:43:14','e8f55ca9-4b72-4449-9517-6eb38fa7ab9b'),(188,11,80,NULL,15,1,'2023-11-04 15:43:14','2023-11-04 15:43:14','1a4b3e2b-aef1-4159-8d00-7aa72876b3d6'),(189,10,80,NULL,24,1,'2023-11-04 15:43:14','2023-11-04 15:43:14','a442d7eb-7740-40df-8fdd-bdc07562f232'),(190,8,81,NULL,6,1,'2023-11-04 15:43:22','2023-11-04 15:43:22','9b0bbbe0-a6b4-41b5-ba7d-0cf42c2c6fb2'),(191,11,81,NULL,15,1,'2023-11-04 15:43:22','2023-11-04 15:43:22','c1a8a55c-fdd3-4301-9c7e-4ac8587279a7'),(192,10,81,NULL,24,1,'2023-11-04 15:43:22','2023-11-04 15:43:22','a9c262a3-9a69-4166-a3bc-0fe06b7b783d'),(193,8,82,NULL,6,1,'2023-11-04 15:43:22','2023-11-04 15:43:22','92c65831-b6e6-4ed6-8944-65bb55a75aa1'),(194,11,82,NULL,15,1,'2023-11-04 15:43:22','2023-11-04 15:43:22','98bf58fb-8a57-40fe-96eb-e700ccdb2f90'),(195,10,82,NULL,24,1,'2023-11-04 15:43:22','2023-11-04 15:43:22','a1cb70af-fbee-4b06-a51d-b71d1d682a44'),(197,11,83,NULL,13,1,'2023-11-04 15:43:40','2023-11-04 15:43:40','05f5dc14-f300-4432-9cfc-b7bd6dbb37c7'),(199,8,84,NULL,4,1,'2023-11-04 15:43:53','2023-11-04 15:43:53','207d40bb-8b63-43be-824b-7eedca7a9ccb'),(200,11,84,NULL,13,1,'2023-11-04 15:43:53','2023-11-04 15:43:53','625cf6aa-c11d-4945-9785-de5b2b5ad1d3'),(201,10,84,NULL,18,1,'2023-11-04 15:43:53','2023-11-04 15:43:53','d365b6ba-c46a-4f32-8f38-c4391d007fda'),(203,11,85,NULL,13,1,'2023-11-04 15:43:57','2023-11-04 15:43:57','d4b489cd-9ca9-4045-b553-53420491e17e'),(205,8,86,NULL,4,1,'2023-11-04 15:43:57','2023-11-04 15:43:57','4e7130d3-f69d-469b-98c7-aae91291aa84'),(206,11,86,NULL,13,1,'2023-11-04 15:43:57','2023-11-04 15:43:57','58d69e04-b0f1-47a1-b9e7-2f39b0303585'),(207,10,86,NULL,18,1,'2023-11-04 15:43:57','2023-11-04 15:43:57','9fbb6f64-6501-4d8c-b9d0-164364018ab0'),(208,8,87,NULL,4,1,'2023-11-04 15:44:03','2023-11-04 15:44:03','a2fa8b8b-b725-41ba-bd6c-934f4c76c501'),(209,11,87,NULL,13,1,'2023-11-04 15:44:03','2023-11-04 15:44:03','473cecac-3d91-4323-979b-9ced9b82fd8c'),(210,10,87,NULL,18,1,'2023-11-04 15:44:03','2023-11-04 15:44:03','f060a473-ee03-4cdb-bd2a-3c5aeee59139'),(211,8,88,NULL,4,1,'2023-11-04 15:44:03','2023-11-04 15:44:03','cc0a3c70-6036-4ac7-8d0c-ce3fc4cda98f'),(212,11,88,NULL,13,1,'2023-11-04 15:44:03','2023-11-04 15:44:03','76feb4d9-1cdb-45ba-88b4-c9390e222faf'),(213,10,88,NULL,18,1,'2023-11-04 15:44:03','2023-11-04 15:44:03','16f2f03f-0b0e-42ef-9d00-8216ea8cfca5'),(214,8,89,NULL,4,1,'2023-11-04 15:44:03','2023-11-04 15:44:03','9cb0563f-abdb-4693-b792-2065f5aed0f5'),(215,11,89,NULL,13,1,'2023-11-04 15:44:03','2023-11-04 15:44:03','d0f56bf7-a1b5-45f8-a820-24c2603e4b82'),(216,10,89,NULL,18,1,'2023-11-04 15:44:03','2023-11-04 15:44:03','88e56108-0928-47ba-a81c-affd0e8b131e'),(217,8,90,NULL,4,1,'2023-11-04 15:44:03','2023-11-04 15:44:03','3d030cdf-e1e6-40d2-b336-a4a81f951f87'),(218,11,90,NULL,13,1,'2023-11-04 15:44:03','2023-11-04 15:44:03','6c4fae03-1f0d-4f0f-9536-748530372435'),(219,10,90,NULL,18,1,'2023-11-04 15:44:03','2023-11-04 15:44:03','a3624095-55db-4cfe-a2a0-dd162cfcdec0'),(220,8,91,NULL,4,1,'2023-11-04 15:44:10','2023-11-04 15:44:10','bc21cefa-27a9-44ae-b4ac-fd74469f341a'),(221,11,91,NULL,13,1,'2023-11-04 15:44:10','2023-11-04 15:44:10','b2527d0b-4128-47ae-91ea-be3985fcfe1c'),(222,10,91,NULL,18,1,'2023-11-04 15:44:10','2023-11-04 15:44:10','83b21f25-eaa0-4341-a96a-61e9f8204354'),(223,8,92,NULL,4,1,'2023-11-04 15:44:10','2023-11-04 15:44:10','b4ff57d6-deef-4ef9-a065-1e43b171c480'),(224,11,92,NULL,13,1,'2023-11-04 15:44:10','2023-11-04 15:44:10','3a987456-3d40-49f4-87b7-8765627f8b24'),(225,10,92,NULL,18,1,'2023-11-04 15:44:10','2023-11-04 15:44:10','cd1af12b-963e-4f88-a563-9ca17090bc7a'),(227,11,93,NULL,13,1,'2023-11-04 15:44:10','2023-11-04 15:44:10','2f4f6c4a-4637-425c-adda-a117db5a11b1'),(228,10,93,NULL,18,1,'2023-11-04 15:44:10','2023-11-04 15:44:10','e2395d2b-1c0f-4b6f-8387-c8e8f21d0e05'),(229,8,94,NULL,4,1,'2023-11-04 15:44:10','2023-11-04 15:44:10','d152e3ed-24dc-4527-a148-25c93c6d58d4'),(230,11,94,NULL,13,1,'2023-11-04 15:44:10','2023-11-04 15:44:10','404e4a45-1671-4484-b028-ad841a3d9488'),(231,10,94,NULL,18,1,'2023-11-04 15:44:10','2023-11-04 15:44:10','7e9a0b86-4f07-4d74-b907-ff9e1460f639'),(233,11,95,NULL,13,1,'2023-11-04 15:44:10','2023-11-04 15:44:10','ddacfd45-c1be-4ae5-95e2-84fa095a217d'),(235,8,96,NULL,4,1,'2023-11-04 15:44:10','2023-11-04 15:44:10','6cc7ec1e-bdda-485e-88f1-0240bb8d5c4f'),(236,11,96,NULL,13,1,'2023-11-04 15:44:10','2023-11-04 15:44:10','389c611a-8d2f-49ad-a2a6-5693c7759f4a'),(237,10,96,NULL,18,1,'2023-11-04 15:44:10','2023-11-04 15:44:10','cae635f0-1a0a-427e-89a4-5c0d450d866d'),(238,8,97,NULL,4,1,'2023-11-04 15:44:25','2023-11-04 15:44:25','1efb1c06-5041-4a05-bc1a-1c0ada3621a9'),(239,11,97,NULL,13,1,'2023-11-04 15:44:25','2023-11-04 15:44:25','90c4b2d4-bd13-4991-be6b-7f402ee392e4'),(240,10,97,NULL,18,1,'2023-11-04 15:44:25','2023-11-04 15:44:25','5a212408-38da-4c69-aab2-db1c192dbfdf'),(244,8,99,NULL,4,1,'2023-11-04 15:44:34','2023-11-04 15:44:34','ed8e07a1-ffc4-46c5-9d26-7439bdc68cfe'),(245,11,99,NULL,13,1,'2023-11-04 15:44:34','2023-11-04 15:44:34','9504b4b2-a473-4223-85e6-31f6083fbf30'),(246,10,99,NULL,18,1,'2023-11-04 15:44:34','2023-11-04 15:44:34','a5d229c1-8b46-4b3f-91a3-b129f608a33a'),(250,8,101,NULL,4,1,'2023-11-04 15:54:32','2023-11-04 15:54:32','152c8b02-25e5-4b89-a6b8-ca8a33cdae4b'),(251,11,101,NULL,13,1,'2023-11-04 15:54:32','2023-11-04 15:54:32','ca73c5d2-82b1-4d97-9d21-413b3884b8a6'),(252,10,101,NULL,18,1,'2023-11-04 15:54:32','2023-11-04 15:54:32','0b7d4463-1cb4-4ea3-a245-fa680161633d'),(256,8,103,NULL,4,1,'2023-11-04 16:21:02','2023-11-04 16:21:02','36d002ce-5f90-49c2-b519-d179301082a9'),(257,11,103,NULL,13,1,'2023-11-04 16:21:02','2023-11-04 16:21:02','d4a06498-1818-4334-bcd8-8b4c7f91ff35'),(258,10,103,NULL,18,1,'2023-11-04 16:21:02','2023-11-04 16:21:02','7dcf490a-2784-499f-a616-2385707d7eed'),(262,8,105,NULL,6,1,'2023-11-04 17:13:06','2023-11-04 17:13:06','bcca9628-a61d-4154-8714-3e0d417105c8'),(263,11,105,NULL,15,1,'2023-11-04 17:13:06','2023-11-04 17:13:06','c54f0aab-0970-4fe3-9e64-2ee5d5755a2d'),(264,10,105,NULL,24,1,'2023-11-04 17:13:06','2023-11-04 17:13:06','cd998ce6-1ab1-497f-b76b-60734f13d94c'),(268,8,107,NULL,6,1,'2023-11-04 17:13:15','2023-11-04 17:13:15','300e7fda-ac87-44bb-9b8d-569c88790277'),(269,11,107,NULL,15,1,'2023-11-04 17:13:15','2023-11-04 17:13:15','51bd8eef-3601-4422-9f46-d78aeadf48b3'),(270,10,107,NULL,24,1,'2023-11-04 17:13:15','2023-11-04 17:13:15','38a9ec2d-a386-42b3-a924-a71cf437f9fc'),(271,8,108,NULL,6,1,'2023-11-04 17:13:34','2023-11-04 17:13:34','37e0d054-ce8c-4b2c-84ce-b736ff285a2f'),(272,11,108,NULL,15,1,'2023-11-04 17:13:34','2023-11-04 17:13:34','038f02a1-0d39-4aff-a75f-c3301af15a22'),(273,10,108,NULL,24,1,'2023-11-04 17:13:34','2023-11-04 17:13:34','71234001-96a5-4485-abb2-eb8f038f06f1'),(277,8,110,NULL,4,1,'2023-11-04 17:13:47','2023-11-04 17:13:47','f0b66577-9015-4d87-b9fe-de8db8be24ef'),(278,11,110,NULL,13,1,'2023-11-04 17:13:47','2023-11-04 17:13:47','547041f8-3783-4f7a-b051-a587bf8448a4'),(279,10,110,NULL,18,1,'2023-11-04 17:13:47','2023-11-04 17:13:47','ee23573e-bedd-48ed-a008-c07811847a96'),(283,8,112,NULL,4,1,'2023-11-04 17:14:08','2023-11-04 17:14:08','c989251a-fcb4-40cc-80c3-b0d49e13ef89'),(284,11,112,NULL,13,1,'2023-11-04 17:14:08','2023-11-04 17:14:08','d41f3a50-4335-4784-993e-0fa5f66ac5c5'),(285,10,112,NULL,18,1,'2023-11-04 17:14:08','2023-11-04 17:14:08','06158002-26fc-429b-a65f-fc9cba673850'),(289,8,114,NULL,4,1,'2023-11-04 17:14:18','2023-11-04 17:14:18','7c86664a-0776-43a8-a440-3233da37ed21'),(290,11,114,NULL,13,1,'2023-11-04 17:14:18','2023-11-04 17:14:18','8ccd21b4-5d28-4705-b84d-529ce8a78fa0'),(291,10,114,NULL,18,1,'2023-11-04 17:14:18','2023-11-04 17:14:18','23aa6531-9984-4485-ba88-fe615c545e1f'),(295,8,116,NULL,6,1,'2023-11-04 17:19:47','2023-11-04 17:19:47','7141db19-3555-41cd-a25e-7bfe18948b3c'),(296,11,116,NULL,15,1,'2023-11-04 17:19:47','2023-11-04 17:19:47','9b57e240-2e83-44e9-a9e5-f07caf458512'),(297,10,116,NULL,24,1,'2023-11-04 17:19:47','2023-11-04 17:19:47','179409cd-c7d4-4636-b156-d7d7da91d407'),(302,8,93,NULL,118,1,'2023-11-09 17:34:47','2023-11-09 17:34:47','f970c36a-3ac4-4e22-8dad-89e6a6f5f6fa'),(303,8,122,NULL,118,1,'2023-11-09 17:34:47','2023-11-09 17:34:47','25f58002-0496-4cde-9ba3-5fffb572ea11'),(304,11,122,NULL,13,1,'2023-11-09 17:34:47','2023-11-09 17:34:47','8aba7dde-13d4-4155-aa6e-5dbebf855614'),(305,10,122,NULL,18,1,'2023-11-09 17:34:47','2023-11-09 17:34:47','a872911b-d300-4ab0-965f-16a9bed1880d'),(309,8,124,NULL,4,1,'2023-11-09 17:34:59','2023-11-09 17:34:59','9d1c6ef6-c6e5-44a8-a763-b7a4c490f422'),(310,11,124,NULL,13,1,'2023-11-09 17:34:59','2023-11-09 17:34:59','ea55a5e6-bc9a-4431-b3a4-1351189fd4ff'),(311,10,124,NULL,18,1,'2023-11-09 17:34:59','2023-11-09 17:34:59','951ed0f0-5817-4977-8d42-efc3ac2fa85b'),(315,8,126,NULL,4,1,'2023-11-09 17:40:09','2023-11-09 17:40:09','dbae2a97-8629-46aa-82ef-9c0cd527fa78'),(316,11,126,NULL,13,1,'2023-11-09 17:40:09','2023-11-09 17:40:09','51f3d2b3-6469-4bf8-9c30-29ba8ba4ad2e'),(317,10,126,NULL,18,1,'2023-11-09 17:40:09','2023-11-09 17:40:09','154f968c-233d-4496-b488-e43e5510c2e3'),(321,8,128,NULL,118,1,'2023-11-09 17:51:26','2023-11-09 17:51:26','d653b851-413a-4c63-951a-0b2703ec4cb6'),(322,11,128,NULL,13,1,'2023-11-09 17:51:26','2023-11-09 17:51:26','ddf18795-b43f-466c-9b7f-98ee59cbc777'),(323,10,128,NULL,18,1,'2023-11-09 17:51:26','2023-11-09 17:51:26','71e58626-3940-4ff2-8554-2bbb5365d5ed'),(327,8,130,NULL,4,1,'2023-11-10 09:26:37','2023-11-10 09:26:37','a6fd5495-f2aa-48ef-850b-1585d20a28cf'),(328,11,130,NULL,13,1,'2023-11-10 09:26:37','2023-11-10 09:26:37','ac1c0279-89ab-45e3-8f3f-c095cc6788d1'),(329,10,130,NULL,18,1,'2023-11-10 09:26:37','2023-11-10 09:26:37','cc5b74fa-cac0-467d-b455-5fa74eb84a35'),(333,8,132,NULL,6,1,'2023-11-10 09:27:01','2023-11-10 09:27:01','b26d14ac-73b2-4548-bf23-8b4c792157ee'),(334,11,132,NULL,15,1,'2023-11-10 09:27:01','2023-11-10 09:27:01','aa3bec02-05c8-41b7-a6ff-3bc62feb84c8'),(335,10,132,NULL,24,1,'2023-11-10 09:27:01','2023-11-10 09:27:01','a97222a8-27c3-487c-a4cf-e801829f1022'),(336,8,133,NULL,118,1,'2023-11-10 09:30:34','2023-11-10 09:30:34','dc35995d-5fdf-4ec0-b1a7-02618b2159b5'),(337,8,134,NULL,118,1,'2023-11-10 09:30:49','2023-11-10 09:30:49','5aef591b-adc8-4037-9acd-a6b7f622fb16'),(338,8,135,NULL,118,1,'2023-11-10 09:30:50','2023-11-10 09:30:50','871998db-24d0-4395-ba17-cbbc43795172'),(339,11,133,NULL,134,1,'2023-11-10 09:30:53','2023-11-10 09:30:53','663c0e10-9c55-469d-a5e3-44c392d27cab'),(340,10,133,NULL,24,1,'2023-11-10 09:30:55','2023-11-10 09:30:55','189f86e0-57bf-487a-97de-3eda430fa1c1'),(341,8,136,NULL,118,1,'2023-11-10 09:31:06','2023-11-10 09:31:06','9fcf4973-61f2-4580-a408-f5f2d0cff6ae'),(342,11,136,NULL,134,1,'2023-11-10 09:31:06','2023-11-10 09:31:06','1a141a32-4764-442d-8167-0c1684083367'),(343,10,136,NULL,24,1,'2023-11-10 09:31:06','2023-11-10 09:31:06','e893914c-41de-4ada-9cd5-90ec853390cb'),(347,8,138,NULL,118,1,'2023-11-10 09:31:16','2023-11-10 09:31:16','d460926b-883f-4d68-941b-447e273d2f5c'),(348,11,138,NULL,134,1,'2023-11-10 09:31:16','2023-11-10 09:31:16','073dba4b-2ce5-46e1-9dc4-1b726b0a6c52'),(349,10,138,NULL,24,1,'2023-11-10 09:31:16','2023-11-10 09:31:16','af3c890a-99bb-4bfa-8f16-884a29781bb9'),(353,8,140,NULL,6,1,'2023-11-10 10:20:07','2023-11-10 10:20:07','87a9c8ee-cf4a-483f-89ab-6b8a72c3ab68'),(354,11,140,NULL,15,1,'2023-11-10 10:20:07','2023-11-10 10:20:07','0e93d669-6bce-44e4-8239-371a6b72e1cd'),(355,10,140,NULL,24,1,'2023-11-10 10:20:07','2023-11-10 10:20:07','c388ac23-57af-45e6-b1b7-7800ae49e110'),(356,8,147,NULL,118,1,'2023-11-11 10:20:29','2023-11-11 10:20:29','fdef34f9-6fe0-437d-b335-b36d314031a8'),(357,11,147,NULL,134,1,'2023-11-11 10:20:29','2023-11-11 10:20:29','bbf144a5-ea4b-4deb-b65f-c5933ba52176'),(358,10,147,NULL,24,1,'2023-11-11 10:20:29','2023-11-11 10:20:29','331ad5ca-f5ee-41b9-bf31-048266d898e8'),(362,8,149,NULL,4,1,'2023-11-11 10:20:54','2023-11-11 10:20:54','13427454-94a8-4fe9-8c81-e7636be03883'),(363,11,149,NULL,13,1,'2023-11-11 10:20:54','2023-11-11 10:20:54','f0fc1695-dc77-454f-884f-f7ae224c304e'),(364,10,149,NULL,18,1,'2023-11-11 10:20:54','2023-11-11 10:20:54','1a002f2e-721b-46fd-98d2-0a3b72b4d1d0'),(370,8,95,NULL,6,1,'2023-11-11 10:21:13','2023-11-11 10:21:13','c5c7e563-82a5-4775-8731-36dd6e8cae28'),(371,10,95,NULL,24,1,'2023-11-11 10:21:13','2023-11-11 10:21:13','3f6d5001-9e33-49b3-ac3e-2ba1cb58a9fe'),(372,8,151,NULL,6,1,'2023-11-11 10:21:13','2023-11-11 10:21:13','23fc094b-87d6-4d5f-bf86-66f2451ffcee'),(373,11,151,NULL,13,1,'2023-11-11 10:21:13','2023-11-11 10:21:13','14551419-3afe-4f49-b885-af611ec58df6'),(374,10,151,NULL,24,1,'2023-11-11 10:21:13','2023-11-11 10:21:13','ac78b536-9c06-4cd1-998c-ca321f65ba53'),(378,8,153,NULL,6,1,'2023-11-11 10:21:29','2023-11-11 10:21:29','ea6a3f1d-f624-4584-a27c-2b6db2a7db35'),(379,11,153,NULL,13,1,'2023-11-11 10:21:29','2023-11-11 10:21:29','5fd18b65-a93f-4c1c-a83e-bd93a0dc9366'),(380,10,153,NULL,24,1,'2023-11-11 10:21:29','2023-11-11 10:21:29','38bc2336-5feb-4c33-9336-bec5b2d98e0d'),(386,8,83,NULL,6,1,'2023-11-11 10:22:20','2023-11-11 10:22:20','876acc82-114d-43ee-a133-2699e6f67a64'),(387,10,83,NULL,24,1,'2023-11-11 10:22:20','2023-11-11 10:22:20','3277478a-039c-404f-b7e5-b41e60f75119'),(388,8,155,NULL,6,1,'2023-11-11 10:22:20','2023-11-11 10:22:20','84172f53-9c04-414c-a9eb-3dabf9795995'),(389,11,155,NULL,13,1,'2023-11-11 10:22:20','2023-11-11 10:22:20','f39a8cb0-52c9-45bf-8e05-a223d5753afe'),(390,10,155,NULL,24,1,'2023-11-11 10:22:20','2023-11-11 10:22:20','7a0bc492-d738-4a2a-a539-680264e19cc3'),(396,8,85,NULL,6,1,'2023-11-11 10:22:59','2023-11-11 10:22:59','993de2cc-8d76-48c8-b995-5ba9b6bcf42d'),(397,10,85,NULL,24,1,'2023-11-11 10:22:59','2023-11-11 10:22:59','947ef466-e7a4-43d1-8ffb-a9c83082825a'),(398,8,157,NULL,6,1,'2023-11-11 10:22:59','2023-11-11 10:22:59','92187c7a-1ad1-4ce9-b443-dc0c13d345bf'),(399,11,157,NULL,13,1,'2023-11-11 10:22:59','2023-11-11 10:22:59','93183495-4336-4cc4-903c-c025ebf8160c'),(400,10,157,NULL,24,1,'2023-11-11 10:22:59','2023-11-11 10:22:59','57b48302-53e7-4f89-a78f-8be5a01155d5'),(404,8,159,NULL,4,1,'2023-11-11 10:23:22','2023-11-11 10:23:22','c59d4373-a649-402d-96e6-cf79eb17365f'),(405,11,159,NULL,13,1,'2023-11-11 10:23:22','2023-11-11 10:23:22','c4c287a2-f8cc-47e4-83d3-7a5f76cd5fd2'),(406,10,159,NULL,18,1,'2023-11-11 10:23:22','2023-11-11 10:23:22','17f0c1eb-ad25-4e80-bf24-83325bb3b4c6'),(410,8,161,NULL,4,1,'2023-11-11 10:23:42','2023-11-11 10:23:42','dc22ccf2-c297-40a5-86ba-c431b016760f'),(411,11,161,NULL,13,1,'2023-11-11 10:23:42','2023-11-11 10:23:42','76d18686-b3f2-444a-9909-5ca57a60adf1'),(412,10,161,NULL,18,1,'2023-11-11 10:23:42','2023-11-11 10:23:42','a10a918d-0d19-429a-94c0-e29616c592bd'),(416,8,163,NULL,6,1,'2023-11-11 10:23:58','2023-11-11 10:23:58','6e822356-1d6a-4048-81c8-9dc727ab00d6'),(417,11,163,NULL,15,1,'2023-11-11 10:23:58','2023-11-11 10:23:58','515a0534-f80a-4eb0-8d44-1370dfec0bfa'),(418,10,163,NULL,24,1,'2023-11-11 10:23:58','2023-11-11 10:23:58','94705197-ce98-45a9-9b62-d974109baab3'),(419,8,170,NULL,4,1,'2023-11-12 16:37:46','2023-11-12 16:37:46','4052b620-c8f2-4e0d-8ebd-1e31703ac65e'),(420,11,170,NULL,13,1,'2023-11-12 16:37:46','2023-11-12 16:37:46','fe9e744b-8e73-4884-970b-ad600b4140ea'),(421,10,170,NULL,18,1,'2023-11-12 16:37:46','2023-11-12 16:37:46','2f6b2711-6a14-4ad2-b4e1-e4edcaa477d6'),(422,8,171,NULL,4,1,'2023-11-12 16:37:46','2023-11-12 16:37:46','81c950eb-e60a-4580-b54b-905d733d1c67'),(423,11,171,NULL,13,1,'2023-11-12 16:37:46','2023-11-12 16:37:46','ec5e6513-ba62-4cae-acd1-8294673afe0e'),(424,10,171,NULL,18,1,'2023-11-12 16:37:46','2023-11-12 16:37:46','22fe03d5-5130-4252-956a-390e47ef9d3e'),(425,8,172,NULL,4,1,'2023-11-12 16:37:53','2023-11-12 16:37:53','f3eaadd2-f3c6-4843-b2f4-d42be6c25eb7'),(426,11,172,NULL,13,1,'2023-11-12 16:37:53','2023-11-12 16:37:53','ebcc31f8-ebb8-4af4-8492-48e8f2786854'),(427,10,172,NULL,18,1,'2023-11-12 16:37:53','2023-11-12 16:37:53','03416eed-aa0e-41f6-ae0c-450c8d4e5df5'),(428,8,173,NULL,4,1,'2023-11-12 16:37:53','2023-11-12 16:37:53','a1d79074-5523-4d77-844e-27562eada256'),(429,11,173,NULL,13,1,'2023-11-12 16:37:53','2023-11-12 16:37:53','c84049d5-57e1-4a08-a1c2-546be964f270'),(430,10,173,NULL,18,1,'2023-11-12 16:37:53','2023-11-12 16:37:53','a31e522c-c1d7-4da4-8dc2-9323c3d75cae'),(434,8,175,NULL,4,1,'2023-11-12 16:39:01','2023-11-12 16:39:01','2c39e567-1b3c-4f66-b7c9-70d2f8ffe85f'),(435,11,175,NULL,13,1,'2023-11-12 16:39:01','2023-11-12 16:39:01','8182c1fb-ef9f-4697-a90f-cc4340161a17'),(436,10,175,NULL,18,1,'2023-11-12 16:39:01','2023-11-12 16:39:01','a450d962-2bcb-4315-8eee-7e78338f687a'),(437,8,176,NULL,4,1,'2023-11-12 16:40:16','2023-11-12 16:40:16','bd1701ef-8397-4591-b69b-6a40862ee1ec'),(438,11,176,NULL,13,1,'2023-11-12 16:40:16','2023-11-12 16:40:16','9b1c15fd-1d37-4c0a-b014-f6ca1c391cfb'),(439,10,176,NULL,18,1,'2023-11-12 16:40:16','2023-11-12 16:40:16','e9c4093f-6530-407f-ad70-ce8ded01a46c'),(440,8,177,NULL,4,1,'2023-11-12 16:40:16','2023-11-12 16:40:16','6b8b0fac-5d89-4712-8c3a-02be8d1d10ee'),(441,11,177,NULL,13,1,'2023-11-12 16:40:16','2023-11-12 16:40:16','03ee6dff-b955-444d-aa19-01b38e5655ef'),(442,10,177,NULL,18,1,'2023-11-12 16:40:16','2023-11-12 16:40:16','78745e25-2287-4078-8fde-feba94c43776'),(446,8,179,NULL,4,1,'2023-11-12 16:40:44','2023-11-12 16:40:44','05ad297b-110b-4c61-aeef-679f3bf6c5d4'),(447,11,179,NULL,13,1,'2023-11-12 16:40:44','2023-11-12 16:40:44','3e11ecea-d18a-496e-bfa0-b035ea837207'),(448,10,179,NULL,18,1,'2023-11-12 16:40:44','2023-11-12 16:40:44','0b5d1810-caf5-417b-8795-6991536b5752'),(452,8,181,NULL,4,1,'2023-11-12 16:41:15','2023-11-12 16:41:15','4dae2694-4c99-4d9e-8a94-d46d8732024a'),(453,11,181,NULL,13,1,'2023-11-12 16:41:15','2023-11-12 16:41:15','b7e4b968-774d-4797-8d92-f4e414f6d887'),(454,10,181,NULL,18,1,'2023-11-12 16:41:15','2023-11-12 16:41:15','d7872e36-e6cf-4015-bb59-573ea9cc05f5'),(458,8,183,NULL,4,1,'2023-11-12 16:41:25','2023-11-12 16:41:25','1a3e6ee6-1966-4af1-acb0-35df12694874'),(459,11,183,NULL,13,1,'2023-11-12 16:41:25','2023-11-12 16:41:25','78ab0951-e588-4cda-9ebe-57f8e820059f'),(460,10,183,NULL,18,1,'2023-11-12 16:41:25','2023-11-12 16:41:25','0e255b4e-934b-419f-b453-8957fb7854ec'),(461,8,186,NULL,4,1,'2023-11-12 16:42:21','2023-11-12 16:42:21','7d3bfda9-94ea-445d-ae6e-67daf5477970'),(462,11,186,NULL,13,1,'2023-11-12 16:42:21','2023-11-12 16:42:21','37e43c40-2a54-40b7-84d5-2a190398e977'),(463,10,186,NULL,18,1,'2023-11-12 16:42:21','2023-11-12 16:42:21','8849524d-c3f5-43e2-b280-e92f84d50441'),(464,8,187,NULL,4,1,'2023-11-12 16:42:21','2023-11-12 16:42:21','93b5e588-1577-453a-8d85-6ec2ffab3e3d'),(465,11,187,NULL,13,1,'2023-11-12 16:42:21','2023-11-12 16:42:21','59d85d39-24fa-4a4d-86b3-072f9b63b76d'),(466,10,187,NULL,18,1,'2023-11-12 16:42:21','2023-11-12 16:42:21','9e485660-1c8b-403a-b450-c6320e8844be'),(467,8,188,NULL,4,1,'2023-11-12 16:42:50','2023-11-12 16:42:50','f74f90ed-0c6c-496b-bcaf-eaff149d4b74'),(468,11,188,NULL,13,1,'2023-11-12 16:42:50','2023-11-12 16:42:50','532c267d-1545-424a-a9ba-ba2fa3da7058'),(469,10,188,NULL,18,1,'2023-11-12 16:42:50','2023-11-12 16:42:50','7325d8bc-9e5b-435e-b994-59edebb727cd'),(470,8,189,NULL,4,1,'2023-11-12 16:42:50','2023-11-12 16:42:50','488b5b62-15d8-45a2-9954-4ebcfc819c11'),(471,11,189,NULL,13,1,'2023-11-12 16:42:50','2023-11-12 16:42:50','0a579d32-be7a-473a-bfed-1f9912226e73'),(472,10,189,NULL,18,1,'2023-11-12 16:42:50','2023-11-12 16:42:50','0f4e35f3-2def-4c74-9ddd-666bccb822c7'),(476,8,191,NULL,4,1,'2023-11-12 16:43:15','2023-11-12 16:43:15','2f9e4937-1314-4c5f-87c8-4d28129b6745'),(477,11,191,NULL,13,1,'2023-11-12 16:43:15','2023-11-12 16:43:15','1e1e1061-d6a2-4381-b417-cafe25f6e0b4'),(478,10,191,NULL,18,1,'2023-11-12 16:43:15','2023-11-12 16:43:15','16fdbe3a-a88b-4b86-91a4-ac683d2865fc'),(479,8,192,NULL,4,1,'2023-11-12 16:43:29','2023-11-12 16:43:29','ecf64675-431e-4e1e-baf2-aaf0dba03d6d'),(480,11,192,NULL,13,1,'2023-11-12 16:43:29','2023-11-12 16:43:29','d2cec26d-84e1-44af-9cf3-3abbcce5a148'),(481,10,192,NULL,18,1,'2023-11-12 16:43:29','2023-11-12 16:43:29','992b8ac7-5669-41a3-a028-6634e767eaa2'),(482,8,193,NULL,4,1,'2023-11-12 16:43:29','2023-11-12 16:43:29','d875e33f-4cb3-43f7-95c4-f893ce622390'),(483,11,193,NULL,13,1,'2023-11-12 16:43:29','2023-11-12 16:43:29','7546aed7-45c2-4aae-9046-f51e095fa092'),(484,10,193,NULL,18,1,'2023-11-12 16:43:29','2023-11-12 16:43:29','f5512dd6-d167-40e7-bcf3-8de68fab2805'),(485,8,194,NULL,4,1,'2023-11-12 16:52:34','2023-11-12 16:52:34','65a88925-4dd6-401d-84d0-1a19c99fb08f'),(486,11,194,NULL,13,1,'2023-11-12 16:52:34','2023-11-12 16:52:34','5183dfb9-8bc8-485f-a2ba-e6abbe238fbb'),(487,10,194,NULL,18,1,'2023-11-12 16:52:34','2023-11-12 16:52:34','f2cb6b55-ee0f-4608-ab79-49f25676902d'),(488,8,195,NULL,4,1,'2023-11-12 16:52:34','2023-11-12 16:52:34','cf384026-e668-4e08-877c-4fbaeef7cab7'),(489,11,195,NULL,13,1,'2023-11-12 16:52:34','2023-11-12 16:52:34','93a9da60-bab9-48c1-9a9a-93608f48fdaa'),(490,10,195,NULL,18,1,'2023-11-12 16:52:34','2023-11-12 16:52:34','abe51db1-c73b-45da-b75d-f5615a9d1d87'),(491,8,196,NULL,4,1,'2023-11-12 16:52:45','2023-11-12 16:52:45','eaceecd1-b8bd-466e-8e83-9935b895f0e1'),(492,11,196,NULL,13,1,'2023-11-12 16:52:45','2023-11-12 16:52:45','646b499b-d820-48ac-9d01-9bbe912adf3c'),(493,10,196,NULL,18,1,'2023-11-12 16:52:45','2023-11-12 16:52:45','63c5fe60-0e24-41f8-97b1-e1e3c119690b'),(494,8,197,NULL,4,1,'2023-11-12 16:52:45','2023-11-12 16:52:45','bdd767a6-39b3-439e-b974-b36f3ac611cb'),(495,11,197,NULL,13,1,'2023-11-12 16:52:45','2023-11-12 16:52:45','e1d3eba3-c3ca-40d7-9647-d61dcc296d0c'),(496,10,197,NULL,18,1,'2023-11-12 16:52:45','2023-11-12 16:52:45','cad20ad5-eb6f-43f9-9d8c-6b8fff6eef02'),(497,8,198,NULL,4,1,'2023-11-12 16:53:24','2023-11-12 16:53:24','ff7d111f-2a7f-4461-ae49-f00ad9bb41de'),(498,11,198,NULL,13,1,'2023-11-12 16:53:24','2023-11-12 16:53:24','f27186ff-9ff0-4c81-8a1d-f23addfae79d'),(499,10,198,NULL,18,1,'2023-11-12 16:53:24','2023-11-12 16:53:24','ea092730-0df1-41ad-a626-d3af6205a983'),(500,8,199,NULL,4,1,'2023-11-12 16:53:24','2023-11-12 16:53:24','33f52875-07b0-4e9f-a0bd-8b8f67026e48'),(501,11,199,NULL,13,1,'2023-11-12 16:53:24','2023-11-12 16:53:24','ff575f10-2d3b-449c-afbe-470c2344bb73'),(502,10,199,NULL,18,1,'2023-11-12 16:53:24','2023-11-12 16:53:24','1b4dda3a-c7f3-4dbc-b5a2-743776616a5c'),(504,8,208,NULL,6,1,'2023-11-15 19:17:03','2023-11-15 19:17:03','702332b2-958e-4b22-8d05-20ee17e4f3ef'),(505,8,211,NULL,6,1,'2023-11-15 19:17:03','2023-11-15 19:17:03','7ec27066-e644-492e-bec1-ee2a1844b1b9'),(506,8,212,NULL,6,1,'2023-11-15 19:19:47','2023-11-15 19:19:47','90598ee4-4ff4-4709-92f3-26081281ac23'),(507,8,213,NULL,6,1,'2023-11-15 19:19:53','2023-11-15 19:19:53','df3199f2-2681-4659-9e4d-96a8222946c0'),(508,8,216,NULL,6,1,'2023-11-15 19:26:26','2023-11-15 19:26:26','9df07d48-6fe8-4046-9fb6-bbae80d46db9'),(509,8,217,NULL,6,1,'2023-11-15 19:28:48','2023-11-15 19:28:48','a2473eaf-1410-4295-8c3b-a59006dae93a'),(510,8,220,NULL,118,1,'2023-11-15 19:34:51','2023-11-15 19:34:51','634d9804-2716-48d9-b09e-b950c687deb8'),(511,8,222,NULL,118,1,'2023-11-15 19:34:51','2023-11-15 19:34:51','bd244c6b-938b-45a7-9c4b-8e966d810c16'),(513,8,223,NULL,203,1,'2023-11-15 19:34:56','2023-11-15 19:34:56','86523426-2d70-4d80-aa54-ddfa036457fe'),(514,8,205,NULL,6,1,'2023-11-15 19:35:04','2023-11-15 19:35:04','1d2e63cb-de45-4ba9-a5cb-b269f4c6fde3'),(515,8,224,NULL,6,1,'2023-11-15 19:35:04','2023-11-15 19:35:04','3d2ed920-314d-4fcb-8b4d-96d5b5ee5b86');
/*!40000 ALTER TABLE `relations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `resourcepaths`
--

DROP TABLE IF EXISTS `resourcepaths`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `resourcepaths` (
  `hash` varchar(255) NOT NULL,
  `path` varchar(255) NOT NULL,
  PRIMARY KEY (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `resourcepaths`
--

LOCK TABLES `resourcepaths` WRITE;
/*!40000 ALTER TABLE `resourcepaths` DISABLE KEYS */;
INSERT INTO `resourcepaths` VALUES ('11c7ed3c','@craft/web/assets/deprecationerrors/dist'),('1dc938b','@craft/web/assets/jqueryui/dist'),('1fa74520','@craft/web/assets/fileupload/dist'),('2e4403c0','@craft/web/assets/dashboard/dist'),('354300b3','@craft/web/assets/edituser/dist'),('3a92814f','@craft/web/assets/htmx/dist'),('4c2272b9','@craft/web/assets/vue/dist'),('4c7a82e6','@craft/web/assets/editsection/dist'),('509a363e','@craft/web/assets/systemmessages/dist'),('539e2192','@craft/web/assets/datepickeri18n/dist'),('5707250b','@craft/web/assets/feed/dist'),('571ee573','@craft/web/assets/clearcaches/dist'),('5802aae2','@craft/web/assets/velocity/dist'),('5d95a855','@craft/web/assets/jquerypayment/dist'),('5dc67737','@craft/web/assets/jquerytouchevents/dist'),('61ce728b','@craft/web/assets/picturefill/dist'),('62853f43','@craft/web/assets/dbbackup/dist'),('6812184f','@craft/web/assets/craftsupport/dist'),('6a76cf8b','@craft/web/assets/xregexp/dist'),('6ebc8237','@craft/web/assets/timepicker/dist'),('88d1f53d','@craft/web/assets/queuemanager/dist'),('8f320f1d','@craft/web/assets/utilities/dist'),('9f189923','@craft/web/assets/fabric/dist'),('af293478','@craft/web/assets/graphiql/dist'),('b3b039d','@bower/jquery/dist'),('b7aaae34','@craft/web/assets/garnish/dist'),('c2fdcd1f','@craft/web/assets/fieldsettings/dist'),('c4941829','@craft/web/assets/iframeresizer/dist'),('c691ba1d','@craft/web/assets/generalsettings/dist'),('cfbeee46','@craft/web/assets/updateswidget/dist'),('cff5119e','@craft/web/assets/d3/dist'),('d5c037d7','@craft/web/assets/cp/dist'),('d988959f','@craft/web/assets/selectize/dist'),('dcbb07aa','@craft/web/assets/pluginstore/dist'),('de9d2fbd','@craft/web/assets/tailwindreset/dist'),('e9f13971','@craft/web/assets/axios/dist'),('edb1c75','@craft/web/assets/elementresizedetector/dist'),('f104ac28','@craft/web/assets/recententries/dist'),('f283c47c','@craft/web/assets/conditionbuilder/dist'),('fc465300','@craft/web/assets/findreplace/dist');
/*!40000 ALTER TABLE `resourcepaths` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `revisions`
--

DROP TABLE IF EXISTS `revisions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `revisions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int NOT NULL,
  `creatorId` int DEFAULT NULL,
  `num` int NOT NULL,
  `notes` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_pnzvdgsupwidscslekscauptqdoxtacfydni` (`canonicalId`,`num`),
  KEY `fk_irsqihkfcrxdgczrckythajyshbbozgjhkbe` (`creatorId`),
  CONSTRAINT `fk_irsqihkfcrxdgczrckythajyshbbozgjhkbe` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_vzxnwlygeugrwicuyfpzcpugeelbluupllhr` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=118 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `revisions`
--

LOCK TABLES `revisions` WRITE;
/*!40000 ALTER TABLE `revisions` DISABLE KEYS */;
INSERT INTO `revisions` VALUES (1,2,1,1,''),(2,4,1,1,''),(3,6,1,1,''),(4,9,1,1,''),(5,11,1,1,''),(6,13,1,1,''),(7,15,1,1,''),(8,18,1,1,''),(9,2,1,2,'Applied “Draft 1”'),(10,2,1,3,'Applied “Draft 1”'),(11,24,1,1,''),(12,9,1,2,'Applied “Draft 1”'),(13,11,1,2,'Applied “Draft 1”'),(14,9,1,3,'Applied “Draft 1”'),(15,31,1,1,''),(16,33,1,1,''),(17,33,1,2,'Applied “Draft 1”'),(18,38,1,1,''),(19,37,1,1,''),(20,41,1,1,''),(21,43,1,1,NULL),(22,45,1,1,NULL),(23,47,1,1,NULL),(24,49,1,1,NULL),(25,51,1,1,''),(26,53,1,1,NULL),(27,55,1,1,NULL),(28,57,1,1,NULL),(29,59,1,1,NULL),(30,61,1,1,NULL),(31,63,1,1,NULL),(32,65,1,1,NULL),(33,67,1,1,''),(34,69,1,1,NULL),(35,67,1,2,'Applied “Draft 1”'),(36,73,1,1,NULL),(37,75,1,1,NULL),(38,77,1,1,NULL),(39,75,1,2,'Applied “Draft 1”'),(40,81,1,1,NULL),(41,83,1,1,''),(42,85,1,1,NULL),(43,87,1,1,NULL),(44,89,1,1,NULL),(45,91,1,1,NULL),(46,93,1,1,NULL),(47,95,1,1,NULL),(48,93,1,2,''),(49,95,1,2,'Applied “Draft 1”'),(50,2,1,4,'Applied “Draft 1”'),(51,93,1,3,'Applied “Draft 1”'),(52,77,1,2,'Applied “Draft 1”'),(53,73,1,2,'Applied “Draft 1”'),(54,77,1,3,''),(55,89,1,2,'Applied “Draft 1”'),(56,87,1,2,'Applied “Draft 1”'),(57,91,1,2,'Applied “Draft 1”'),(58,57,1,2,'Applied “Draft 1”'),(59,118,1,1,''),(60,93,1,4,'Applied “Draft 1”'),(61,95,1,3,'Applied “Draft 1”'),(62,89,1,3,'Applied “Draft 1”'),(63,93,1,5,'Applied “Draft 1”'),(64,91,1,3,'Applied “Draft 1”'),(65,75,1,3,'Applied “Draft 1”'),(66,134,1,1,''),(67,133,1,1,''),(68,133,1,2,'Applied “Draft 1”'),(69,11,1,3,'Applied “Draft 1”'),(70,6,1,2,'Applied “Draft 1”'),(71,118,1,2,'Applied “Draft 1”'),(72,4,1,2,'Applied “Draft 1”'),(73,133,1,3,''),(74,83,1,2,'Applied “Draft 1”'),(75,95,1,4,'Applied “Draft 1”'),(76,95,1,5,'Applied “Draft 1”'),(77,83,1,3,'Applied “Draft 1”'),(78,85,1,2,'Applied “Draft 1”'),(79,87,1,3,'Applied “Draft 1”'),(80,91,1,4,'Applied “Draft 1”'),(81,9,1,4,'Applied “Draft 1”'),(82,118,121,3,'Applied “Draft 1”'),(83,6,121,3,'Applied “Draft 1”'),(84,4,121,3,'Applied “Draft 1”'),(85,170,1,1,NULL),(86,172,1,1,NULL),(87,172,1,2,'Applied “Draft 1”'),(88,176,1,1,NULL),(89,170,1,2,'Applied “Draft 1”'),(90,172,1,3,'Applied “Draft 1”'),(91,176,1,2,'Applied “Draft 1”'),(92,186,1,1,NULL),(93,188,1,1,NULL),(94,186,1,2,'Applied “Draft 1”'),(95,192,1,1,NULL),(96,194,1,1,NULL),(97,196,1,1,NULL),(98,198,NULL,1,NULL),(99,118,121,4,NULL),(100,118,121,5,NULL),(101,203,121,1,NULL),(102,205,121,1,NULL),(103,205,121,2,NULL),(104,208,121,1,NULL),(105,208,1,2,'Applied “Draft 1”'),(106,208,121,3,NULL),(107,208,121,4,NULL),(108,205,121,3,NULL),(109,205,121,4,NULL),(110,208,121,5,NULL),(111,208,121,6,NULL),(112,205,121,5,NULL),(113,205,121,6,NULL),(114,220,121,1,NULL),(115,220,121,2,NULL),(116,205,121,7,NULL),(117,205,121,8,NULL);
/*!40000 ALTER TABLE `revisions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `searchindex`
--

DROP TABLE IF EXISTS `searchindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `searchindex` (
  `elementId` int NOT NULL,
  `attribute` varchar(25) NOT NULL,
  `fieldId` int NOT NULL,
  `siteId` int NOT NULL,
  `keywords` text NOT NULL,
  PRIMARY KEY (`elementId`,`attribute`,`fieldId`,`siteId`),
  FULLTEXT KEY `idx_ecfolbfczfvewyhhwvuxirwzfuvqsqbrjjvf` (`keywords`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `searchindex`
--

LOCK TABLES `searchindex` WRITE;
/*!40000 ALTER TABLE `searchindex` DISABLE KEYS */;
INSERT INTO `searchindex` VALUES (1,'email',0,1,' hello emagine ie '),(1,'firstname',0,1,' aaron '),(1,'fullname',0,1,' aaron jay '),(1,'lastname',0,1,' jay '),(1,'slug',0,1,''),(1,'username',0,1,' admin '),(2,'slug',0,1,' entry 1 '),(2,'title',0,1,' entry 1 '),(4,'slug',0,1,' hub 367 '),(4,'title',0,1,' hub 367 '),(6,'slug',0,1,' diocletian museum '),(6,'title',0,1,' diocletian museum '),(8,'slug',0,1,' temp iuuftuboqfzmycvibtkzyqagtgmwheocdalt '),(8,'title',0,1,''),(9,'slug',0,1,' entry 2 '),(9,'title',0,1,' entry 2 '),(11,'slug',0,1,' entry 3 '),(11,'title',0,1,' entry 3 '),(13,'slug',0,1,' headset 1 '),(13,'title',0,1,' headset 1 '),(15,'slug',0,1,' headset 2 '),(15,'title',0,1,' headset 2 '),(18,'slug',0,1,' echoes of sarajevo '),(18,'title',0,1,' echoes of sarajevo '),(24,'slug',0,1,' diocletians dream '),(24,'title',0,1,' diocletias dream '),(31,'slug',0,1,' entry 4 '),(31,'title',0,1,' entry 4 '),(33,'slug',0,1,' entry 5 ba '),(33,'title',0,1,' entry 5 ba '),(37,'slug',0,1,' entry 6 ba '),(37,'title',0,1,' entry 6 ba '),(38,'slug',0,1,' headset 2 2 '),(38,'title',0,1,' headset 2 '),(41,'slug',0,1,' entry 7 '),(41,'title',0,1,' entry 7 '),(43,'slug',0,1,' entry 6 ba 2 '),(43,'title',0,1,' entry 6 ba '),(45,'slug',0,1,' entry 7 2 '),(45,'title',0,1,' entry 7 '),(47,'slug',0,1,' entry 6 ba 3 '),(47,'title',0,1,' entry 6 ba '),(49,'slug',0,1,' entry 7 3 '),(49,'title',0,1,' entry 7 '),(51,'slug',0,1,' entry es '),(51,'title',0,1,' entry es '),(53,'slug',0,1,' entry es 2 '),(53,'title',0,1,' entry es '),(55,'slug',0,1,' entry es 3 '),(55,'title',0,1,' entry es '),(57,'slug',0,1,' entry es 2 2 '),(57,'title',0,1,' entry es '),(59,'slug',0,1,' entry es 4 '),(59,'title',0,1,' entry es '),(61,'slug',0,1,' entry es 2 3 '),(61,'title',0,1,' entry es '),(63,'slug',0,1,' entry es 3 2 '),(63,'title',0,1,' entry es '),(65,'slug',0,1,' entry es 2 2 2 '),(65,'title',0,1,' entry es '),(67,'slug',0,1,' entry en '),(67,'title',0,1,' entry en '),(69,'slug',0,1,' entry en 2 '),(69,'title',0,1,' entry en '),(73,'slug',0,1,' entry en 3 '),(73,'title',0,1,' entry en '),(75,'slug',0,1,' entry en 4 '),(75,'title',0,1,' entry ba '),(77,'slug',0,1,' entry en 2 2 '),(77,'title',0,1,' entry en '),(81,'slug',0,1,' entry en 4 2 '),(81,'title',0,1,' entry ba '),(83,'slug',0,1,' entry fr '),(83,'title',0,1,' entry fr '),(85,'slug',0,1,' entry fr 2 '),(85,'title',0,1,' entry es '),(87,'slug',0,1,' entry fr 3 '),(87,'title',0,1,' entry fr '),(89,'slug',0,1,' entry fr 2 2 '),(89,'title',0,1,' entry fr '),(91,'slug',0,1,' entry fr 4 '),(91,'title',0,1,' entry fr '),(93,'slug',0,1,' entry fr 2 3 '),(93,'title',0,1,' entry fr '),(95,'slug',0,1,' entry fr 3 2 '),(95,'title',0,1,' entry fr '),(118,'slug',0,1,' hvar festival '),(118,'title',0,1,' hvar festival '),(120,'email',0,1,' jovana emagine ie '),(120,'firstname',0,1,' jovana '),(120,'fullname',0,1,' jovana music '),(120,'lastname',0,1,' music '),(120,'slug',0,1,''),(120,'username',0,1,' jovana '),(121,'email',0,1,' declan emagine ie '),(121,'firstname',0,1,' declan '),(121,'fullname',0,1,' declan o rourke '),(121,'lastname',0,1,' rourke '),(121,'slug',0,1,''),(121,'username',0,1,' declan '),(133,'slug',0,1,' entry it '),(133,'title',0,1,' entry it '),(134,'slug',0,1,' headset 3 '),(134,'title',0,1,' headset 3 '),(170,'slug',0,1,' graphql entry again '),(170,'title',0,1,' graphql entry again '),(172,'slug',0,1,' graphql entry again 2 '),(172,'title',0,1,' graphql entry again '),(176,'slug',0,1,' graphql entry again 3 '),(176,'title',0,1,' graphql entry again '),(186,'slug',0,1,' graphql entry again 4 '),(186,'title',0,1,' graphql entry again '),(188,'slug',0,1,' graphql entry again 5 '),(188,'title',0,1,' graphql entry again '),(192,'slug',0,1,' graphql jovana again '),(192,'title',0,1,' graphql jovana again '),(194,'slug',0,1,' graphql jovana again 2 '),(194,'title',0,1,' graphql jovana again '),(196,'slug',0,1,' graphql jovana again 3 '),(196,'title',0,1,' graphql jovana again '),(198,'slug',0,1,' graphql entry again 6 '),(198,'title',0,1,' graphql entry again '),(200,'slug',0,1,' temp ixlxooulelexehuqwmmvmawadeineurwnzsy '),(200,'title',0,1,''),(203,'slug',0,1,' test '),(203,'title',0,1,' test '),(205,'slug',0,1,' headset 4 '),(205,'title',0,1,' headset 4 '),(208,'slug',0,1,' headset 5 '),(208,'title',0,1,' headset 5 '),(220,'slug',0,1,' headset 6 '),(220,'title',0,1,' headset 6 ');
/*!40000 ALTER TABLE `searchindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sections`
--

DROP TABLE IF EXISTS `sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `type` enum('single','channel','structure') NOT NULL DEFAULT 'channel',
  `enableVersioning` tinyint(1) NOT NULL DEFAULT '0',
  `propagationMethod` varchar(255) NOT NULL DEFAULT 'all',
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `previewTargets` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_zixivxpdcmytvfpapmgauahkugsfkoesjobp` (`handle`),
  KEY `idx_nilfefkjkkqvwmgigntdmueseaipjazkhozd` (`name`),
  KEY `idx_ubzksguyknavaectzoanunghydkslkgbazvl` (`structureId`),
  KEY `idx_ihbmyplqqonfsbxsyimcrgxpgxgbkmudytwd` (`dateDeleted`),
  CONSTRAINT `fk_vbutzoxiolfttyehnxrnqowzewlhhxzprhmc` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sections`
--

LOCK TABLES `sections` WRITE;
/*!40000 ALTER TABLE `sections` DISABLE KEYS */;
INSERT INTO `sections` VALUES (1,NULL,'Headsets','headsets','channel',1,'all','end','[{\"label\":\"Primary entry page\",\"urlFormat\":\"{url}\",\"refresh\":\"1\"}]','2023-11-04 14:04:28','2023-11-04 14:04:28',NULL,'38875b9f-df2c-41e6-a1a2-e9d4ed370735'),(2,NULL,'Statistics','statistics','channel',1,'all','end','[{\"label\":\"Primary entry page\",\"urlFormat\":\"{url}\",\"refresh\":\"1\"}]','2023-11-04 14:04:28','2023-11-04 14:04:28',NULL,'cb843ec5-3aaa-44ea-94cf-f99f4023642f'),(3,NULL,'Venues','venues','channel',1,'all','end','[{\"label\":\"Primary entry page\",\"urlFormat\":\"{url}\",\"refresh\":\"1\"}]','2023-11-04 14:04:28','2023-11-04 14:04:28',NULL,'fa1a9449-1cdb-4185-8017-6d6baea8371b'),(4,NULL,'Movies','movies','channel',1,'all','end','[{\"label\":\"Primary entry page\",\"urlFormat\":\"{url}\",\"refresh\":\"1\"}]','2023-11-04 15:32:15','2023-11-04 15:32:15',NULL,'b3e8c798-1f09-4ca2-ac30-695d0273d094');
/*!40000 ALTER TABLE `sections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sections_sites`
--

DROP TABLE IF EXISTS `sections_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sectionId` int NOT NULL,
  `siteId` int NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `enabledByDefault` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_kdmamzzqsrezxnrjdnnfmvptyoqclpohlnsa` (`sectionId`,`siteId`),
  KEY `idx_rbwbijsufsjjoplqitkwxpozvesnuhravsvj` (`siteId`),
  CONSTRAINT `fk_arjamejaasuqvlvqwrigssrlbnzqivojpfmo` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_zanemznqzhvrndsytxnpscztjxmszqndzxwf` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sections_sites`
--

LOCK TABLES `sections_sites` WRITE;
/*!40000 ALTER TABLE `sections_sites` DISABLE KEYS */;
INSERT INTO `sections_sites` VALUES (1,1,1,1,'headsets/{slug}','headsets/_entry',1,'2023-11-04 14:04:28','2023-11-04 14:04:28','b5d3ee22-cd04-4621-bcbb-7aa4d3fc962a'),(2,2,1,1,'statistics/{slug}','statistics/_entry',1,'2023-11-04 14:04:28','2023-11-04 14:04:28','11d7f4d8-92ea-431b-8946-a36fe6ba166c'),(3,3,1,1,'venues/{slug}','venues/_entry',1,'2023-11-04 14:04:28','2023-11-04 14:04:28','7442ed50-9f72-4d13-ac3d-a15c5fe61ba1'),(4,4,1,1,'movies/{slug}','movies/_entry',1,'2023-11-04 15:32:15','2023-11-04 15:32:15','acd57f94-9188-4fe8-8dc4-c98709f61860');
/*!40000 ALTER TABLE `sections_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sequences`
--

DROP TABLE IF EXISTS `sequences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sequences` (
  `name` varchar(255) NOT NULL,
  `next` int unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sequences`
--

LOCK TABLES `sequences` WRITE;
/*!40000 ALTER TABLE `sequences` DISABLE KEYS */;
/*!40000 ALTER TABLE `sequences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `token` char(100) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_anlbzgwdjkpvdsfgjboeocsmgsxdyfuqmcuo` (`uid`),
  KEY `idx_hwfasvkvxoadeqfftneyxcuzmrfngcydnlst` (`token`),
  KEY `idx_csrqrdnonrwfkcdbzqasphjkkrhszmlpnjio` (`dateUpdated`),
  KEY `idx_laoucajffszihyryercgfjkwftczjlweqapk` (`userId`),
  CONSTRAINT `fk_xvlgblvihgsuymaffsdoesinzeltysmpurqs` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES (8,1,'UIjuPRvHBAm5tsxMXjYTWbTnsHRigLEB2B8oLzdqNGID16jumwogjJbf7A6rPnycDy5GzJerIoFjRbOaA-neYDrpele_YBa9eqCI','2023-11-08 14:19:07','2023-11-08 14:48:10','e5491285-d16a-4cf2-be15-d8988341b1a4'),(11,1,'IBSqKgU69PXq_BkAZn4n57AbvbOaFY1gFvjzzckCuZsBg7ov7IVQv3Urqc2DGE6xIxtQyTbYZoa4HK0ykuY6pG-DwiNJI2ooo3be','2023-11-09 09:47:51','2023-11-09 09:47:51','b93934ff-d0c4-43ed-a9cc-ddf00e3ed543'),(13,1,'8mWOOfSyTSAhmzGEjzfj4gEJqGE33gt6Nmmx6zoe6VbhQ6uTttMWtq80KSy9uLJK7dErwLkFoRta1w6sK4Y0xMv8C2LnJbi-lWFj','2023-11-09 15:45:02','2023-11-09 16:00:15','90b3b46c-b5c4-4354-8c35-a3af84eb13de'),(14,120,'xolXnCJeB_Ce7xp3ZfLYzorApPQg3pgP6G_i7k_ZFpuc9bCQ_wa3bNVLaZscgEUhiJywHqZzwEUlThRxXFQmZbEGjnFS3Wg__HXt','2023-11-09 16:00:15','2023-11-09 16:01:27','4e85d14c-8dce-4820-b8af-74c3d3c28ea2'),(20,1,'dOPziBPxN0OCT8maiCZIhfKFzjh7WKdsJOR0LQ2gok72R7VzQqFkyoY1YnlszpfMlyapPkZJxzTf0fiJtnhbcEvBF5PQPiyc8hQ9','2023-11-11 12:04:14','2023-11-11 12:04:31','4836244f-e4b8-45e0-842c-f0777f0b4b1d'),(23,1,'aN8ezpxO-I07hLS7-BOhV72fG2iGNv8U7Ixr0g-sKWPoCKpgcVChgp3f5cAdieMg0JbzTdbqn64dTXtwR8APJ7J9zOVL9laXekEf','2023-11-13 10:30:24','2023-11-13 10:36:28','cbdcbe37-568b-41be-83a0-d5ad64ac3694'),(28,121,'NOhPj76E1C8Zm0ArDnDK05lRbAVJUO7bdv-gxmxQpzL4L6uJUIZXothaw8fQip8xIjDlXtthcPHhe7BnKR7wzDd3b5lIXaR1ZXmX','2023-11-16 10:05:28','2023-11-16 10:21:00','c16f5001-1e74-4578-838a-703a583cf560'),(29,1,'SrNTI4_9n-x-vNzP7efdSHsihaQN9O7US2BQE5idDTRipHKsKv1c3Rt5QfPAm-U5YkndImsC7lzUlkmsZ__9Ny2yubXQE9GLR7ic','2024-04-04 13:54:24','2024-04-04 14:13:35','a0444502-360e-40ab-8909-fcc92783bc99');
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shunnedmessages`
--

DROP TABLE IF EXISTS `shunnedmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shunnedmessages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `message` varchar(255) NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_fzmpccuifdvnaqyvwnxehzlrqjrzesfxqwhl` (`userId`,`message`),
  CONSTRAINT `fk_xkawprryuluryppmetcsiuzrqcumhocvpedl` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shunnedmessages`
--

LOCK TABLES `shunnedmessages` WRITE;
/*!40000 ALTER TABLE `shunnedmessages` DISABLE KEYS */;
/*!40000 ALTER TABLE `shunnedmessages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sitegroups`
--

DROP TABLE IF EXISTS `sitegroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sitegroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_qoerryetckwyuozvauoxigkylqyuuvzwftpo` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sitegroups`
--

LOCK TABLES `sitegroups` WRITE;
/*!40000 ALTER TABLE `sitegroups` DISABLE KEYS */;
INSERT INTO `sitegroups` VALUES (1,'Emagine VR Analytics','2023-11-04 14:04:27','2023-11-04 14:04:27',NULL,'3226293d-1172-4808-9dfa-adbbb8120257');
/*!40000 ALTER TABLE `sitegroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sites`
--

DROP TABLE IF EXISTS `sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `primary` tinyint(1) NOT NULL,
  `enabled` varchar(255) NOT NULL DEFAULT 'true',
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `language` varchar(12) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '0',
  `baseUrl` varchar(255) DEFAULT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_wycqirihixzdltvpejpitkpeiiernemaafxe` (`dateDeleted`),
  KEY `idx_wbkzfbxwmykhzzdzzcbwcazzyduksnfhylvp` (`handle`),
  KEY `idx_wwuiunugoccnrlfjayropxwykwccpiimpqip` (`sortOrder`),
  KEY `fk_mydeoucojxqakruzcllvwzsislphoadfxlup` (`groupId`),
  CONSTRAINT `fk_mydeoucojxqakruzcllvwzsislphoadfxlup` FOREIGN KEY (`groupId`) REFERENCES `sitegroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sites`
--

LOCK TABLES `sites` WRITE;
/*!40000 ALTER TABLE `sites` DISABLE KEYS */;
INSERT INTO `sites` VALUES (1,1,1,'1','Emagine VR Analytics','default','en-US',1,'$PRIMARY_SITE_URL',1,'2023-11-04 14:04:27','2023-11-04 14:04:30',NULL,'f957802c-8f19-44d3-a30a-668d452862ac');
/*!40000 ALTER TABLE `sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `structureelements`
--

DROP TABLE IF EXISTS `structureelements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `structureelements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int NOT NULL,
  `elementId` int DEFAULT NULL,
  `root` int unsigned DEFAULT NULL,
  `lft` int unsigned NOT NULL,
  `rgt` int unsigned NOT NULL,
  `level` smallint unsigned NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_tlvcamxijigwzwpcqqbkehojxjtoecsfbnjm` (`structureId`,`elementId`),
  KEY `idx_pozgwlqanuqbefrtwpidtikzxsmjzbznhnjo` (`root`),
  KEY `idx_brqezmdubluqhsczixhgzwjtplnddjzvkndb` (`lft`),
  KEY `idx_sqqkscidbzpjbivjhduzrwgydhppzwsipmpa` (`rgt`),
  KEY `idx_izjmmyrmrwsufctddwfazeduvcagnwefljjc` (`level`),
  KEY `idx_vcsvmqwzceupkcdjeuekzyvewmqclpvpbbhz` (`elementId`),
  CONSTRAINT `fk_hniyhqruvbzxsodkwwftlrpsmxafmofoxusx` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `structureelements`
--

LOCK TABLES `structureelements` WRITE;
/*!40000 ALTER TABLE `structureelements` DISABLE KEYS */;
/*!40000 ALTER TABLE `structureelements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `structures`
--

DROP TABLE IF EXISTS `structures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `structures` (
  `id` int NOT NULL AUTO_INCREMENT,
  `maxLevels` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_oggkdjjgtpdwpqocpxnheepknwwozcmcfyok` (`dateDeleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `structures`
--

LOCK TABLES `structures` WRITE;
/*!40000 ALTER TABLE `structures` DISABLE KEYS */;
/*!40000 ALTER TABLE `structures` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `systemmessages`
--

DROP TABLE IF EXISTS `systemmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `systemmessages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `language` varchar(255) NOT NULL,
  `key` varchar(255) NOT NULL,
  `subject` text NOT NULL,
  `body` text NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_aobfigriajzgcmisanmegbmywfvxgerexpow` (`key`,`language`),
  KEY `idx_mxfuvznwzojrdyuuoukhdffpnyyewfsrknmv` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `systemmessages`
--

LOCK TABLES `systemmessages` WRITE;
/*!40000 ALTER TABLE `systemmessages` DISABLE KEYS */;
/*!40000 ALTER TABLE `systemmessages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `taggroups`
--

DROP TABLE IF EXISTS `taggroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `taggroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_ldzkhkldbccaibzckuieagfpdjemrxfaksdh` (`name`),
  KEY `idx_wknixxmauxkonineuqpnykiugwlefchvztje` (`handle`),
  KEY `idx_rnwqjrrefikyxssqxjeaprppzaqwvvqeyahj` (`dateDeleted`),
  KEY `fk_korxlwkoezuimptujjdkrhxuorgpxslpzois` (`fieldLayoutId`),
  CONSTRAINT `fk_korxlwkoezuimptujjdkrhxuorgpxslpzois` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `taggroups`
--

LOCK TABLES `taggroups` WRITE;
/*!40000 ALTER TABLE `taggroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `taggroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tags` (
  `id` int NOT NULL,
  `groupId` int NOT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_xgmcyvqgidvbfhwgicgumrdxojthoyxeldkv` (`groupId`),
  CONSTRAINT `fk_jvrnvomvicwkkfmvkguykphkxxqiefjkthoj` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ziiymiwumuixfgwrkgmbobqdvtajhherehps` FOREIGN KEY (`groupId`) REFERENCES `taggroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tokens`
--

DROP TABLE IF EXISTS `tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `token` char(32) NOT NULL,
  `route` text,
  `usageLimit` tinyint unsigned DEFAULT NULL,
  `usageCount` tinyint unsigned DEFAULT NULL,
  `expiryDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_jzapyzvezeasvgvfbshmyoidzetmcoxvadip` (`token`),
  KEY `idx_itkoccayigvifqajfqajzokffakhkcsgavyj` (`expiryDate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tokens`
--

LOCK TABLES `tokens` WRITE;
/*!40000 ALTER TABLE `tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usergroups`
--

DROP TABLE IF EXISTS `usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usergroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `description` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_vxxwwfdqyoljlcbtujrfnkzxeautzskbwquq` (`handle`),
  KEY `idx_djipuswqyfpkaptpebbtszewrthbiskgtndp` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usergroups`
--

LOCK TABLES `usergroups` WRITE;
/*!40000 ALTER TABLE `usergroups` DISABLE KEYS */;
INSERT INTO `usergroups` VALUES (1,'Admin','admin','','2023-11-04 14:04:28','2023-11-04 14:04:28','a5255343-5341-4742-9fd7-dc1f26af404a'),(2,'Clients','Clients','Clients to the analytics system','2023-11-04 14:04:28','2023-11-04 14:04:28','32c28836-80b3-4da9-a427-6d42b223613b');
/*!40000 ALTER TABLE `usergroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usergroups_users`
--

DROP TABLE IF EXISTS `usergroups_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usergroups_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_dueetpfzrjpmbdobzcxzvurcocxsrazncxmu` (`groupId`,`userId`),
  KEY `idx_fkgmcryapqtlcbfppkmpeepavmzsxhpwuncr` (`userId`),
  CONSTRAINT `fk_lqzjfyjeojkfxxzkrsrfmircibusmdbjeyat` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_vrnguoufmlbamlcyyrzblniqtgwnovddbiec` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usergroups_users`
--

LOCK TABLES `usergroups_users` WRITE;
/*!40000 ALTER TABLE `usergroups_users` DISABLE KEYS */;
INSERT INTO `usergroups_users` VALUES (1,1,1,'2023-11-04 15:27:26','2023-11-04 15:27:26','ab80c418-5e7a-428e-adc7-33cef857c556'),(2,2,120,'2023-11-09 16:00:00','2023-11-09 16:00:00','cb17f19b-ebea-4a61-a851-3e4ec26fedfd'),(3,2,121,'2023-11-09 16:01:08','2023-11-09 16:01:08','639b5f28-f5a6-48a4-bcfb-c47a63f7c502');
/*!40000 ALTER TABLE `usergroups_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpermissions`
--

DROP TABLE IF EXISTS `userpermissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_qrtnqdefgjkcppknjfqbabzntmncdsefgaqp` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpermissions`
--

LOCK TABLES `userpermissions` WRITE;
/*!40000 ALTER TABLE `userpermissions` DISABLE KEYS */;
INSERT INTO `userpermissions` VALUES (1,'accesscp','2023-11-04 14:04:28','2023-11-04 14:04:28','ceb4f6b0-05b6-4dc1-96c6-5b3707b912c5'),(2,'accesscpwhensystemisoff','2023-11-04 14:04:28','2023-11-04 14:04:28','ee8679d1-d85e-4eb0-90ba-87c9d7e02555'),(3,'accesssitewhensystemisoff','2023-11-04 14:04:28','2023-11-04 14:04:28','a043a250-12a4-4c85-a191-780e66db2cb0'),(4,'administrateusers','2023-11-04 14:04:28','2023-11-04 14:04:28','15bae3fb-3474-404d-b746-5324a07cd233'),(5,'assignusergroup:32c28836-80b3-4da9-a427-6d42b223613b','2023-11-04 14:04:28','2023-11-04 14:04:28','ef4c1176-d67f-4949-a891-a76a7a3b52a7'),(6,'assignusergroup:a5255343-5341-4742-9fd7-dc1f26af404a','2023-11-04 14:04:28','2023-11-04 14:04:28','50348de9-dbcf-4353-849d-1edc4da71679'),(7,'assignuserpermissions','2023-11-04 14:04:28','2023-11-04 14:04:28','7ac0ffe7-7517-4887-b954-1127a5de5fa5'),(8,'createentries:38875b9f-df2c-41e6-a1a2-e9d4ed370735','2023-11-04 14:04:28','2023-11-04 14:04:28','49a4ea0a-ae42-49d8-bfa6-599db40b06ae'),(9,'createentries:cb843ec5-3aaa-44ea-94cf-f99f4023642f','2023-11-04 14:04:28','2023-11-04 14:04:28','03d78eef-7d4f-44f9-96b4-76f04dbc0263'),(10,'createentries:fa1a9449-1cdb-4185-8017-6d6baea8371b','2023-11-04 14:04:28','2023-11-04 14:04:28','17f527d2-5a74-4e91-acb0-3396a10e1eff'),(11,'deleteentries:38875b9f-df2c-41e6-a1a2-e9d4ed370735','2023-11-04 14:04:28','2023-11-04 14:04:28','33b5f6b3-98ee-446a-835f-65a82773e3c8'),(12,'deleteentries:cb843ec5-3aaa-44ea-94cf-f99f4023642f','2023-11-04 14:04:28','2023-11-04 14:04:28','c576512c-849e-4079-82f5-03191b6770b2'),(13,'deleteentries:fa1a9449-1cdb-4185-8017-6d6baea8371b','2023-11-04 14:04:28','2023-11-04 14:04:28','f587ad73-35c4-4e91-a4df-9cea497787fb'),(14,'deletepeerentries:38875b9f-df2c-41e6-a1a2-e9d4ed370735','2023-11-04 14:04:28','2023-11-04 14:04:28','844859c6-8d48-4787-8dee-f0fa917dfcff'),(15,'deletepeerentries:cb843ec5-3aaa-44ea-94cf-f99f4023642f','2023-11-04 14:04:28','2023-11-04 14:04:28','4f9661b5-4b81-4442-b36b-bcb1c34514dc'),(16,'deletepeerentries:fa1a9449-1cdb-4185-8017-6d6baea8371b','2023-11-04 14:04:28','2023-11-04 14:04:28','6cbc19ae-c165-4eb6-b1ef-a104abc7e179'),(17,'deletepeerentrydrafts:38875b9f-df2c-41e6-a1a2-e9d4ed370735','2023-11-04 14:04:28','2023-11-04 14:04:28','2e0651f2-0868-443e-a957-d391202f0cbd'),(18,'deletepeerentrydrafts:cb843ec5-3aaa-44ea-94cf-f99f4023642f','2023-11-04 14:04:28','2023-11-04 14:04:28','2ed08a84-d999-4ab2-b8a2-ba86f71b609c'),(19,'deletepeerentrydrafts:fa1a9449-1cdb-4185-8017-6d6baea8371b','2023-11-04 14:04:28','2023-11-04 14:04:28','fb0c8401-eb86-42a3-9055-dacf89324abb'),(20,'deleteusers','2023-11-04 14:04:28','2023-11-04 14:04:28','6aaf2115-d24f-42af-a5be-f4af266cb883'),(21,'editusers','2023-11-04 14:04:28','2023-11-04 14:04:28','70e5fbf0-b931-48fc-b0b9-11c7b1775235'),(22,'impersonateusers','2023-11-04 14:04:28','2023-11-04 14:04:28','4858ae82-7035-466b-bbf7-cc66b13c01e8'),(23,'moderateusers','2023-11-04 14:04:28','2023-11-04 14:04:28','a2879143-bd76-49fe-964c-9a847c1ea49b'),(24,'performupdates','2023-11-04 14:04:28','2023-11-04 14:04:28','201a2ff8-3d8d-4ebe-89d7-f914cb85c1d7'),(25,'registerusers','2023-11-04 14:04:28','2023-11-04 14:04:28','ba9c28e1-96b1-468c-a6e5-e15ea16f53cc'),(26,'saveentries:38875b9f-df2c-41e6-a1a2-e9d4ed370735','2023-11-04 14:04:28','2023-11-04 14:04:28','a06bad52-d2f5-4425-9497-d5e2c65a2a7e'),(27,'saveentries:cb843ec5-3aaa-44ea-94cf-f99f4023642f','2023-11-04 14:04:28','2023-11-04 14:04:28','4fb4957d-4cd1-4dfe-a1e5-6f598d8d2d59'),(28,'saveentries:fa1a9449-1cdb-4185-8017-6d6baea8371b','2023-11-04 14:04:28','2023-11-04 14:04:28','cc5d23aa-4a22-484e-88f5-8cc429610c72'),(29,'savepeerentries:38875b9f-df2c-41e6-a1a2-e9d4ed370735','2023-11-04 14:04:28','2023-11-04 14:04:28','28e5a068-094c-49c7-b8b7-33039796142b'),(30,'savepeerentries:cb843ec5-3aaa-44ea-94cf-f99f4023642f','2023-11-04 14:04:28','2023-11-04 14:04:28','68bd0876-2adb-4d97-bb62-adecab109bec'),(31,'savepeerentries:fa1a9449-1cdb-4185-8017-6d6baea8371b','2023-11-04 14:04:28','2023-11-04 14:04:28','d29e82ee-9240-4d14-956e-6404d0f40b22'),(32,'savepeerentrydrafts:38875b9f-df2c-41e6-a1a2-e9d4ed370735','2023-11-04 14:04:28','2023-11-04 14:04:28','0027aac4-dca4-4257-9298-44511a29725c'),(33,'savepeerentrydrafts:cb843ec5-3aaa-44ea-94cf-f99f4023642f','2023-11-04 14:04:28','2023-11-04 14:04:28','149ed54e-bb8f-46bd-a092-06aa726bb1f0'),(34,'savepeerentrydrafts:fa1a9449-1cdb-4185-8017-6d6baea8371b','2023-11-04 14:04:28','2023-11-04 14:04:28','80a29ff3-6639-4b8d-b2b2-6d28c7d61de6'),(35,'utility:clear-caches','2023-11-04 14:04:28','2023-11-04 14:04:28','5f20f41e-bf87-4166-b932-d8045d0c4e8f'),(36,'utility:db-backup','2023-11-04 14:04:28','2023-11-04 14:04:28','6443b3eb-6d60-4d81-bd40-2c13f528d4bf'),(37,'utility:deprecation-errors','2023-11-04 14:04:28','2023-11-04 14:04:28','1f88df22-bd4b-4071-8190-ccaa7226edca'),(38,'utility:find-replace','2023-11-04 14:04:28','2023-11-04 14:04:28','283b44c9-2a53-41cd-b842-fac539cea6ec'),(39,'utility:migrations','2023-11-04 14:04:28','2023-11-04 14:04:28','51f1f1cd-90e5-4670-8843-e301e1c8734e'),(40,'utility:php-info','2023-11-04 14:04:28','2023-11-04 14:04:28','8f6881db-59f2-4198-9d05-bf6a340aaba0'),(41,'utility:queue-manager','2023-11-04 14:04:28','2023-11-04 14:04:28','2579b8b0-1644-4333-85a7-d26b2bf34daa'),(42,'utility:system-messages','2023-11-04 14:04:28','2023-11-04 14:04:28','4dcf0246-0298-40d7-88a7-aa95fedcd84f'),(43,'utility:system-report','2023-11-04 14:04:28','2023-11-04 14:04:28','31c44128-90a3-4d34-9182-b182a6f7abe4'),(44,'utility:updates','2023-11-04 14:04:28','2023-11-04 14:04:28','ea2d3126-2f85-4ef3-8b8d-8d1e970f8a16'),(45,'viewentries:38875b9f-df2c-41e6-a1a2-e9d4ed370735','2023-11-04 14:04:28','2023-11-04 14:04:28','da4c4ed8-1701-43a7-92b0-bc1accf5ad40'),(46,'viewentries:cb843ec5-3aaa-44ea-94cf-f99f4023642f','2023-11-04 14:04:29','2023-11-04 14:04:29','6e8e7171-1ddc-480e-81cc-6c1abd14675f'),(47,'viewentries:fa1a9449-1cdb-4185-8017-6d6baea8371b','2023-11-04 14:04:29','2023-11-04 14:04:29','e62d4cf0-1bce-40ad-9401-2ec3131f0365'),(48,'viewpeerentries:38875b9f-df2c-41e6-a1a2-e9d4ed370735','2023-11-04 14:04:29','2023-11-04 14:04:29','d0a5dc67-8378-4d1c-b33c-627f79f12d31'),(49,'viewpeerentries:cb843ec5-3aaa-44ea-94cf-f99f4023642f','2023-11-04 14:04:29','2023-11-04 14:04:29','1b054dea-47dd-4ae0-8367-727893b2f56a'),(50,'viewpeerentries:fa1a9449-1cdb-4185-8017-6d6baea8371b','2023-11-04 14:04:29','2023-11-04 14:04:29','db11322c-fdc2-4499-b1ec-3792253c322b'),(51,'viewpeerentrydrafts:38875b9f-df2c-41e6-a1a2-e9d4ed370735','2023-11-04 14:04:29','2023-11-04 14:04:29','574870fc-24c5-4347-a52c-c2fbd16ea3d6'),(52,'viewpeerentrydrafts:cb843ec5-3aaa-44ea-94cf-f99f4023642f','2023-11-04 14:04:29','2023-11-04 14:04:29','e62105e3-cfdb-49cf-a9b3-cab0ab89478d'),(53,'viewpeerentrydrafts:fa1a9449-1cdb-4185-8017-6d6baea8371b','2023-11-04 14:04:29','2023-11-04 14:04:29','f4b65f3e-3ba0-485c-a3d6-25f5363ffff1');
/*!40000 ALTER TABLE `userpermissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpermissions_usergroups`
--

DROP TABLE IF EXISTS `userpermissions_usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions_usergroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `permissionId` int NOT NULL,
  `groupId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_qfybfdeixkvhdxbuqqcikqtxtjzwldxhzeuj` (`permissionId`,`groupId`),
  KEY `idx_sirnpukprwxninegyhferlhwmudoxsvgdplt` (`groupId`),
  CONSTRAINT `fk_niqtviujkpwlrbmzbanmgioahavnwgplmkwj` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_qijfpvxzqjmfedzreibfswoaoxpqjbvgekbd` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=135 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpermissions_usergroups`
--

LOCK TABLES `userpermissions_usergroups` WRITE;
/*!40000 ALTER TABLE `userpermissions_usergroups` DISABLE KEYS */;
INSERT INTO `userpermissions_usergroups` VALUES (54,1,1,'2023-11-04 14:04:29','2023-11-04 14:04:29','fcd4b8f2-d5e5-4f8f-be96-445236394646'),(55,2,1,'2023-11-04 14:04:29','2023-11-04 14:04:29','7d3b75b6-23d8-4b2e-bfa1-fb5f5966a907'),(56,3,1,'2023-11-04 14:04:29','2023-11-04 14:04:29','e19bdc93-7a78-4cec-97a4-9ec2d2af7d70'),(57,4,1,'2023-11-04 14:04:29','2023-11-04 14:04:29','86f133f9-d22c-461b-8b41-f1b9deee829e'),(58,5,1,'2023-11-04 14:04:29','2023-11-04 14:04:29','df4996a0-6560-4f59-9d13-99eb2f63d6f4'),(59,6,1,'2023-11-04 14:04:29','2023-11-04 14:04:29','975673e0-ca8f-470b-8af2-1cc878a1c966'),(60,7,1,'2023-11-04 14:04:29','2023-11-04 14:04:29','52dd349e-5c17-4dc6-8307-ca89fc09d204'),(61,8,1,'2023-11-04 14:04:29','2023-11-04 14:04:29','8cfae0fe-0df0-4a23-b237-2fb3a3bb8f18'),(62,9,1,'2023-11-04 14:04:29','2023-11-04 14:04:29','244748ae-07b1-4387-bd35-3a4f987e0635'),(63,10,1,'2023-11-04 14:04:29','2023-11-04 14:04:29','3da265f9-2405-41e9-9a32-f783f40e503c'),(64,11,1,'2023-11-04 14:04:29','2023-11-04 14:04:29','3411109f-03f7-4df9-831a-c3cdb71f6e1f'),(65,12,1,'2023-11-04 14:04:29','2023-11-04 14:04:29','6576c36e-416f-42fa-a7b7-937eefe5f006'),(66,13,1,'2023-11-04 14:04:29','2023-11-04 14:04:29','3f3a1f54-4245-44be-b52e-0c7d268cd452'),(67,14,1,'2023-11-04 14:04:29','2023-11-04 14:04:29','af7ee80d-6849-4cf7-ae90-2dceb43923a9'),(68,15,1,'2023-11-04 14:04:29','2023-11-04 14:04:29','afe157ea-9a31-41db-a951-a760fc7a0f67'),(69,16,1,'2023-11-04 14:04:29','2023-11-04 14:04:29','5a3b82ed-281c-4ea8-9dfb-6ecc37d94b28'),(70,17,1,'2023-11-04 14:04:29','2023-11-04 14:04:29','ec29cc54-66cf-4256-861d-1fdb9c53720a'),(71,18,1,'2023-11-04 14:04:29','2023-11-04 14:04:29','1fb3b694-221f-4da6-95e1-cf7d82cf34dc'),(72,19,1,'2023-11-04 14:04:29','2023-11-04 14:04:29','e80d06fc-615b-45ff-8ab5-833a4d6be041'),(73,20,1,'2023-11-04 14:04:29','2023-11-04 14:04:29','59ba014a-f6f2-49e3-9291-784374bc3844'),(74,21,1,'2023-11-04 14:04:29','2023-11-04 14:04:29','69d1980d-5031-4845-8415-e1e4166b55bd'),(75,22,1,'2023-11-04 14:04:29','2023-11-04 14:04:29','977d1ac3-2b48-4e62-b574-d75291554b35'),(76,23,1,'2023-11-04 14:04:29','2023-11-04 14:04:29','d7980aa2-95aa-4424-b845-50dd9e48cb21'),(77,24,1,'2023-11-04 14:04:29','2023-11-04 14:04:29','a3c21c38-f555-4806-8252-5638d67ff253'),(78,25,1,'2023-11-04 14:04:29','2023-11-04 14:04:29','0f599046-12c9-4a61-877a-79d69eb6d72a'),(79,26,1,'2023-11-04 14:04:29','2023-11-04 14:04:29','9935c53d-0fbc-484f-943e-2beaa586f701'),(80,27,1,'2023-11-04 14:04:29','2023-11-04 14:04:29','06ceba3d-7463-4462-98ad-82d29ebcf379'),(81,28,1,'2023-11-04 14:04:29','2023-11-04 14:04:29','e7a9c9f8-e291-4868-8a50-fa12142a6017'),(82,29,1,'2023-11-04 14:04:29','2023-11-04 14:04:29','154283c2-9e0d-4704-987a-b007abbe228c'),(83,30,1,'2023-11-04 14:04:29','2023-11-04 14:04:29','44022919-875e-42a9-b3f3-6d2f6090f665'),(84,31,1,'2023-11-04 14:04:29','2023-11-04 14:04:29','578ce2bd-e73d-4a88-934b-6917738eb809'),(85,32,1,'2023-11-04 14:04:29','2023-11-04 14:04:29','c1f0d725-7779-4c95-91bd-10deaed90d99'),(86,33,1,'2023-11-04 14:04:29','2023-11-04 14:04:29','e817302b-3e56-4ec4-a630-55c6c588bc1a'),(87,34,1,'2023-11-04 14:04:29','2023-11-04 14:04:29','32b697ee-e5e0-4024-9d60-c18d9bde7469'),(88,35,1,'2023-11-04 14:04:29','2023-11-04 14:04:29','35768e3e-2086-418c-9754-24a08ea9ad85'),(89,36,1,'2023-11-04 14:04:29','2023-11-04 14:04:29','ad1968f7-95bb-46cc-a973-6c967fd95764'),(90,37,1,'2023-11-04 14:04:29','2023-11-04 14:04:29','88897bc6-c480-409a-9de4-52c7f70fe7c2'),(91,38,1,'2023-11-04 14:04:29','2023-11-04 14:04:29','c8e424b3-6a74-4af6-8b8f-f89f455f7519'),(92,39,1,'2023-11-04 14:04:29','2023-11-04 14:04:29','d934fefa-8e77-4a29-9818-af162f6fc279'),(93,40,1,'2023-11-04 14:04:29','2023-11-04 14:04:29','8e83e92a-b645-49a0-a01d-5d721006a536'),(94,41,1,'2023-11-04 14:04:29','2023-11-04 14:04:29','4a6b54cc-3585-4feb-9ea0-105b8fee59b2'),(95,42,1,'2023-11-04 14:04:29','2023-11-04 14:04:29','f682279d-c597-4c5f-8981-7504e1ce1cd2'),(96,43,1,'2023-11-04 14:04:29','2023-11-04 14:04:29','4d21ab11-31f2-4938-bb4b-a2f888f350e1'),(97,44,1,'2023-11-04 14:04:29','2023-11-04 14:04:29','e7a52ea5-c04f-4aa1-9343-e309c915ea44'),(98,45,1,'2023-11-04 14:04:29','2023-11-04 14:04:29','3b45cd5e-8551-4f33-af75-3b34870440f0'),(99,46,1,'2023-11-04 14:04:29','2023-11-04 14:04:29','cb605c48-c1e3-4b0d-ba88-9e5d3dd10ec3'),(100,47,1,'2023-11-04 14:04:29','2023-11-04 14:04:29','2af69bd1-52f3-462b-837e-755b59e71574'),(101,48,1,'2023-11-04 14:04:29','2023-11-04 14:04:29','564474bc-3086-4572-b643-b6152c6dd2c8'),(102,49,1,'2023-11-04 14:04:29','2023-11-04 14:04:29','0c742c35-0a64-45b4-9dd5-b0554335e571'),(103,50,1,'2023-11-04 14:04:29','2023-11-04 14:04:29','281fdfd1-0d7f-420d-aa4a-1775eabd8d27'),(104,51,1,'2023-11-04 14:04:29','2023-11-04 14:04:29','3d22df54-832a-4039-98cc-99883407c6df'),(105,52,1,'2023-11-04 14:04:29','2023-11-04 14:04:29','d6e5cef9-347a-4b34-b987-95140f7818a6'),(106,53,1,'2023-11-04 14:04:29','2023-11-04 14:04:29','9ae21a33-ff6d-488a-9dd3-587bd5ff62bb'),(125,8,2,'2023-11-09 15:59:31','2023-11-09 15:59:31','7f6cac05-300c-441e-8368-bf31769038d0'),(126,9,2,'2023-11-09 15:59:31','2023-11-09 15:59:31','2b045b8b-9a73-423c-8c7c-3029c1708bb8'),(127,10,2,'2023-11-09 15:59:31','2023-11-09 15:59:31','a90ce422-6501-40f7-a0a4-59a8597fe716'),(128,11,2,'2023-11-09 15:59:31','2023-11-09 15:59:31','a21bee3d-d0b8-4b44-ac17-f8ce6c876d02'),(129,26,2,'2023-11-09 15:59:31','2023-11-09 15:59:31','fd046038-9c10-4cb5-865a-62e816106ed5'),(130,27,2,'2023-11-09 15:59:31','2023-11-09 15:59:31','a2f36da2-3cfe-46be-af74-9225340654af'),(131,28,2,'2023-11-09 15:59:31','2023-11-09 15:59:31','fe19fb09-7446-4500-ad1e-d3be8860eb3c'),(132,45,2,'2023-11-09 15:59:31','2023-11-09 15:59:31','b2248cbf-0f94-4c50-98d9-755becce210e'),(133,46,2,'2023-11-09 15:59:31','2023-11-09 15:59:31','57097c26-f6fd-4733-82f7-602f6cda9e24'),(134,47,2,'2023-11-09 15:59:31','2023-11-09 15:59:31','63bd6b1d-a570-4778-be1b-d777284dbfc6');
/*!40000 ALTER TABLE `userpermissions_usergroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpermissions_users`
--

DROP TABLE IF EXISTS `userpermissions_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `permissionId` int NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_zzhjflrxnvolzhyqknxlhxiucspdeyxdnuot` (`permissionId`,`userId`),
  KEY `idx_vyblmpkcyxlqimdueyqxedehxmhzzdpgpxzb` (`userId`),
  CONSTRAINT `fk_idnwpdacstcnvrpxniptesoywieblqdrxtrv` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_tqlvornohehacnufcfgosalhdwcqlxiecstu` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpermissions_users`
--

LOCK TABLES `userpermissions_users` WRITE;
/*!40000 ALTER TABLE `userpermissions_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `userpermissions_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpreferences`
--

DROP TABLE IF EXISTS `userpreferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpreferences` (
  `userId` int NOT NULL AUTO_INCREMENT,
  `preferences` text,
  PRIMARY KEY (`userId`),
  CONSTRAINT `fk_mnmudxtsjdtxryjtuvbodigthgacebocqkgm` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=122 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpreferences`
--

LOCK TABLES `userpreferences` WRITE;
/*!40000 ALTER TABLE `userpreferences` DISABLE KEYS */;
INSERT INTO `userpreferences` VALUES (1,'{\"language\":\"en-US\",\"locale\":null,\"weekStartDay\":\"1\",\"alwaysShowFocusRings\":false,\"useShapes\":false,\"underlineLinks\":false,\"notificationDuration\":\"5000\",\"showFieldHandles\":false,\"enableDebugToolbarForSite\":false,\"enableDebugToolbarForCp\":false,\"showExceptionView\":false,\"profileTemplates\":false}'),(120,'{\"language\":\"en-GB\",\"locale\":null,\"weekStartDay\":\"1\",\"alwaysShowFocusRings\":false,\"useShapes\":false,\"underlineLinks\":false,\"notificationDuration\":\"5000\",\"showFieldHandles\":false,\"enableDebugToolbarForSite\":false,\"enableDebugToolbarForCp\":false,\"showExceptionView\":false,\"profileTemplates\":false}'),(121,'{\"language\":\"en-GB\",\"locale\":null,\"weekStartDay\":\"1\",\"alwaysShowFocusRings\":false,\"useShapes\":false,\"underlineLinks\":false,\"notificationDuration\":\"5000\",\"showFieldHandles\":false,\"enableDebugToolbarForSite\":false,\"enableDebugToolbarForCp\":false,\"showExceptionView\":false,\"profileTemplates\":false}');
/*!40000 ALTER TABLE `userpreferences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL,
  `photoId` int DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `pending` tinyint(1) NOT NULL DEFAULT '0',
  `locked` tinyint(1) NOT NULL DEFAULT '0',
  `suspended` tinyint(1) NOT NULL DEFAULT '0',
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `username` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `lastLoginDate` datetime DEFAULT NULL,
  `lastLoginAttemptIp` varchar(45) DEFAULT NULL,
  `invalidLoginWindowStart` datetime DEFAULT NULL,
  `invalidLoginCount` tinyint unsigned DEFAULT NULL,
  `lastInvalidLoginDate` datetime DEFAULT NULL,
  `lockoutDate` datetime DEFAULT NULL,
  `hasDashboard` tinyint(1) NOT NULL DEFAULT '0',
  `verificationCode` varchar(255) DEFAULT NULL,
  `verificationCodeIssuedDate` datetime DEFAULT NULL,
  `unverifiedEmail` varchar(255) DEFAULT NULL,
  `passwordResetRequired` tinyint(1) NOT NULL DEFAULT '0',
  `lastPasswordChangeDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_yyplgurhracvjzqcdrbhwtjrbezoojyoalhv` (`active`),
  KEY `idx_qaxsoutzolrujxyytvyzdvohwgpropecawiw` (`locked`),
  KEY `idx_pviizkwkwznavwbbdfjnrpwwoflmovbettgg` (`pending`),
  KEY `idx_qxsfvafbjfemswkxvecuolumgcykixwfyofw` (`suspended`),
  KEY `idx_ekvgjekdznzwpwhptpqojeweciosvixltkrf` (`verificationCode`),
  KEY `idx_gphtansgfpneedbqucwlskzuqdazhmbxmmce` (`email`),
  KEY `idx_pdrqnlsebfknahtkobeaoarmrzvgygadxziu` (`username`),
  KEY `fk_ysxwuxewpsphgdzcdvokehmpdaiqjspqvqak` (`photoId`),
  CONSTRAINT `fk_xocemtowwwidjrpyatounyvxtalalkbzsdrk` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ysxwuxewpsphgdzcdvokehmpdaiqjspqvqak` FOREIGN KEY (`photoId`) REFERENCES `assets` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,NULL,1,0,0,0,1,'admin','Aaron Jay','Aaron','Jay','hello@emagine.ie','$2y$13$/180Byha96u6qGydH/2PceVJMk4.AqWBtgQ7FJDYaPFYIeJuwX0N.','2024-04-04 13:54:24',NULL,NULL,NULL,'2023-11-10 09:32:39',NULL,1,NULL,NULL,NULL,0,'2023-11-04 14:04:31','2023-11-04 14:04:31','2024-04-04 13:54:24'),(120,NULL,1,0,0,0,1,'jovana','Jovana Music','Jovana','Music','jovana@emagine.ie','$2y$13$YgO1KzUgM9PpiVJrsbSJveCJuvEUuF5QWjm/Moe3apviL5qxupey.',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,0,'2023-11-09 16:00:31','2023-11-09 16:00:00','2023-11-15 18:47:10'),(121,NULL,1,0,0,0,0,'declan','Declan O Rourke','Declan','Rourke','declan@emagine.ie','$2y$13$ycSGnSR9nGYaRRUrQq2BG.8kDHOXbUl5k8XF9NiD8fAgs0g30Qp4S','2023-11-16 10:05:28',NULL,NULL,NULL,'2023-11-16 10:05:20',NULL,1,NULL,NULL,NULL,0,'2023-11-11 12:04:47','2023-11-09 16:01:08','2023-11-16 10:05:28');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `volumefolders`
--

DROP TABLE IF EXISTS `volumefolders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `volumefolders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `parentId` int DEFAULT NULL,
  `volumeId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `path` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_mntrcddpizdufecsvytosgdmadhduyfndnti` (`name`,`parentId`,`volumeId`),
  KEY `idx_bajncvgyfyctbhhufzjmekixonygoasblbit` (`parentId`),
  KEY `idx_aulccxhmpnssnyhdhwlgjjunxwwewmhjctwj` (`volumeId`),
  CONSTRAINT `fk_nnkpfxscuxllvbpvyqfrkczftvgzxpyyqcrd` FOREIGN KEY (`parentId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rytibvrxyjvcjqnsgwccsimnajfglhxjmfwj` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `volumefolders`
--

LOCK TABLES `volumefolders` WRITE;
/*!40000 ALTER TABLE `volumefolders` DISABLE KEYS */;
/*!40000 ALTER TABLE `volumefolders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `volumes`
--

DROP TABLE IF EXISTS `volumes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `volumes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fs` varchar(255) NOT NULL,
  `transformFs` varchar(255) DEFAULT NULL,
  `transformSubpath` varchar(255) DEFAULT NULL,
  `titleTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_skauqidcnqeqijkwvilvhzxmhyonfljqidlj` (`name`),
  KEY `idx_myqfhingxuakxzbctbqgibsrbmxlazogsrtq` (`handle`),
  KEY `idx_jvlbouezhnuwwqzwbrgevyxhbnnpmugkcewp` (`fieldLayoutId`),
  KEY `idx_xheucxmgzjhzcxdtfaruiuebanilroikmgnj` (`dateDeleted`),
  CONSTRAINT `fk_fatynnlcwodsjgwpnymauozhqcmlgofnseux` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `volumes`
--

LOCK TABLES `volumes` WRITE;
/*!40000 ALTER TABLE `volumes` DISABLE KEYS */;
/*!40000 ALTER TABLE `volumes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `widgets`
--

DROP TABLE IF EXISTS `widgets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `widgets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `type` varchar(255) NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `colspan` tinyint DEFAULT NULL,
  `settings` text,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_lbdoywerygwwotnnzlnksvywsckeqaulbjmp` (`userId`),
  CONSTRAINT `fk_cnatxvxuibiyhfosvnlhepnfpzscrxecbodp` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `widgets`
--

LOCK TABLES `widgets` WRITE;
/*!40000 ALTER TABLE `widgets` DISABLE KEYS */;
INSERT INTO `widgets` VALUES (1,1,'craft\\widgets\\RecentEntries',1,NULL,'{\"siteId\":1,\"section\":\"*\",\"limit\":10}',1,'2023-11-04 14:04:32','2023-11-04 14:04:32','2316b5f7-8faf-4baf-82a1-a230d0bbdd10'),(2,1,'craft\\widgets\\CraftSupport',2,NULL,'[]',1,'2023-11-04 14:04:32','2023-11-04 14:04:32','0c7cbb87-ab4a-478f-8eba-25ae535bde55'),(3,1,'craft\\widgets\\Updates',3,NULL,'[]',1,'2023-11-04 14:04:32','2023-11-04 14:04:32','e61c47e9-ba19-4c9c-853e-accf58eb3eba'),(4,1,'craft\\widgets\\Feed',4,NULL,'{\"url\":\"https:\\/\\/craftcms.com\\/news.rss\",\"title\":\"Craft News\",\"limit\":5}',1,'2023-11-04 14:04:32','2023-11-04 14:04:32','5cdf26f1-80b1-4b73-bc48-a1fddad25b91'),(5,120,'craft\\widgets\\RecentEntries',1,NULL,'{\"siteId\":1,\"section\":\"*\",\"limit\":10}',1,'2023-11-09 16:00:15','2023-11-09 16:00:15','7a71e74f-ad48-444b-be43-06b0bc0ac575'),(6,120,'craft\\widgets\\CraftSupport',2,NULL,'[]',1,'2023-11-09 16:00:15','2023-11-09 16:00:15','8a3acbf1-2e40-4972-b9b8-ade2232c9873'),(7,120,'craft\\widgets\\Updates',3,NULL,'[]',1,'2023-11-09 16:00:15','2023-11-09 16:00:15','dba82129-fe06-4433-9ef8-9999e7f87da0'),(8,120,'craft\\widgets\\Feed',4,NULL,'{\"url\":\"https:\\/\\/craftcms.com\\/news.rss\",\"title\":\"Craft News\",\"limit\":5}',1,'2023-11-09 16:00:15','2023-11-09 16:00:15','912869a3-147d-41de-adb0-c088f1c06183'),(9,121,'craft\\widgets\\RecentEntries',1,NULL,'{\"siteId\":1,\"section\":\"*\",\"limit\":10}',1,'2023-11-09 16:01:27','2023-11-09 16:01:27','e9d35caa-5466-4cc5-ad1f-32831d277c99'),(10,121,'craft\\widgets\\CraftSupport',2,NULL,'[]',1,'2023-11-09 16:01:27','2023-11-09 16:01:27','ca206115-48d6-47a7-a8f8-d853abcf1af5'),(11,121,'craft\\widgets\\Updates',3,NULL,'[]',1,'2023-11-09 16:01:27','2023-11-09 16:01:27','e14c21eb-be73-4f55-a3c7-5f35bb27ff3a'),(12,121,'craft\\widgets\\Feed',4,NULL,'{\"url\":\"https:\\/\\/craftcms.com\\/news.rss\",\"title\":\"Craft News\",\"limit\":5}',1,'2023-11-09 16:01:27','2023-11-09 16:01:27','6253b7e4-e4e0-4b8c-952d-a4515f9de5ed');
/*!40000 ALTER TABLE `widgets` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-04-04 14:14:22
